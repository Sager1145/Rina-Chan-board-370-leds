"""Regenerate default_faces.py and faces370.json from a demo_faces.py file."""
import argparse, importlib.util, json
from pathlib import Path

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('demo_faces_py')
    ap.add_argument('--out-dir', default='esp32s3_firmware')
    args = ap.parse_args()
    src = Path(args.demo_faces_py)
    out_dir = Path(args.out_dir)
    spec = importlib.util.spec_from_file_location('demo_faces', src)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    faces = []
    for i, frame in enumerate(m.FRAMES):
        faces.append({
            'default_id': 'py_default_%02d' % i,
            'name': 'Default %02d' % i,
            'type': 'default', 'locked': True, 'builtin': True,
            'source': src.name, 'data': frame,
        })
    (out_dir / 'default_faces.py').write_text('DEFAULT_START_INDEX=%r\nDEFAULT_SAVED_FACES=%r\n' % (m.DEFAULT_FACE_INDEX, faces), encoding='utf-8')
    (out_dir / 'faces370.json').write_text(json.dumps(faces, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')

if __name__ == '__main__':
    main()
