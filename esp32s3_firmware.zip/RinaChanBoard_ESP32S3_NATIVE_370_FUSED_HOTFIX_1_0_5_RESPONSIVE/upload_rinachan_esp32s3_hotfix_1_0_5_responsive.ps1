param(
    [string]$ZipPath = ".\RinaChanBoard_ESP32S3_NATIVE_370_FUSED_HOTFIX_1_0_5_RESPONSIVE.zip",
    [string]$Port = "auto",
    [switch]$EraseKnownFiles
)

$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not [System.IO.Path]::IsPathRooted($ZipPath)) {
    $ZipPath = Join-Path $ScriptDir $ZipPath
}
if (-not (Test-Path $ZipPath)) {
    throw "ZIP not found: $ZipPath"
}

$WorkDir = Join-Path $ScriptDir "RinaChanBoard_ESP32S3_NATIVE_370_FUSED_upload"
if (Test-Path $WorkDir) { Remove-Item -Recurse -Force $WorkDir }
New-Item -ItemType Directory -Force -Path $WorkDir | Out-Null
Expand-Archive -Path $ZipPath -DestinationPath $WorkDir -Force

$ProjectDir = Join-Path $WorkDir "RinaChanBoard_ESP32S3_NATIVE_370_FUSED"
if (-not (Test-Path $ProjectDir)) {
    $ProjectDir = Join-Path $WorkDir "RinaChanBoard_ESP32S3_NATIVE_370_FUSED_HOTFIX_1_0_5_RESPONSIVE"
}
if (-not (Test-Path $ProjectDir)) {
    $ProjectDir = $WorkDir
}
$FirmwareDir = Join-Path $ProjectDir "esp32s3_firmware"
if (-not (Test-Path $FirmwareDir)) {
    throw "Firmware directory not found inside ZIP: esp32s3_firmware"
}

function Invoke-Mpremote {
    param([string[]]$ArgsList)
    Write-Host "py -m mpremote $($ArgsList -join ' ')" -ForegroundColor DarkCyan
    & py -m mpremote @ArgsList
    if ($LASTEXITCODE -ne 0) { throw "mpremote failed with exit code $LASTEXITCODE" }
}

try {
    & py -m mpremote --help *> $null
    if ($LASTEXITCODE -ne 0) { throw "mpremote missing" }
} catch {
    Write-Host "Installing mpremote with pip..." -ForegroundColor Yellow
    & py -m pip install --upgrade mpremote
    if ($LASTEXITCODE -ne 0) { throw "Failed to install mpremote" }
}

if ($EraseKnownFiles) {
    $Known = @(
        "main.py","board.py","buttons.py","config.py","default_faces.py","display_num.py","display_text.py",
        "face_codec.py","face_parts.py","faces370.json","network_manager.py","saved_faces.py",
        "settings_store.py","webui.py","protocol_server.py","logger.py","wifi_config.py","battery.py","settings370.json"
    )
    foreach ($f in $Known) {
        try { Invoke-Mpremote @("connect", $Port, "fs", "rm", ":$f") } catch { Write-Host "skip rm $f" -ForegroundColor DarkGray }
    }
    try { Invoke-Mpremote @("connect", $Port, "fs", "rm", ":webui/index.html") } catch { Write-Host "skip rm webui/index.html" -ForegroundColor DarkGray }
}

try { Invoke-Mpremote @("connect", $Port, "fs", "mkdir", ":webui") } catch { Write-Host "webui directory already exists or mkdir failed; continuing" -ForegroundColor DarkGray }

Get-ChildItem -Path $FirmwareDir -File | Sort-Object Name | ForEach-Object {
    Invoke-Mpremote @("connect", $Port, "fs", "cp", $_.FullName, ":$($_.Name)")
}
Get-ChildItem -Path (Join-Path $FirmwareDir "webui") -File | Sort-Object Name | ForEach-Object {
    Invoke-Mpremote @("connect", $Port, "fs", "cp", $_.FullName, ":webui/$($_.Name)")
}

Invoke-Mpremote @("connect", $Port, "reset")
Write-Host "Upload complete. Responsive build uploaded. Connect phone to RINA-S3, password 12345678, then open http://192.168.4.1/" -ForegroundColor Green
