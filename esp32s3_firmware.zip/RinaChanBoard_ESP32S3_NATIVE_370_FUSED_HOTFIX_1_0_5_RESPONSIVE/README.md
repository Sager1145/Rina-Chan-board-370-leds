# RinaChanBoard ESP32-S3 Native 370 LED Fused - HOTFIX 1.0.5 RESPONSIVE

Version: `2.0.4-esp32s3-native-370-fused-responsive`

This build keeps the AP-stable Wi-Fi settings from HOTFIX 1.0.4 and focuses on responsiveness:

- Physical buttons are serviced during HTTP/DNS/UDP transfers.
- WebUI command buttons return immediately and refresh state in the background.
- Flash writes for brightness / face index / mode / interval are deferred until after button activity stops.
- High-frequency serial logs are disabled by default to prevent USB serial printing from slowing down controls.
- Poll period is reduced to 1 ms.
- HTTP client timeout is shortened to avoid stalled phone/browser sockets blocking the main loop.
- Battery ADC mean still uses multiple samples per second, but with fewer samples per read to reduce blocking time.

Phone connection:

- SSID: `RINA-S3`
- Password: `12345678`
- URL: `http://192.168.4.1/`

Upload:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\upload_rinachan_esp32s3_hotfix_1_0_5_responsive.ps1 -ZipPath .\RinaChanBoard_ESP32S3_NATIVE_370_FUSED_HOTFIX_1_0_5_RESPONSIVE.zip -Port auto -EraseKnownFiles
```

Logging notes:

- `LOG_LEVEL = 3` keeps activity logs.
- `LOG_BATTERY_MEAN = False`, `LOG_PROTOCOL_VERBOSE = False`, and `LOG_DRAW_VERBOSE = False` are deliberate for responsiveness.
- Turn them back on only while debugging a specific issue.
