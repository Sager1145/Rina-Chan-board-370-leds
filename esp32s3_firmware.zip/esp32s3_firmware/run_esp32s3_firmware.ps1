param(
    [string]$Port = "COM6",
    [string]$ZipPath = "",
    [switch]$SkipFirmware,
    [switch]$SkipFilesystem,
    [switch]$Clean
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Write-Step {
    param([string]$Message)
    Write-Host "`n==> $Message" -ForegroundColor Cyan
}

function Invoke-Checked {
    param(
        [string]$FilePath,
        [string[]]$Arguments,
        [string]$WorkingDirectory
    )
    Write-Host "> $FilePath $($Arguments -join ' ')" -ForegroundColor DarkGray
    Push-Location $WorkingDirectory
    try {
        & $FilePath @Arguments
        if ($LASTEXITCODE -ne 0) {
            throw "$FilePath exited with code $LASTEXITCODE"
        }
    }
    finally {
        Pop-Location
    }
}

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
if ([string]::IsNullOrWhiteSpace($scriptDir)) {
    $scriptDir = (Get-Location).Path
}

if (-not [string]::IsNullOrWhiteSpace($ZipPath)) {
    $resolvedZip = Resolve-Path $ZipPath
    Write-Step "Extracting firmware ZIP"
    Expand-Archive -Path $resolvedZip.Path -DestinationPath $scriptDir -Force
}

$projectDir = $scriptDir
if (-not (Test-Path (Join-Path $projectDir "platformio.ini"))) {
    $candidate = Join-Path $scriptDir "esp32s3_firmware"
    if (Test-Path (Join-Path $candidate "platformio.ini")) {
        $projectDir = $candidate
    }
    else {
        throw "Could not find platformio.ini. Run this script from the project folder, or pass -ZipPath to the release ZIP."
    }
}

Write-Step "Using project directory"
Write-Host $projectDir

try {
    & pio --version | Out-Host
    if ($LASTEXITCODE -ne 0) { throw "PlatformIO check failed" }
}
catch {
    throw "PlatformIO CLI 'pio' was not found. Install PlatformIO Core or run this from a VS Code PlatformIO terminal."
}

if ($Clean) {
    Write-Step "Cleaning stale build output"
    Invoke-Checked -FilePath "pio" -Arguments @("run", "-e", "esp32s3", "-t", "clean") -WorkingDirectory $projectDir
}

Write-Step "Filesystem payload size"
Get-ChildItem (Join-Path $projectDir "data") -Recurse -File |
    Sort-Object Length -Descending |
    Select-Object FullName, @{Name="KB"; Expression={[math]::Round($_.Length / 1KB, 1)}} |
    Format-Table -AutoSize

if (-not $SkipFirmware) {
    Write-Step "Uploading firmware and partition table to $Port"
    Invoke-Checked -FilePath "pio" -Arguments @("run", "-e", "esp32s3", "-t", "upload", "--upload-port", $Port) -WorkingDirectory $projectDir
}
else {
    Write-Step "Skipping firmware upload by request"
}

if (-not $SkipFilesystem) {
    Write-Step "Uploading LittleFS image to $Port"
    Invoke-Checked -FilePath "pio" -Arguments @("run", "-e", "esp32s3", "-t", "uploadfs", "--upload-port", $Port) -WorkingDirectory $projectDir
}
else {
    Write-Step "Skipping filesystem upload by request"
}

Write-Step "Done"
Write-Host "Connect to SSID RinaChanBoard-ESP32S3, password rinachan, then open http://192.168.1.14/"
