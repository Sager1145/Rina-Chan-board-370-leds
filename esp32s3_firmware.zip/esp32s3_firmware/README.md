# esp32s3_firmware saved_faces default migration

Open `data/index.html` directly, or serve `data/` as the web root for the ESP32/static server.

The unified face library is `data/resources/saved_faces.json`.

Default startup face: `face_07_triangle_eyes_frown`.
