param(
    [string]$ZipPath = ".\RinaChanBoard_ESP32S3_NATIVE_370_FUSED_HOTFIX_1_0_7_FORCE_IMPORT_FIX.zip",
    [string]$Port = "auto",
    [switch]$EraseKnownFiles,
    [switch]$ForceFormat
)

$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not [System.IO.Path]::IsPathRooted($ZipPath)) {
    $ZipPath = Join-Path $ScriptDir $ZipPath
}
if (-not (Test-Path $ZipPath)) { throw "ZIP not found: $ZipPath" }

$WorkDir = Join-Path $ScriptDir "RinaChanBoard_ESP32S3_FORCE_IMPORT_FIX_upload"
if (Test-Path $WorkDir) { Remove-Item -Recurse -Force $WorkDir }
New-Item -ItemType Directory -Force -Path $WorkDir | Out-Null
Expand-Archive -Path $ZipPath -DestinationPath $WorkDir -Force

$ProjectDir = Join-Path $WorkDir "RinaChanBoard_ESP32S3_NATIVE_370_FUSED_HOTFIX_1_0_7_FORCE_IMPORT_FIX"
if (-not (Test-Path $ProjectDir)) { $ProjectDir = $WorkDir }
$FirmwareDir = Join-Path $ProjectDir "esp32s3_firmware"
if (-not (Test-Path $FirmwareDir)) { throw "Firmware directory not found inside ZIP: esp32s3_firmware" }

function Invoke-Mpremote {
    param([string[]]$ArgsList, [switch]$AllowFail)
    Write-Host "py -m mpremote $($ArgsList -join ' ')" -ForegroundColor DarkCyan
    & py -m mpremote @ArgsList
    $code = $LASTEXITCODE
    if (($code -ne 0) -and (-not $AllowFail)) { throw "mpremote failed with exit code $code" }
    return $code
}

try {
    & py -m mpremote --help *> $null
    if ($LASTEXITCODE -ne 0) { throw "mpremote missing" }
} catch {
    Write-Host "Installing mpremote with pip..." -ForegroundColor Yellow
    & py -m pip install --upgrade mpremote
    if ($LASTEXITCODE -ne 0) { throw "Failed to install mpremote" }
}

Invoke-Mpremote @("connect", $Port, "exec", "print('mpremote upload session start')") -AllowFail | Out-Null

if ($ForceFormat) {
    Write-Host "ForceFormat requested: recursively deleting board filesystem content before upload." -ForegroundColor Yellow
    $cleanScript = @'
import os

def rm_tree(path):
    try:
        st = os.stat(path)
    except OSError:
        return
    if st[0] & 0x4000:
        for name in os.listdir(path):
            rm_tree(path.rstrip('/') + '/' + name)
        if path != '/':
            try:
                os.rmdir(path)
            except OSError as e:
                print('rmdir skip', path, e)
    else:
        try:
            os.remove(path)
        except OSError as e:
            print('remove skip', path, e)

for name in os.listdir('/'):
    rm_tree('/' + name)
print('filesystem cleaned')
'@
    Invoke-Mpremote @("connect", $Port, "exec", $cleanScript) | Out-Null
} else {
    $AlwaysRemove = @("main.py", "webui.py", "protocol_server.py")
    foreach ($f in $AlwaysRemove) {
        Invoke-Mpremote @("connect", $Port, "fs", "rm", ":$f") -AllowFail | Out-Null
    }
    Invoke-Mpremote @("connect", $Port, "fs", "rm", ":webui/index.html") -AllowFail | Out-Null
    Invoke-Mpremote @("connect", $Port, "fs", "rm", ":webui/index.html.gz") -AllowFail | Out-Null

    if ($EraseKnownFiles) {
        $Known = @(
            "board.py","buttons.py","config.py","default_faces.py","display_num.py","display_text.py",
            "face_codec.py","face_parts.py","faces370.json","network_manager.py","saved_faces.py",
            "settings_store.py","logger.py","wifi_config.py","battery.py","settings370.json"
        )
        foreach ($f in $Known) { Invoke-Mpremote @("connect", $Port, "fs", "rm", ":$f") -AllowFail | Out-Null }
    }
}

Invoke-Mpremote @("connect", $Port, "fs", "mkdir", ":webui") -AllowFail | Out-Null

$topFiles = Get-ChildItem -Path $FirmwareDir -File | Where-Object { $_.Name -ne "main.py" } | Sort-Object Name
foreach ($file in $topFiles) {
    Invoke-Mpremote @("connect", $Port, "fs", "cp", $file.FullName, ":$($file.Name)") | Out-Null
}

$webuiDir = Join-Path $FirmwareDir "webui"
Get-ChildItem -Path $webuiDir -File | Sort-Object Name | ForEach-Object {
    Invoke-Mpremote @("connect", $Port, "fs", "cp", $_.FullName, ":webui/$($_.Name)") | Out-Null
}

$mainFile = Join-Path $FirmwareDir "main.py"
Invoke-Mpremote @("connect", $Port, "fs", "cp", $mainFile, ":main.py") | Out-Null

Write-Host "Verifying remote main.py import..." -ForegroundColor Yellow
$remoteMainLines = & py -m mpremote connect $Port fs cat :main.py
if ($LASTEXITCODE -ne 0) { throw "Could not read back remote main.py" }
$remoteMain = ($remoteMainLines -join "`n")
if ($remoteMain -notmatch "from protocol_server import ProtocolServer") {
    throw "Upload verification failed: remote main.py does not contain 'from protocol_server import ProtocolServer'."
}
if ($remoteMain -match "from webui import ProtocolServer|webui\.ProtocolServer") {
    throw "Upload verification failed: remote main.py still contains stale webui.ProtocolServer import."
}
Write-Host "Remote main.py verified: protocol_server import is active." -ForegroundColor Green

Invoke-Mpremote @("connect", $Port, "reset") | Out-Null
Write-Host "Upload complete. Connect to SSID RINA-S3, password 12345678, then open http://192.168.4.1/" -ForegroundColor Green
