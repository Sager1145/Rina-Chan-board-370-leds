# RinaChanBoard ESP32-S3 Native 370 LED - HOTFIX 1.0.6 WEBUI FULL

Version: `2.0.6-esp32s3-native-370-fused-webui-import-fix`

This build integrates the uploaded full WebUI bundle and adds firmware-side compatibility endpoints for the WebUI:

- `/api/send`
- `/api/request`
- `/api/binary`
- `/api/status`
- `/api/flyakari/test`
- `/api/wifi/status`
- `/api/wifi/scan`
- `/api/wifi/save`

It also adds direct command support for:

- `M370:<93 hex>` full 370 logical matrix upload
- `#RRGGBB` color upload
- `Bxxx` legacy brightness upload
- `requestVersion`, `requestEspStatus`, `requestFace370`, `requestColor`, `requestBright`, `requestBattery`, `requestState`
- `saveFace370|name|M370:<hex>`
- `deleteFace370|name`
- `renameFace370|old|new`
- `saveFaces370Json|[...]`
- `scrollText370|speed_ms|text`
- `timeline370Begin`, `timeline370Chunk`, `timeline370Play`, `timeline370Preview`, `timeline370Stop`, `timeline370Clear`
- `setManualMode|1/0`, `manualMode|1/0/toggle`, `manualControlMode|1/0`

The full WebUI is stored as `webui/index.html.gz` and served with `Content-Encoding: gzip` to reduce AP page load time and keep physical-button response more immediate during page transfer.

AP defaults:

- SSID: `RINA-S3`
- Password: `12345678`
- URL: `http://192.168.4.1/`

Upload from Windows PowerShell:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\upload_rinachan_esp32s3_hotfix_1_0_6_webui_full.ps1 -ZipPath .\RinaChanBoard_ESP32S3_NATIVE_370_FUSED_HOTFIX_1_0_6_WEBUI_FULL.zip -Port auto -EraseKnownFiles
```

## HOTFIX 1.0.7 note
This package force-fixes stale `main.py` imports. The uploaded `main.py` imports `ProtocolServer` from `protocol_server.py`; it does not import `webui.ProtocolServer`. The companion PowerShell script verifies the remote `main.py` after upload.
