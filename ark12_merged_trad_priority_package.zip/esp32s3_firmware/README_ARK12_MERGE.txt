Ark12 merged font package for RinaChanBoard

Goal:
- Build one Ark Pixel 12px monospaced bitmap JSON covering Simplified Chinese, Traditional Chinese, Japanese, English, and symbols.
- Merge priority is low -> high: zh_cn, ja, zh_tw.
- When the same Unicode codepoint exists in more than one source, zh_tw is applied last and wins.

Run from the extracted esp32s3_firmware folder:

powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\run_merge_ark12_traditional_priority.ps1

Outputs:
- data\resources\fonts\ark12_merged_trad_priority.json
- data\resources\fonts\ark12.json
- data\resources\fonts\ark12.woff2
- data\resources\fonts\ark12_merged_trad_priority_report.txt

Offline/cache mode:
- Put these files in .font_cache first, then run with -NoDownload:
  - ark-pixel-font-12px-monospaced-bdf-v2026.05.07.zip
  - ark-pixel-font-12px-monospaced-otf.woff2-v2026.05.07.zip

Example:
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\run_merge_ark12_traditional_priority.ps1 -NoDownload

Validation fix v2:
- The default sample no longer includes U+908A 邊 because official Ark Pixel 12px v2026.05.07 does not cover that codepoint.
- Missing sample glyphs are warning-only unless --strict-sample is passed to the Python builder.
