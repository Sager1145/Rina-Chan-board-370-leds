console.log('[RinaChanBoard] app.js loaded v2.0.10-color-memory-ap');

(function(){

  function isLocalHost(){
    return /^(localhost|127\.0\.0\.1|::1)$/i.test(location.hostname || '');
  }

  function hardwareMode(){
    return (location.protocol === 'http:' || location.protocol === 'https:') && !isLocalHost();
  }
  window.rinaHardwareMode = hardwareMode;
  window.rinaPreviewMode = function(){ return !hardwareMode(); };
  window.rinaApiBase = function(){ return hardwareMode() ? location.origin : 'local-preview'; };
  window.rinaDeviceUrl = function(input){ return input; };
})();

const DEFAULT_COLOR_HEX = 'f971d4';
function currentColorHex(){ return cleanHex(($('colorHex') && $('colorHex').value) || DEFAULT_COLOR_HEX).slice(0, 6).padEnd(6, '0').toLowerCase(); }
function setUiThemeColor(hex){
  const h = cleanHex(hex || DEFAULT_COLOR_HEX).slice(0, 6).padEnd(6, '0').toLowerCase();
  if ($('colorHex')) $('colorHex').value = h;
  if ($('colorPick')) $('colorPick').value = '#' + h;
  if (document && document.documentElement) {
    document.documentElement.style.setProperty('--accent', '#' + h);
    document.documentElement.style.setProperty('--accent-soft', '#' + h + '55');
  }
  return h;
}

function horizontalFlip(array)
{
    return array.map(row => row.slice().reverse());
}

const none = [
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
];

const mouth = [[

    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,1,1,1,1,1,1,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
],[

    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [1,0,0,0,0,0,0,1],
    [0,1,1,1,1,1,1,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
],[

    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [1,0,0,0,0,0,0,1],
    [0,1,0,0,0,0,1,0],
    [0,0,1,1,1,1,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
],[

    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,1,0,0,0,0,1,0],
    [0,0,1,0,0,1,0,0],
    [0,0,0,1,1,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
],[

    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [1,1,1,1,1,1,1,1],
    [1,0,0,0,0,0,0,1],
    [0,1,0,0,0,0,1,0],
    [0,0,1,0,0,1,0,0],
    [0,0,0,1,1,0,0,0],
    [0,0,0,0,0,0,0,0],
],[

    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [1,1,1,1,1,1,1,1],
    [1,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,1],
    [0,1,0,0,0,0,1,0],
    [0,0,1,1,1,1,0,0],
    [0,0,0,0,0,0,0,0],
],[

    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,1,1,1,1,1,1,0],
    [0,1,0,0,0,0,1,0],
    [0,0,1,0,0,1,0,0],
    [0,0,0,1,1,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
],[

    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,1,1,1,1,0,0],
    [0,1,0,0,0,0,1,0],
    [1,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,1],
    [1,1,1,1,1,1,1,1],
    [0,0,0,0,0,0,0,0],
],[

    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [1,1,1,1,1,1,1,1],
    [1,0,0,0,0,0,0,1],
    [0,1,1,1,1,1,1,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
],[

    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,1,1,0,0,0],
    [0,0,1,0,0,1,0,0],
    [0,0,1,0,0,1,0,0],
    [0,0,0,1,1,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
],[

    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,1,1,0,0,0],
    [0,0,1,0,0,1,0,0],
    [0,1,0,0,0,0,1,0],
    [0,1,0,0,0,0,1,0],
    [0,0,1,0,0,1,0,0],
    [0,0,0,1,1,0,0,0],
],[

    [0,0,0,0,0,0,0,0],
    [0,0,0,1,1,0,0,0],
    [0,0,1,0,0,1,0,0],
    [0,0,1,0,0,1,0,0],
    [0,0,1,0,0,1,0,0],
    [0,0,1,0,0,1,0,0],
    [0,0,0,1,1,0,0,0],
    [0,0,0,0,0,0,0,0],
],[

    [0,0,0,1,1,0,0,0],
    [0,0,1,0,0,1,0,0],
    [0,0,1,0,0,1,0,0],
    [0,0,1,0,0,1,0,0],
    [0,0,1,0,0,1,0,0],
    [0,0,1,0,0,1,0,0],
    [0,0,0,1,1,0,0,0],
    [0,0,0,0,0,0,0,0],
],[

    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,1,1,1,1,1,1,0],
    [1,0,0,0,0,0,0,1],
    [1,1,1,1,1,1,1,1],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
],[

    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,1,0,0,1,0,0],
    [0,1,0,1,1,0,1,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
],[

    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [1,0,0,0,0,0,0,1],
    [0,1,0,0,0,0,1,0],
    [0,1,1,1,1,1,1,0],
    [0,1,0,0,0,0,1,0],
    [1,0,0,0,0,0,0,1],
    [0,0,0,0,0,0,0,0],
],[
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,1,1,1,1,0,0],
    [0,1,0,0,0,0,1,0],
    [0,1,0,0,0,0,1,0],
    [0,0,1,0,0,1,0,0],
    [0,0,0,1,1,0,0,0],
    [0,0,0,0,0,0,0,0],
],[
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,1,1,1,1,1,1,0],
    [0,1,0,0,0,0,1,0],
    [0,1,1,1,1,1,1,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
],[
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,1,1,0,0,1,1,0],
    [1,0,0,1,1,0,0,1],
    [1,0,0,0,0,0,0,1],
    [1,0,0,1,1,0,0,1],
    [0,1,1,0,0,1,1,0],
    [0,0,0,0,0,0,0,0],
]]

const leye = [
[

    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,1,1,0,0,0,0],
    [0,0,1,1,0,0,0,0],
    [0,0,1,1,0,0,0,0],
    [0,0,1,1,0,0,0,0],
    [0,0,0,0,0,0,0,0],
],[

    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,1,0,0,0,0,0,0],
    [0,0,1,1,0,0,0,0],
    [0,0,1,1,0,0,0,0],
    [0,0,1,1,0,0,0,0],
    [0,0,1,1,0,0,0,0],
    [0,0,0,0,0,0,0,0],
],[

    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,1,0,0,0],
    [0,0,0,1,0,1,0,0],
    [0,0,1,0,0,0,1,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
],[

    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,1,1,0,0,0,0,0],
    [0,0,0,1,1,0,0,0],
    [0,0,0,0,0,1,0,0],
    [0,0,0,1,1,0,0,0],
    [0,1,1,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
],[

    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,1,1,0,0,0],
    [0,0,1,1,0,1,0,0],
    [0,0,1,1,1,1,0,0],
    [0,0,0,1,1,0,0,0],
    [0,0,0,0,0,0,0,0],
],[

    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,1,0,0,0,0,0,0],
    [0,0,1,1,1,1,0,0],
    [0,0,0,0,0,0,0,0],
],[

    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,1,1,1,1,1,1,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
],[

    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,1,1,1,1,1,1,0],
    [1,0,1,0,0,0,0,0],
    [0,1,0,0,0,0,0,0],
],[

    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,1,1,1,0,0],
    [0,0,1,0,0,0,1,0],
    [0,0,0,0,0,1,0,0],
    [0,0,0,0,1,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,1,0,0,0],
],[

    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,1,0,0,0],
    [0,0,0,0,1,0,0,0],
    [0,0,0,0,1,0,0,0],
    [0,0,0,0,1,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,1,0,0,0],
],[

    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,1,1,0,0,0,0],
    [0,0,1,1,1,1,0,0],
    [0,0,0,1,1,0,0,0],
    [0,0,0,0,0,0,0,0],
],[

    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,1,0,0,0],
    [0,0,0,1,0,0,0,0],
    [0,1,1,1,0,0,0,0],
    [0,0,1,1,0,0,0,0],
    [0,0,1,1,0,0,0,0],
    [0,0,0,0,0,0,0,0],
],[

    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,1,0,0,0,0,0,0],
    [0,0,1,0,0,0,0,0],
    [0,0,1,1,1,0,0,0],
    [0,0,1,1,0,0,0,0],
    [0,0,1,1,0,0,0,0],
    [0,0,0,0,0,0,0,0],
],[

    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,1,0,0,0,1,0],
    [0,0,0,1,0,1,0,0],
    [0,0,0,0,1,0,0,0],
    [0,0,0,1,0,1,0,0],
    [0,0,1,0,0,0,1,0],
    [0,0,0,0,0,0,0,0],
],[

    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,1,1,1,0,0],
    [0,0,1,0,0,0,1,0],
    [0,0,1,0,0,0,1,0],
    [0,0,1,0,0,0,1,0],
    [0,0,0,1,1,1,0,0],
    [0,0,0,0,0,0,0,0],
],[

    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,1,1,0,1,1,0],
    [0,1,0,0,1,0,0,1],
    [0,1,0,0,0,0,0,1],
    [0,0,1,0,0,0,1,0],
    [0,0,0,1,0,1,0,0],
    [0,0,0,0,1,0,0,0],
],[

    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,1,1,0,0,0],
    [0,0,1,1,0,1,0,0],
    [0,0,1,1,1,1,0,0],
    [0,1,0,1,1,0,0,0],
    [0,0,1,0,0,0,0,0],
],[

    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,1,1,0,0,0,0,0],
    [0,0,0,1,1,0,0,0],
    [0,0,0,0,0,1,0,0],
    [0,1,1,1,1,0,0,0],
    [0,0,0,0,0,0,0,0],
],[

    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,1,1,0,0,0],
    [0,0,1,0,0,1,0,0],
    [0,1,0,0,0,0,1,0],
    [0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0],
]];

const reye=[
    horizontalFlip(leye[0]),horizontalFlip(leye[1]),
    horizontalFlip(leye[2]),horizontalFlip(leye[3]),
    horizontalFlip(leye[4]),horizontalFlip(leye[5]),
    horizontalFlip(leye[6]),horizontalFlip(leye[7]),
    horizontalFlip(leye[8]),horizontalFlip(leye[9]),
    horizontalFlip(leye[10]),horizontalFlip(leye[11]),
    horizontalFlip(leye[12]),horizontalFlip(leye[13]),
    horizontalFlip(leye[14]),horizontalFlip(leye[15]),
    horizontalFlip(leye[16]),horizontalFlip(leye[17]),
    horizontalFlip(leye[18]),
];

const cheek00 = [
    [0,0,0,0,0],
    [0,0,0,0,0]
];

const cheek = [[

    [0,0,0,0,0],
    [0,0,1,1,0]
],[

    [0,0,0,0,0],
    [0,1,0,1,0]
],[

    [0,0,1,0,1],
    [0,1,0,1,0]
],[

    [0,1,0,1,0],
    [0,0,1,0,1]
]];

window.RINA_FACES = { none, horizontalFlip, mouth, leye, reye, cheek00, cheek };

const device_info=[
    {uid:'null',topic:'null'},
    {uid:'a8a83e1f0a4c4e42b031e1c323dd9159',topic:'RinaChanBoard'},
    {uid:'a8a83e1f0a4c4e42b031e1c323dd9159',topic:'RinaChanBoardExp'},
];

const color_info=[
    {name:'默认璃奈粉色',           color:'f971d4'},
    {name:'高坂穗乃果-橙色',        color:'f38500'},
    {name:'绚濑绘里-水蓝色',        color:'7aeeff'},
    {name:'南小鸟-白色',            color:'cebfbf'},
    {name:'园田海未-蓝色',          color:'1769ff'},
    {name:'星空凛-黄色',            color:'fff832'},
    {name:'西木野真姬-红色',        color:'ff503e'},
    {name:'东条希-紫罗兰色',        color:'c455f6'},
    {name:'小泉花阳-绿色',          color:'6ae673'},
    {name:'矢泽妮可-粉色',          color:'ff4f91'},
    {name:'高海千歌-蜜柑色',        color:'ff9547'},
    {name:'樱内梨子-樱花粉色',      color:'ff9eac'},
    {name:'松浦果南-祖母绿色',      color:'27c1b7'},
    {name:'黑泽黛雅-红色',          color:'db0839'},
    {name:'渡边曜-亮蓝色',          color:'66c0ff'},
    {name:'津岛善子-白色',          color:'c1cad4'},
    {name:'国木田花丸-黄色',        color:'ffd010'},
    {name:'小原鞠莉-紫罗兰色',      color:'c252c6'},
    {name:'黑泽露比-粉色',          color:'ff6fbe'},
    {name:'CYaRon!-橙色',           color:'ffa434'},
    {name:'AZALEA-粉色',            color:'ff5a79'},
    {name:'Guilty Kiss-紫色',       color:'825deb'},
    {name:'鹿角圣良-天蓝色',        color:'00ccff'},
    {name:'鹿角理亚-纯白色',        color:'bbbbbb'},
    {name:'Saint Snow-红色',        color:'cb3935'},
    {name:'高咲侑-黑色',            color:'1d1d1d'},
    {name:'上原步梦-浅粉色',        color:'ed7d95'},
    {name:'中须霞-蜡笔黄色',        color:'e7d600'},
    {name:'樱坂雫-浅蓝色',          color:'01b7ed'},
    {name:'朝香果林-皇室蓝色',      color:'485ec6'},
    {name:'宫下爱-超橙色',          color:'ff5800'},
    {name:'近江彼方-堇色',          color:'a664a0'},
    {name:'优木雪菜-猩红色',        color:'d81c2f'},
    {name:'艾玛·维尔德-浅绿色',     color:'84c36e'},
    {name:'天王寺璃奈-纸白色',      color:'9ca5b9'},
    {name:'三船栞子-翡翠色',        color:'37b484'},
    {name:'米雅·泰勒-白金银色',     color:'a9a898'},
    {name:'钟岚珠-玫瑰金色',        color:'f8c8c4'},
    {name:'DiverDiva-银紫色',       color:'ab76f7'},
    {name:'A·ZU·NA-意大利红色',     color:'ff0042'},
    {name:'QU4RTZ-奶茶色',          color:'d9db83'},
    {name:'R3BIRTH-坦桑蓝色',       color:'424a9d'},
    {name:'涩谷香音-金盏花色',      color:'ff7f27'},
    {name:'唐可可-蜡笔蓝色',        color:'a0fff9'},
    {name:'岚千砂都-桃粉色',        color:'ff6e90'},
    {name:'平安名堇-蜜瓜绿色',      color:'74f466'},
    {name:'叶月恋-宝石蓝色',        color:'0000a0'},
    {name:'樱小路希奈子-玉米黄色',  color:'fff442'},
    {name:'米女芽衣-胭脂红色',      color:'ff3535'},
    {name:'若菜四季-冰绿白色',      color:'b2ffdd'},
    {name:'鬼冢夏美-鬼夏粉色',      color:'ff51c4'},
    {name:'薇恩·玛格丽特-优雅紫色', color:'e49dfd'},
    {name:'鬼冢冬毬-烟熏蓝色',      color:'4cd2e2'},
];

function sleep (time)
{
    return new Promise((resolve) => setTimeout(resolve, time));
}

window.RINA_COLOR_INFO = color_info; window.RINA_DEVICE_INFO = device_info;

const FPS=30

const voice_data=[
    {
        id:'vo_na_m0209_0001',
        text:'欢迎回来! 璃奈板,笑一个~',
        faces:[
            {leye: 2,reye: 2,mouth: 6,cheek: 0,during:  6},
            {leye: 2,reye: 2,mouth: 3,cheek: 0,during:  1},
            {leye: 2,reye: 2,mouth: 6,cheek: 0,during:  2},
            {leye: 2,reye: 2,mouth: 3,cheek: 0,during:  9},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,during:  1},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,during:  2},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,during:  1},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,during:  7},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,during:  3},
            {leye: 4,reye: 4,mouth: 6,cheek: 2,during:  1},
            {leye: 4,reye: 4,mouth: 3,cheek: 2,during:  2},
            {leye: 4,reye: 4,mouth: 6,cheek: 2,during:  1},
            {leye: 4,reye: 4,mouth: 3,cheek: 2,during:  2},
            {leye: 4,reye: 4,mouth: 6,cheek: 2,during:  3},
            {leye: 4,reye: 4,mouth: 3,cheek: 2,during:  1},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,during:  1},
        ]
    },
    {
        id:'vo_na_m0209_0002',
        text:'我是......称职的学院偶像吗?',
        faces:[
            {leye: 1,reye: 1,mouth: 3,cheek: 0,during:  1},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,during:  3},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,during:  1},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,during:  2},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,during:  7},
            {leye: 6,reye: 6,mouth: 3,cheek: 0,during:  2},
            {leye: 6,reye: 6,mouth: 6,cheek: 0,during:  3},
            {leye: 6,reye: 6,mouth: 3,cheek: 0,during:  3},
            {leye: 6,reye: 6,mouth: 6,cheek: 0,during:  2},
            {leye: 6,reye: 6,mouth: 3,cheek: 0,during:  2},
            {leye: 6,reye: 6,mouth: 6,cheek: 0,during:  5},
            {leye: 6,reye: 6,mouth: 3,cheek: 0,during:  3},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,during:  4},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,during:  1},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,during:  2},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,during:  3},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,during:  1},
        ]
    },
    {
        id:'vo_na_m0209_0003',
        text:'一摸到电脑,就会觉得安心很多~',
        faces:[
            {leye: 1,reye: 1,mouth: 3,cheek: 0,during:  1},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,during:  1},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,during:  1},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,during:  1},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,during:  1},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,during:  3},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,during:  2},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,during:  2},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,during:  2},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,during:  2},
            {leye: 1,reye: 1,mouth: 4,cheek: 0,during:  1},
            {leye: 1,reye: 1,mouth: 1,cheek: 0,during:  1},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,during:  1},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,during:  1},
            {leye: 4,reye: 4,mouth: 3,cheek: 0,during:  1},
            {leye: 4,reye: 4,mouth: 6,cheek: 0,during:  3},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,during:  2},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,during:  1},
        ]
    },
    {
        id:'vo_na_m0209_0004',
        text:'感觉最近和你亲近了不少......真开心~',
        faces:[
            {leye: 1,reye: 1,mouth: 3,cheek: 0,during:  3},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,during:  2},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,during:  8},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,during:  4},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,during:  1},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,during:  2},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,during:  2},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,during:  4},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,during:  3},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,during:  1},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,during:  1},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,during:  3},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,during:  3},
            {leye: 4,reye: 4,mouth: 3,cheek: 2,during:  6},
            {leye: 4,reye: 4,mouth: 6,cheek: 2,during:  2},
            {leye: 4,reye: 4,mouth: 3,cheek: 2,during:  1},
            {leye: 4,reye: 4,mouth: 6,cheek: 2,during:  2},
            {leye: 4,reye: 4,mouth: 3,cheek: 2,during:  6},
            {leye: 4,reye: 4,mouth: 6,cheek: 2,during:  6},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,during:  3},
        ]
    },
    {
        id:'vo_na_m0209_0005',
        text:'我最近跳舞进步了一点,但是还是学不会小跳步.哎你别笑我啊!',
        faces:[
            {leye: 1,reye: 1,mouth: 3,cheek: 0,during:  1},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,during:  2},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,during:  1},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,during:  2},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,during:  2},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,during:  1},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,during:  2},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,during:  1},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,during:  1},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,during:  7},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,during:  2},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,during:  1},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,during:  1},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,during:  1},
            {leye: 5,reye:17,mouth: 3,cheek: 0,during:  8},
            {leye: 5,reye:17,mouth: 6,cheek: 0,during:  1},
            {leye: 5,reye:17,mouth: 3,cheek: 0,during:  1},
            {leye: 5,reye:17,mouth: 6,cheek: 0,during:  6},
            {leye: 5,reye:17,mouth: 3,cheek: 0,during:  7},
            {leye:11,reye:11,mouth: 3,cheek: 2,during:  3},
            {leye:11,reye:11,mouth: 6,cheek: 2,during:  1},
            {leye:11,reye:11,mouth: 3,cheek: 2,during:  3},
            {leye:11,reye:11,mouth: 6,cheek: 2,during:  8},
            {leye:11,reye:11,mouth: 3,cheek: 2,during:  3},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,during:  1},
        ]
    },
    {
        id:'vo_na_m0209_0006',
        text:'对了,你觉得什么样的璃奈板比较方便呢?',
        faces:[
            {leye: 1,reye: 1,mouth: 3,cheek: 0,during:  2},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,during:  2},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,during:  4},
            {leye: 2,reye: 2,mouth: 3,cheek: 0,during:  1},
            {leye: 2,reye: 2,mouth: 6,cheek: 0,during:  4},
            {leye: 2,reye: 2,mouth: 3,cheek: 0,during:  1},
            {leye: 2,reye: 2,mouth: 6,cheek: 0,during:  5},
            {leye: 2,reye: 2,mouth: 3,cheek: 0,during:  3},
            {leye: 2,reye: 2,mouth: 6,cheek: 0,during:  1},
            {leye: 2,reye: 2,mouth: 3,cheek: 0,during:  1},
            {leye: 2,reye: 2,mouth: 6,cheek: 0,during:  1},
            {leye: 9,reye:10,mouth: 6,cheek: 0,during:  1},
            {leye: 9,reye:10,mouth: 3,cheek: 0,during:  1},
            {leye: 9,reye:10,mouth: 6,cheek: 0,during:  2},
            {leye: 9,reye:10,mouth: 3,cheek: 0,during:  1},
            {leye: 9,reye:10,mouth: 6,cheek: 0,during:  1},
            {leye: 9,reye:10,mouth: 3,cheek: 0,during:  2},
            {leye: 9,reye:10,mouth: 6,cheek: 0,during:  5},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,during:  2},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,during:  1},
        ]
    },
    {
        id:'vo_na_m0209_0007',
        text:'一起来看学园偶像的影片吧?',
        faces:[
            {leye: 1,reye: 1,mouth: 3,cheek: 0,during:  2},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,during:  4},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,during:  6},
            {leye: 2,reye: 2,mouth: 3,cheek: 0,during:  2},
            {leye: 2,reye: 2,mouth: 6,cheek: 0,during:  9},
            {leye: 2,reye: 2,mouth: 3,cheek: 0,during:  2},
            {leye: 2,reye: 2,mouth: 6,cheek: 0,during:  1},
            {leye: 2,reye: 2,mouth: 3,cheek: 0,during:  1},
            {leye: 2,reye: 2,mouth: 6,cheek: 0,during:  1},
            {leye: 2,reye: 2,mouth: 3,cheek: 0,during:  4},
            {leye:18,reye:18,mouth: 3,cheek: 0,during:  3},
            {leye:18,reye:18,mouth: 6,cheek: 0,during:  3},
            {leye:18,reye:18,mouth: 3,cheek: 0,during:  1},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,during:  2},
        ]
    },
]

window.RINA_VOICE_DATA = voice_data;

const music_data=[
    {id:'none',name:'未选择',singer:'未选择',text:'选一首你想要播放的歌曲吧!',faces:[{leye:1,reye:1,mouth:3,cheek:0,frame:0},{leye:1,reye:1,mouth:3,cheek:0,frame:1},]},
    {
        id:'music_02_09_02_00_1',
        name:'Teletelepathy',
        cover_src:'https://www.738ngx.site/api/rinachanboard/images/cover/music_02_09_02.png',
        music_src:'https://www.738ngx.site/api/rinachanboard/musics/music_02_09_02_1.mp3',
        singer:'天王寺璃奈(田中ちえ美)',
        text:  'テレテレパシー是虹咲学园学园偶像同好会第二张专辑《Love U my friends》收录曲之一，由天王寺璃奈演唱，发售于2019年10月2日。本曲在虹咲TV动画二期第13话用作插曲。',
        faces:[
            {"leye":6,"reye":6,"mouth":3,"cheek":0,"frame":0},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":55},
            {"leye":1,"reye":4,"mouth":7,"cheek":2,"frame":115},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":120},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":131},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":134},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":136},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":137},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":140},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":144},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":149},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":150},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":151},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":153},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":154},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":157},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":159},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":160},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":161},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":162},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":168},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":169},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":170},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":172},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":173},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":174},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":176},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":177},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":178},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":179},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":182},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":183},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":185},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":186},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":187},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":188},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":189},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":190},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":192},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":193},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":194},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":198},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":199},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":200},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":202},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":203},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":204},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":205},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":207},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":209},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":214},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":217},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":219},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":220},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":221},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":222},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":225},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":229},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":236},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":237},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":238},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":239},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":241},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":242},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":243},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":244},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":247},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":248},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":249},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":253},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":254},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":255},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":256},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":259},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":261},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":262},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":263},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":264},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":266},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":267},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":273},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":276},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":278},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":280},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":281},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":282},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":284},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":287},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":289},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":292},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":295},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":310},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":311},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":320},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":396},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":397},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":399},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":401},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":403},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":405},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":406},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":407},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":408},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":409},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":412},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":413},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":414},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":416},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":417},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":418},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":419},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":422},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":424},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":426},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":427},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":428},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":429},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":431},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":432},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":436},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":438},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":440},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":443},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":444},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":445},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":446},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":447},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":448},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":449},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":450},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":451},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":452},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":454},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":455},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":457},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":458},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":459},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":463},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":464},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":465},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":466},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":467},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":469},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":470},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":475},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":476},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":477},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":478},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":479},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":481},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":482},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":483},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":485},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":486},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":489},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":490},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":494},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":495},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":496},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":498},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":501},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":502},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":503},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":504},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":505},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":506},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":507},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":509},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":511},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":513},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":516},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":517},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":518},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":520},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":526},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":529},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":532},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":533},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":534},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":536},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":537},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":538},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":539},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":540},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":542},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":543},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":544},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":545},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":546},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":551},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":555},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":556},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":557},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":559},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":560},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":562},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":565},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":566},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":567},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":568},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":569},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":571},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":572},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":573},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":574},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":575},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":578},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":579},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":580},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":582},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":583},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":584},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":585},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":586},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":587},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":589},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":595},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":596},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":597},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":598},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":601},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":602},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":603},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":609},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":610},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":611},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":612},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":613},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":614},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":615},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":618},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":619},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":621},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":622},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":627},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":629},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":631},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":632},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":638},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":639},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":641},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":642},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":643},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":647},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":648},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":649},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":650},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":651},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":664},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":677},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":678},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":682},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":683},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":684},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":685},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":689},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":690},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":691},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":692},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":693},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":694},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":695},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":697},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":698},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":700},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":701},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":703},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":706},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":707},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":709},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":714},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":715},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":717},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":718},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":719},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":720},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":722},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":723},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":724},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":726},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":727},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":728},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":730},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":731},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":733},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":734},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":735},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":736},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":738},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":739},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":740},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":744},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":746},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":749},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":752},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":753},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":754},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":755},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":759},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":762},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":763},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":764},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":765},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":766},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":772},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":773},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":775},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":777},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":778},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":781},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":782},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":783},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":784},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":785},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":786},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":789},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":790},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":793},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":794},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":797},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":798},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":799},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":800},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":801},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":802},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":803},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":807},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":809},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":813},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":815},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":816},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":817},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":818},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":819},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":820},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":822},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":823},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":827},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":829},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":832},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":834},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":835},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":838},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":839},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":840},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":841},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":842},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":843},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":844},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":847},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":848},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":849},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":850},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":851},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":852},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":853},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":854},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":855},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":856},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":859},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":860},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":861},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":862},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":863},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":864},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":867},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":868},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":869},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":870},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":871},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":873},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":875},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":877},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":878},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":879},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":880},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":881},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":882},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":885},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":886},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":887},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":891},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":896},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":898},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":899},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":901},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":903},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":908},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":909},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":910},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":913},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":915},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":916},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":917},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":918},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":921},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":923},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":925},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":926},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":927},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":928},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":932},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":933},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":934},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":935},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":936},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":938},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":942},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":943},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":951},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":952},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":953},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":956},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":958},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":960},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":961},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":962},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":964},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":965},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":966},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":967},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":968},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":970},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":990},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":993},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":999},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1077},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1078},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1079},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1081},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1082},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1083},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1084},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1085},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1086},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1088},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1089},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1090},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1092},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1094},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1095},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1099},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1100},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1101},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1103},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1106},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":1107},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1108},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1110},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1111},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1113},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1114},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1115},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1116},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1118},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1119},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1120},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1121},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1122},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1124},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1125},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1127},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1128},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1129},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1130},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1132},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1133},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1134},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1136},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1137},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1138},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1139},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1140},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1141},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1143},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1144},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1146},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1147},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1148},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1150},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1154},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1156},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1157},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1158},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1159},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1160},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1161},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1164},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1165},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1166},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1167},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1168},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1172},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1174},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1175},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1177},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1180},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1181},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1183},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1184},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1185},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1187},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1189},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1192},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1204},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1207},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1209},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1210},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1212},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1214},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1218},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1220},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1221},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1222},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1224},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1227},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1228},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1231},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1232},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1233},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1236},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1237},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1238},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1239},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1241},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1242},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1243},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1245},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1246},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1247},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1249},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1250},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1251},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1252},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1255},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1256},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1257},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1258},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1260},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1261},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1262},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1266},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1267},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1268},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1271},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1272},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1274},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1275},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1277},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1281},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1288},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1289},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1290},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1292},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1293},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1294},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1296},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1297},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1299},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1300},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1303},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1304},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1305},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1306},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1307},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1310},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1311},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1316},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1317},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1318},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1322},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1326},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1327},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1328},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1329},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1330},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1332},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1342},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1344},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1356},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1357},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1358},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1361},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1363},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1364},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1368},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1369},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1370},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1373},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1374},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1375},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1376},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1379},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1380},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1382},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1384},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1385},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1386},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1387},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1388},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1389},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1390},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1393},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1394},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1395},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1396},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1397},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1398},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1399},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1400},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1401},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1402},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1404},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1406},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1408},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1409},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1410},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1411},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1412},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1413},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1414},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1415},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1417},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1418},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1419},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1422},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1423},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1425},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1426},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1431},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1432},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1433},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1434},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1436},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1439},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1440},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1444},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1445},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1446},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1447},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1448},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1452},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1453},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1454},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1455},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1456},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1460},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1461},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1464},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1465},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":1468},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1469},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1471},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1472},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1473},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1478},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1479},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1480},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1485},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1489},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1492},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1493},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1494},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1495},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1496},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1497},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1500},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1502},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1505},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1506},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1508},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1509},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1512},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1513},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1514},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1517},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1520},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1522},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1524},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1526},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1527},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1528},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1530},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1533},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1534},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1537},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1538},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1539},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1541},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1542},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1543},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1544},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1545},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1546},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1547},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1550},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":1551},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1552},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":1554},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1555},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1557},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1558},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1561},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1562},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1563},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1564},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1565},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1570},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1575},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":1576},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1577},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1580},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1583},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1586},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1587},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1588},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1589},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":1592},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1593},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1597},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1600},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1601},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1604},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1605},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1606},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1607},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1608},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1610},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1611},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1612},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1613},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1614},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1618},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1621},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1622},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1627},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1628},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1629},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1630},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1631},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1633},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1635},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1638},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1639},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1640},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1641},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1644},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1645},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1647},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1649},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1654},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1657},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1660},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1661},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1664},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1665},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1666},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1669},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1670},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1671},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1674},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1675},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1676},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1677},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1681},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1682},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1685},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1686},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1688},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1690},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1693},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1694},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1695},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1696},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1698},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1702},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1703},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1704},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1707},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1709},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1710},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1711},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1712},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1713},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1714},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1715},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1717},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1718},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1719},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1721},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1722},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1725},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1726},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1728},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1730},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1732},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1733},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1734},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1737},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1738},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1740},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1741},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1743},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1745},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1746},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1749},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1750},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1753},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1757},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1758},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1760},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1761},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1766},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1767},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1769},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1771},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1777},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1779},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1780},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1781},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1790},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1791},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1801},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1802},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":1804},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1805},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1806},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1807},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1808},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1809},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1810},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1811},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1812},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1815},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1816},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1822},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1825},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1827},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1828},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1829},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1830},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1834},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1835},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1837},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1838},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1839},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1841},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1843},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1845},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1847},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1848},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1850},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1851},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1853},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1856},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1857},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1862},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1864},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1865},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1866},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1867},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1869},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1870},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1871},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1872},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1873},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":1874},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1875},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1876},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1879},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1880},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1882},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1885},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1886},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1887},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1888},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1889},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1891},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1893},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1895},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1898},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1899},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":1905},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1907},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1908},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1910},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1911},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1913},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1914},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1915},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1916},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1918},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1920},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1921},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":1922},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1924},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1926},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1927},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1928},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1930},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1932},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1934},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1935},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1936},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":1938},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1939},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1940},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1944},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1945},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1947},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":1948},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1949},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1952},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1953},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1960},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1961},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1962},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1963},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1964},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1966},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1968},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1969},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1972},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1973},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1976},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1977},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1978},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1980},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1981},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":1983},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1986},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1988},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2018},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2021},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2023},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":2024},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2025},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2026},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2030},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2031},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2032},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2034},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2035},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2036},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2037},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2039},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2040},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2042},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":2043},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2044},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2045},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2047},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2048},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2050},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2051},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2052},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2054},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2055},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2056},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2057},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2060},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2063},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2064},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2065},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2067},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2068},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2069},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2071},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2072},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2073},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2074},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2075},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":2076},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2077},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2079},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2080},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2081},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2085},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2087},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2092},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2095},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2096},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2097},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2099},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2100},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2101},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2102},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2104},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2105},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2106},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2107},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":2109},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2110},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2111},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2112},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2114},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2115},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2116},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":2120},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2123},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":2125},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2126},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2128},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2130},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2131},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2134},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2135},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2143},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2144},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2148},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2150},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2151},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2152},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2154},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2157},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2158},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2159},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2161},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2162},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2164},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2165},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2166},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2168},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2169},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2170},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2175},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2176},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2179},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2180},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2181},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2182},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2184},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2185},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":2186},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2188},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2189},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2190},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2191},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2192},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2193},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2195},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2196},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2197},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2198},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2202},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2204},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2205},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2207},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2208},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2209},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2210},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2212},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2213},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2214},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":2216},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2217},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2218},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2219},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":2220},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2221},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2222},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":2223},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2226},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2227},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2228},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2229},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2233},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2234},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2235},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2237},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":2238},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2239},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2240},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2241},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2245},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2248},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2250},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2251},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2254},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":2255},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2256},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2258},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2259},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2262},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2263},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2264},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2265},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2266},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2268},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2271},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2272},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2275},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2279},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2283},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2284},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2285},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2289},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2290},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2294},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2295},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2296},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2300},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":2301},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2302},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2305},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2306},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2308},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2310},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2311},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2315},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2317},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2330},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2334},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2335},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2336},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2337},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2338},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2339},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2348},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":2349},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":2460},
        ]
    },
    {
        id:'music_02_09_04_00_1',
        name:'相连的Connect',
        cover_src:'https://www.738ngx.site/api/rinachanboard/images/cover/music_02_09_04.png',
        music_src:'https://www.738ngx.site/api/rinachanboard/musics/music_02_09_04_1.mp3',
        singer:'天王寺璃奈(田中ちえ美)',
        text:  'ツナガルコネクト是《LoveLive!虹咲学园学园偶像同好会》动画第一季第六集的插入曲，由天王寺璃奈演唱。歌曲收录于动画第一季第二张插入曲单曲《サイコーハート / La Bella Patria / ツナガルコネクト》中，发售于2020年12月2日。',
        faces:[
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":0},
            {"leye":6,"reye":6,"mouth":3,"cheek":0,"frame":30},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":32},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":35},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":36},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":37},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":39},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":41},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":44},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":45},
            {"leye":4,"reye":4,"mouth":6,"cheek":3,"frame":46},
            {"leye":4,"reye":4,"mouth":3,"cheek":3,"frame":47},
            {"leye":4,"reye":4,"mouth":9,"cheek":3,"frame":48},
            {"leye":4,"reye":4,"mouth":6,"cheek":3,"frame":49},
            {"leye":4,"reye":4,"mouth":12,"cheek":3,"frame":50},
            {"leye":4,"reye":4,"mouth":17,"cheek":3,"frame":51},
            {"leye":4,"reye":4,"mouth":6,"cheek":3,"frame":52},
            {"leye":4,"reye":4,"mouth":3,"cheek":3,"frame":54},
            {"leye":4,"reye":4,"mouth":6,"cheek":3,"frame":55},
            {"leye":2,"reye":2,"mouth":6,"cheek":2,"frame":62},
            {"leye":2,"reye":2,"mouth":12,"cheek":2,"frame":66},
            {"leye":2,"reye":2,"mouth":6,"cheek":2,"frame":67},
            {"leye":1,"reye":1,"mouth":9,"cheek":2,"frame":71},
            {"leye":1,"reye":1,"mouth":17,"cheek":2,"frame":72},
            {"leye":1,"reye":1,"mouth":6,"cheek":2,"frame":73},
            {"leye":1,"reye":1,"mouth":9,"cheek":2,"frame":76},
            {"leye":1,"reye":1,"mouth":6,"cheek":2,"frame":77},
            {"leye":1,"reye":1,"mouth":9,"cheek":2,"frame":83},
            {"leye":19,"reye":19,"mouth":10,"cheek":3,"frame":85},
            {"leye":19,"reye":19,"mouth":6,"cheek":3,"frame":86},
            {"leye":19,"reye":19,"mouth":12,"cheek":3,"frame":88},
            {"leye":2,"reye":2,"mouth":6,"cheek":2,"frame":90},
            {"leye":2,"reye":2,"mouth":12,"cheek":2,"frame":92},
            {"leye":4,"reye":4,"mouth":6,"cheek":2,"frame":94},
            {"leye":4,"reye":4,"mouth":12,"cheek":2,"frame":95},
            {"leye":4,"reye":4,"mouth":6,"cheek":2,"frame":96},
            {"leye":4,"reye":4,"mouth":12,"cheek":2,"frame":97},
            {"leye":4,"reye":4,"mouth":6,"cheek":2,"frame":98},
            {"leye":4,"reye":4,"mouth":17,"cheek":2,"frame":103},
            {"leye":4,"reye":4,"mouth":6,"cheek":2,"frame":104},
            {"leye":4,"reye":4,"mouth":10,"cheek":2,"frame":107},
            {"leye":4,"reye":4,"mouth":17,"cheek":2,"frame":109},
            {"leye":1,"reye":1,"mouth":6,"cheek":2,"frame":111},
            {"leye":1,"reye":1,"mouth":10,"cheek":2,"frame":112},
            {"leye":1,"reye":1,"mouth":17,"cheek":2,"frame":114},
            {"leye":1,"reye":1,"mouth":6,"cheek":2,"frame":115},
            {"leye":1,"reye":1,"mouth":12,"cheek":2,"frame":121},
            {"leye":1,"reye":1,"mouth":6,"cheek":2,"frame":123},
            {"leye":1,"reye":1,"mouth":9,"cheek":2,"frame":131},
            {"leye":19,"reye":19,"mouth":6,"cheek":2,"frame":132},
            {"leye":19,"reye":19,"mouth":17,"cheek":2,"frame":140},
            {"leye":19,"reye":19,"mouth":6,"cheek":2,"frame":141},
            {"leye":2,"reye":2,"mouth":17,"cheek":2,"frame":144},
            {"leye":2,"reye":2,"mouth":6,"cheek":2,"frame":145},
            {"leye":2,"reye":2,"mouth":17,"cheek":2,"frame":147},
            {"leye":6,"reye":6,"mouth":6,"cheek":0,"frame":149},
            {"leye":6,"reye":6,"mouth":6,"cheek":0,"frame":153},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":154},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":155},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":157},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":159},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":161},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":162},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":163},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":165},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":166},
            {"leye":4,"reye":4,"mouth":17,"cheek":0,"frame":167},
            {"leye":4,"reye":4,"mouth":9,"cheek":0,"frame":168},
            {"leye":4,"reye":4,"mouth":6,"cheek":0,"frame":170},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":198},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":202},
            {"leye":6,"reye":6,"mouth":6,"cheek":0,"frame":204},
            {"leye":6,"reye":6,"mouth":3,"cheek":0,"frame":206},
            {"leye":5,"reye":5,"mouth":6,"cheek":0,"frame":207},
            {"leye":5,"reye":5,"mouth":12,"cheek":0,"frame":209},
            {"leye":5,"reye":5,"mouth":6,"cheek":0,"frame":210},
            {"leye":5,"reye":5,"mouth":12,"cheek":0,"frame":211},
            {"leye":5,"reye":5,"mouth":6,"cheek":0,"frame":213},
            {"leye":5,"reye":5,"mouth":12,"cheek":0,"frame":214},
            {"leye":5,"reye":5,"mouth":17,"cheek":0,"frame":217},
            {"leye":5,"reye":5,"mouth":6,"cheek":0,"frame":218},
            {"leye":4,"reye":4,"mouth":17,"cheek":0,"frame":219},
            {"leye":4,"reye":4,"mouth":9,"cheek":0,"frame":220},
            {"leye":4,"reye":4,"mouth":10,"cheek":0,"frame":221},
            {"leye":4,"reye":4,"mouth":17,"cheek":0,"frame":224},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":225},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":229},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":230},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":233},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":238},
            {"leye":6,"reye":6,"mouth":6,"cheek":0,"frame":240},
            {"leye":6,"reye":6,"mouth":17,"cheek":0,"frame":242},
            {"leye":6,"reye":6,"mouth":12,"cheek":0,"frame":243},
            {"leye":6,"reye":6,"mouth":6,"cheek":0,"frame":244},
            {"leye":6,"reye":6,"mouth":15,"cheek":0,"frame":247},
            {"leye":6,"reye":6,"mouth":6,"cheek":0,"frame":252},
            {"leye":5,"reye":5,"mouth":12,"cheek":0,"frame":255},
            {"leye":4,"reye":4,"mouth":6,"cheek":0,"frame":257},
            {"leye":6,"reye":6,"mouth":12,"cheek":0,"frame":259},
            {"leye":6,"reye":6,"mouth":6,"cheek":0,"frame":260},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":264},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":265},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":266},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":268},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":269},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":272},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":273},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":275},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":276},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":278},
            {"leye":6,"reye":6,"mouth":10,"cheek":0,"frame":279},
            {"leye":6,"reye":6,"mouth":6,"cheek":0,"frame":280},
            {"leye":5,"reye":17,"mouth":12,"cheek":0,"frame":281},
            {"leye":5,"reye":17,"mouth":9,"cheek":0,"frame":287},
            {"leye":5,"reye":17,"mouth":6,"cheek":0,"frame":288},
            {"leye":5,"reye":17,"mouth":12,"cheek":0,"frame":289},
            {"leye":5,"reye":17,"mouth":6,"cheek":0,"frame":293},
            {"leye":5,"reye":17,"mouth":12,"cheek":0,"frame":295},
            {"leye":5,"reye":17,"mouth":17,"cheek":0,"frame":296},
            {"leye":5,"reye":17,"mouth":6,"cheek":0,"frame":297},
            {"leye":5,"reye":17,"mouth":12,"cheek":0,"frame":301},
            {"leye":5,"reye":17,"mouth":6,"cheek":0,"frame":302},
            {"leye":5,"reye":17,"mouth":12,"cheek":0,"frame":306},
            {"leye":4,"reye":4,"mouth":6,"cheek":0,"frame":307},
            {"leye":4,"reye":4,"mouth":12,"cheek":0,"frame":309},
            {"leye":4,"reye":4,"mouth":10,"cheek":0,"frame":310},
            {"leye":4,"reye":4,"mouth":6,"cheek":0,"frame":311},
            {"leye":4,"reye":4,"mouth":9,"cheek":0,"frame":312},
            {"leye":6,"reye":6,"mouth":6,"cheek":0,"frame":314},
            {"leye":6,"reye":6,"mouth":17,"cheek":0,"frame":315},
            {"leye":5,"reye":17,"mouth":9,"cheek":0,"frame":316},
            {"leye":5,"reye":17,"mouth":6,"cheek":0,"frame":317},
            {"leye":5,"reye":17,"mouth":9,"cheek":0,"frame":318},
            {"leye":5,"reye":17,"mouth":10,"cheek":0,"frame":319},
            {"leye":5,"reye":17,"mouth":9,"cheek":0,"frame":320},
            {"leye":5,"reye":17,"mouth":6,"cheek":0,"frame":321},
            {"leye":5,"reye":17,"mouth":9,"cheek":0,"frame":322},
            {"leye":5,"reye":17,"mouth":12,"cheek":0,"frame":323},
            {"leye":5,"reye":17,"mouth":6,"cheek":0,"frame":327},
            {"leye":5,"reye":17,"mouth":9,"cheek":0,"frame":328},
            {"leye":9,"reye":10,"mouth":6,"cheek":0,"frame":329},
            {"leye":9,"reye":10,"mouth":17,"cheek":0,"frame":334},
            {"leye":9,"reye":10,"mouth":12,"cheek":0,"frame":336},
            {"leye":9,"reye":10,"mouth":9,"cheek":0,"frame":340},
            {"leye":9,"reye":10,"mouth":6,"cheek":0,"frame":341},
            {"leye":9,"reye":10,"mouth":12,"cheek":0,"frame":342},
            {"leye":9,"reye":10,"mouth":17,"cheek":0,"frame":344},
            {"leye":9,"reye":10,"mouth":6,"cheek":0,"frame":348},
            {"leye":6,"reye":6,"mouth":12,"cheek":0,"frame":349},
            {"leye":6,"reye":6,"mouth":9,"cheek":0,"frame":350},
            {"leye":4,"reye":4,"mouth":17,"cheek":3,"frame":351},
            {"leye":4,"reye":4,"mouth":9,"cheek":3,"frame":353},
            {"leye":4,"reye":4,"mouth":17,"cheek":3,"frame":354},
            {"leye":4,"reye":4,"mouth":12,"cheek":3,"frame":355},
            {"leye":4,"reye":4,"mouth":6,"cheek":3,"frame":356},
            {"leye":4,"reye":4,"mouth":9,"cheek":3,"frame":360},
            {"leye":4,"reye":4,"mouth":17,"cheek":3,"frame":361},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":362},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":363},
            {"leye":6,"reye":6,"mouth":6,"cheek":0,"frame":364},
            {"leye":6,"reye":6,"mouth":12,"cheek":0,"frame":365},
            {"leye":6,"reye":6,"mouth":3,"cheek":0,"frame":368},
            {"leye":11,"reye":11,"mouth":6,"cheek":0,"frame":369},
            {"leye":11,"reye":11,"mouth":12,"cheek":0,"frame":371},
            {"leye":11,"reye":11,"mouth":6,"cheek":0,"frame":372},
            {"leye":11,"reye":11,"mouth":12,"cheek":0,"frame":377},
            {"leye":11,"reye":11,"mouth":6,"cheek":0,"frame":379},
            {"leye":11,"reye":11,"mouth":9,"cheek":2,"frame":381},
            {"leye":11,"reye":11,"mouth":6,"cheek":2,"frame":382},
            {"leye":11,"reye":11,"mouth":12,"cheek":2,"frame":385},
            {"leye":11,"reye":11,"mouth":6,"cheek":2,"frame":386},
            {"leye":11,"reye":11,"mouth":10,"cheek":2,"frame":387},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":389},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":390},
            {"leye":19,"reye":19,"mouth":17,"cheek":0,"frame":392},
            {"leye":19,"reye":19,"mouth":6,"cheek":0,"frame":395},
            {"leye":19,"reye":19,"mouth":12,"cheek":0,"frame":396},
            {"leye":19,"reye":19,"mouth":6,"cheek":0,"frame":401},
            {"leye":5,"reye":5,"mouth":12,"cheek":0,"frame":404},
            {"leye":5,"reye":5,"mouth":9,"cheek":0,"frame":405},
            {"leye":5,"reye":5,"mouth":6,"cheek":0,"frame":406},
            {"leye":5,"reye":5,"mouth":17,"cheek":0,"frame":407},
            {"leye":5,"reye":5,"mouth":6,"cheek":0,"frame":408},
            {"leye":5,"reye":5,"mouth":17,"cheek":0,"frame":409},
            {"leye":5,"reye":5,"mouth":10,"cheek":0,"frame":410},
            {"leye":5,"reye":5,"mouth":12,"cheek":0,"frame":411},
            {"leye":7,"reye":8,"mouth":6,"cheek":0,"frame":412},
            {"leye":7,"reye":8,"mouth":3,"cheek":0,"frame":414},
            {"leye":7,"reye":8,"mouth":6,"cheek":0,"frame":415},
            {"leye":4,"reye":2,"mouth":17,"cheek":0,"frame":424},
            {"leye":4,"reye":2,"mouth":6,"cheek":0,"frame":425},
            {"leye":4,"reye":2,"mouth":12,"cheek":0,"frame":427},
            {"leye":4,"reye":2,"mouth":6,"cheek":0,"frame":428},
            {"leye":2,"reye":4,"mouth":12,"cheek":0,"frame":430},
            {"leye":2,"reye":4,"mouth":17,"cheek":0,"frame":431},
            {"leye":2,"reye":4,"mouth":6,"cheek":0,"frame":433},
            {"leye":2,"reye":4,"mouth":17,"cheek":0,"frame":435},
            {"leye":2,"reye":4,"mouth":6,"cheek":0,"frame":436},
            {"leye":2,"reye":4,"mouth":12,"cheek":0,"frame":439},
            {"leye":2,"reye":4,"mouth":9,"cheek":0,"frame":441},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":442},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":444},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":445},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":447},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":449},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":451},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":452},
            {"leye":6,"reye":6,"mouth":12,"cheek":0,"frame":454},
            {"leye":6,"reye":6,"mouth":6,"cheek":0,"frame":456},
            {"leye":6,"reye":6,"mouth":12,"cheek":0,"frame":457},
            {"leye":6,"reye":6,"mouth":17,"cheek":0,"frame":458},
            {"leye":6,"reye":6,"mouth":9,"cheek":0,"frame":460},
            {"leye":6,"reye":6,"mouth":17,"cheek":0,"frame":461},
            {"leye":6,"reye":6,"mouth":6,"cheek":0,"frame":462},
            {"leye":6,"reye":6,"mouth":12,"cheek":0,"frame":463},
            {"leye":6,"reye":6,"mouth":6,"cheek":0,"frame":464},
            {"leye":6,"reye":6,"mouth":12,"cheek":0,"frame":466},
            {"leye":6,"reye":6,"mouth":6,"cheek":0,"frame":467},
            {"leye":6,"reye":6,"mouth":12,"cheek":0,"frame":470},
            {"leye":2,"reye":2,"mouth":6,"cheek":3,"frame":471},
            {"leye":2,"reye":2,"mouth":12,"cheek":3,"frame":472},
            {"leye":2,"reye":2,"mouth":6,"cheek":3,"frame":473},
            {"leye":2,"reye":2,"mouth":9,"cheek":3,"frame":474},
            {"leye":2,"reye":2,"mouth":6,"cheek":3,"frame":475},
            {"leye":2,"reye":2,"mouth":17,"cheek":3,"frame":476},
            {"leye":2,"reye":2,"mouth":12,"cheek":3,"frame":480},
            {"leye":2,"reye":2,"mouth":9,"cheek":3,"frame":481},
            {"leye":2,"reye":2,"mouth":6,"cheek":3,"frame":482},
            {"leye":2,"reye":2,"mouth":9,"cheek":3,"frame":484},
            {"leye":2,"reye":2,"mouth":6,"cheek":3,"frame":488},
            {"leye":2,"reye":2,"mouth":9,"cheek":3,"frame":492},
            {"leye":2,"reye":2,"mouth":6,"cheek":3,"frame":494},
            {"leye":2,"reye":2,"mouth":9,"cheek":3,"frame":516},
            {"leye":2,"reye":2,"mouth":17,"cheek":3,"frame":517},
            {"leye":2,"reye":2,"mouth":6,"cheek":3,"frame":518},
            {"leye":2,"reye":2,"mouth":17,"cheek":3,"frame":520},
            {"leye":4,"reye":4,"mouth":12,"cheek":0,"frame":522},
            {"leye":4,"reye":4,"mouth":6,"cheek":0,"frame":525},
            {"leye":4,"reye":4,"mouth":3,"cheek":0,"frame":528},
            {"leye":4,"reye":4,"mouth":9,"cheek":0,"frame":529},
            {"leye":4,"reye":4,"mouth":6,"cheek":0,"frame":530},
            {"leye":4,"reye":4,"mouth":12,"cheek":0,"frame":544},
            {"leye":4,"reye":4,"mouth":6,"cheek":0,"frame":545},
            {"leye":4,"reye":4,"mouth":12,"cheek":0,"frame":546},
            {"leye":4,"reye":4,"mouth":9,"cheek":0,"frame":550},
            {"leye":4,"reye":4,"mouth":3,"cheek":0,"frame":552},
            {"leye":4,"reye":4,"mouth":17,"cheek":0,"frame":554},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":555},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":556},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":558},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":559},
            {"leye":4,"reye":4,"mouth":9,"cheek":2,"frame":563},
            {"leye":4,"reye":4,"mouth":6,"cheek":2,"frame":564},
            {"leye":4,"reye":4,"mouth":12,"cheek":2,"frame":565},
            {"leye":4,"reye":4,"mouth":6,"cheek":2,"frame":566},
            {"leye":4,"reye":4,"mouth":9,"cheek":2,"frame":568},
            {"leye":4,"reye":4,"mouth":6,"cheek":2,"frame":569},
            {"leye":1,"reye":1,"mouth":12,"cheek":3,"frame":570},
            {"leye":1,"reye":1,"mouth":6,"cheek":3,"frame":572},
            {"leye":1,"reye":1,"mouth":12,"cheek":3,"frame":573},
            {"leye":1,"reye":1,"mouth":6,"cheek":3,"frame":575},
            {"leye":4,"reye":4,"mouth":17,"cheek":3,"frame":578},
            {"leye":4,"reye":4,"mouth":3,"cheek":3,"frame":580},
            {"leye":4,"reye":4,"mouth":6,"cheek":3,"frame":581},
            {"leye":4,"reye":4,"mouth":12,"cheek":3,"frame":582},
            {"leye":4,"reye":4,"mouth":17,"cheek":0,"frame":584},
            {"leye":2,"reye":2,"mouth":12,"cheek":0,"frame":586},
            {"leye":2,"reye":2,"mouth":6,"cheek":0,"frame":588},
            {"leye":2,"reye":2,"mouth":17,"cheek":0,"frame":589},
            {"leye":2,"reye":2,"mouth":6,"cheek":0,"frame":594},
            {"leye":2,"reye":2,"mouth":9,"cheek":0,"frame":596},
            {"leye":6,"reye":6,"mouth":10,"cheek":0,"frame":599},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":602},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":603},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":605},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":606},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":608},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":609},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":611},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":613},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":615},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":616},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":617},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":618},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":624},
            {"leye":6,"reye":6,"mouth":12,"cheek":0,"frame":626},
            {"leye":6,"reye":6,"mouth":6,"cheek":0,"frame":628},
            {"leye":6,"reye":6,"mouth":17,"cheek":0,"frame":629},
            {"leye":6,"reye":6,"mouth":9,"cheek":0,"frame":630},
            {"leye":6,"reye":6,"mouth":17,"cheek":0,"frame":632},
            {"leye":6,"reye":6,"mouth":6,"cheek":0,"frame":633},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":636},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":637},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":638},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":639},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":641},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":642},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":644},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":646},
            {"leye":4,"reye":2,"mouth":6,"cheek":3,"frame":648},
            {"leye":4,"reye":2,"mouth":9,"cheek":3,"frame":649},
            {"leye":4,"reye":2,"mouth":17,"cheek":3,"frame":650},
            {"leye":4,"reye":2,"mouth":6,"cheek":3,"frame":651},
            {"leye":4,"reye":2,"mouth":17,"cheek":3,"frame":653},
            {"leye":4,"reye":2,"mouth":10,"cheek":3,"frame":654},
            {"leye":4,"reye":2,"mouth":6,"cheek":3,"frame":656},
            {"leye":5,"reye":5,"mouth":12,"cheek":3,"frame":662},
            {"leye":5,"reye":5,"mouth":6,"cheek":3,"frame":663},
            {"leye":5,"reye":5,"0mouth":3,"cheek":3,"frame":664},
            {"leye":4,"reye":4,"mouth":6,"cheek":3,"frame":665},
            {"leye":4,"reye":4,"mouth":17,"cheek":3,"frame":666},
            {"leye":4,"reye":4,"mouth":10,"cheek":3,"frame":670},
            {"leye":4,"reye":4,"mouth":9,"cheek":3,"frame":671},
            {"leye":4,"reye":4,"mouth":17,"cheek":3,"frame":672},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":676},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":678},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":679},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":680},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":684},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":685},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":686},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":687},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":688},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":689},
            {"leye":2,"reye":4,"mouth":6,"cheek":3,"frame":690},
            {"leye":2,"reye":4,"mouth":3,"cheek":3,"frame":692},
            {"leye":2,"reye":4,"mouth":9,"cheek":3,"frame":693},
            {"leye":2,"reye":4,"mouth":12,"cheek":3,"frame":694},
            {"leye":2,"reye":4,"mouth":17,"cheek":3,"frame":695},
            {"leye":2,"reye":4,"mouth":12,"cheek":3,"frame":696},
            {"leye":2,"reye":4,"mouth":17,"cheek":3,"frame":699},
            {"leye":2,"reye":4,"mouth":6,"cheek":3,"frame":700},
            {"leye":5,"reye":5,"mouth":9,"cheek":0,"frame":707},
            {"leye":5,"reye":5,"mouth":17,"cheek":0,"frame":708},
            {"leye":5,"reye":5,"mouth":10,"cheek":0,"frame":709},
            {"leye":5,"reye":5,"mouth":12,"cheek":0,"frame":712},
            {"leye":5,"reye":5,"mouth":17,"cheek":0,"frame":713},
            {"leye":5,"reye":5,"mouth":9,"cheek":0,"frame":714},
            {"leye":5,"reye":5,"mouth":6,"cheek":0,"frame":715},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":720},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":722},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":723},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":726},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":727},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":728},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":733},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":734},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":735},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":737},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":738},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":739},
            {"leye":4,"reye":4,"mouth":9,"cheek":3,"frame":741},
            {"leye":4,"reye":4,"mouth":6,"cheek":3,"frame":742},
            {"leye":4,"reye":4,"mouth":12,"cheek":3,"frame":743},
            {"leye":4,"reye":4,"mouth":6,"cheek":3,"frame":744},
            {"leye":4,"reye":4,"mouth":9,"cheek":3,"frame":748},
            {"leye":4,"reye":4,"mouth":12,"cheek":3,"frame":749},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":750},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":752},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":754},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":755},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":756},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":757},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":759},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":761},
            {"leye":6,"reye":6,"mouth":9,"cheek":3,"frame":762},
            {"leye":6,"reye":6,"mouth":6,"cheek":3,"frame":763},
            {"leye":6,"reye":6,"mouth":9,"cheek":3,"frame":767},
            {"leye":6,"reye":6,"mouth":6,"cheek":3,"frame":768},
            {"leye":6,"reye":6,"mouth":12,"cheek":3,"frame":771},
            {"leye":2,"reye":2,"mouth":6,"cheek":2,"frame":772},
            {"leye":2,"reye":2,"mouth":12,"cheek":2,"frame":773},
            {"leye":2,"reye":2,"mouth":6,"cheek":2,"frame":774},
            {"leye":2,"reye":2,"mouth":12,"cheek":2,"frame":776},
            {"leye":2,"reye":2,"mouth":6,"cheek":2,"frame":777},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":782},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":783},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":784},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":785},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":789},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":790},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":791},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":792},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":793},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":794},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":801},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":802},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":807},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":808},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":809},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":810},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":811},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":813},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":814},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":816},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":817},
            {"leye":19,"reye":19,"mouth":6,"cheek":3,"frame":818},
            {"leye":19,"reye":19,"mouth":9,"cheek":3,"frame":823},
            {"leye":19,"reye":19,"mouth":17,"cheek":3,"frame":825},
            {"leye":19,"reye":19,"mouth":12,"cheek":3,"frame":826},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":827},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":829},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":830},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":833},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":834},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":837},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":838},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":842},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":845},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":848},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":849},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":850},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":851},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":852},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":853},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":854},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":855},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":856},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":857},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":860},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":861},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":862},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":863},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":880},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":881},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":882},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":884},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":885},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":888},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":889},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":892},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":893},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":895},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":899},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":900},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":903},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":904},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":908},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":909},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":910},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":926},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":927},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":939},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":940},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":942},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":943},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":946},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":947},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":950},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":952},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":955},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":956},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":957},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":958},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":959},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":960},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":962},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":964},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":965},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":966},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":967},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":970},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":973},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":974},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":976},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":977},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":979},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":981},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":982},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":983},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":985},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":986},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":989},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":991},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":996},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":997},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1001},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1002},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1003},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1004},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1005},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1006},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1009},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1010},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1012},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1015},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1017},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1019},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1022},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1023},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1024},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1025},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1026},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1027},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1028},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1029},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1032},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1033},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1034},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1038},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1044},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1045},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1047},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1048},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1050},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1052},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1055},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1056},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1058},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1059},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1063},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1065},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1067},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1068},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1069},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1072},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1073},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1076},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1077},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1078},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1081},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1082},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1085},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1086},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1087},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":1091},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1092},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1093},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":1094},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1095},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1099},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1100},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1103},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1104},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1105},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1106},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1108},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1109},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1110},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1113},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1114},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1119},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1122},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1124},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1125},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1127},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":1128},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1129},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1130},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1131},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1132},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1135},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1136},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1137},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1139},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1140},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1143},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1144},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1145},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1146},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1147},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":1148},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1149},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1150},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1152},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1157},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1158},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1162},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1163},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":1164},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1165},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1166},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1168},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1172},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1174},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1175},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1177},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1178},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1181},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1185},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1188},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1189},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1191},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1201},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1202},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1207},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1208},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1210},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1211},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1212},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1213},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1216},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1217},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1218},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1220},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1224},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1226},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1228},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1229},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1231},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1232},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1233},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1234},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1238},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1239},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1240},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1241},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1242},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1243},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1245},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1248},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1249},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1258},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1259},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1261},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1264},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1269},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1270},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1271},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1272},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1280},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1284},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1285},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1287},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1288},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1291},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1293},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1294},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1296},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1297},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1298},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1299},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1303},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1304},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1306},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1308},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1310},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1311},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1313},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":1314},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1315},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1316},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1317},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1318},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1320},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1322},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1323},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1327},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":1328},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1329},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1334},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1335},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":1337},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1338},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1343},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1346},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":1347},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1351},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1352},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1353},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1354},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1355},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1357},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1358},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1360},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1361},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1363},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1364},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1366},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1370},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1372},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1374},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1375},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1376},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1377},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1380},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1381},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1386},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1390},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1391},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1393},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1394},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":1395},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1396},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1397},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1404},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1405},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1406},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1407},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1411},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":1412},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1413},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1417},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1419},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1421},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1424},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1425},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1426},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1427},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1430},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1433},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1434},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1435},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1436},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1437},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1439},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1442},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1443},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1444},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1448},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1449},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1450},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1455},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1456},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1460},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1461},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1462},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1464},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":1468},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1469},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1471},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1473},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1475},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1476},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1480},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1481},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1482},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1483},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1484},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1485},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":1486},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1487},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1488},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":1489},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1490},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1491},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1492},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1498},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1499},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1502},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1504},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1507},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1509},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1515},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1516},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1518},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1519},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1521},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1525},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1623},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1626},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1628},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1629},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1638},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1646},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1647},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1648},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1650},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1651},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1652},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1654},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1655},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1656},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1659},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1660},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1661},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1662},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":1665},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1666},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1667},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1669},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1676},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":1678},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1679},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1680},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1683},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1684},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":1685},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1686},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1687},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1689},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1690},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1695},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1696},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1699},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1700},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1701},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1705},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1706},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1707},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1708},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1710},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1711},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1720},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1721},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1723},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1724},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1726},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1728},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":1729},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1730},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1731},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1732},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1733},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1736},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1737},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1760},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1761},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1763},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1766},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1769},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1771},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1779},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1780},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1783},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":1784},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1801},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1835},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1836},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1837},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1839},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1842},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1843},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1844},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1845},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1846},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1847},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1852},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1855},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1857},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1860},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":1861},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1862},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1863},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1864},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1865},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1867},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":1868},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1870},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1872},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1873},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1874},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1876},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1877},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1878},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1879},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1883},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1885},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1887},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1889},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1891},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1892},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1894},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1901},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1902},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1903},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1904},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1905},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1909},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1910},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1911},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1913},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1914},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1915},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":1917},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1918},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1923},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1925},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1926},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1928},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1933},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1934},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1938},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1940},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1942},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1946},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1947},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1948},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1949},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1950},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1953},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1954},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1956},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1957},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1958},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1961},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1963},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1966},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1967},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1970},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1972},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1973},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1978},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1981},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1982},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1983},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1985},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1988},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":1989},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1990},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1991},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":1995},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":1997},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":1999},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2000},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2002},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2003},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2004},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2014},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2015},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":2018},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2019},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2021},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2023},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2024},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2028},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2030},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2034},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2035},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2040},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2041},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2042},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2043},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":2044},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2045},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":2046},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2047},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2051},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2052},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2053},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2054},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2057},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2058},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":2060},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2061},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2063},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2064},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2068},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2069},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2072},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2073},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2074},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2076},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":2077},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2078},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2079},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2085},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2087},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2094},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2095},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2100},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2101},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2104},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2106},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":2108},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2112},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2114},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2115},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2116},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2117},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2119},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2124},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2125},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2133},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2134},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2138},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2139},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2142},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2143},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2146},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2147},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2151},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2152},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2155},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2157},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2158},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2159},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2160},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2163},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2164},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2165},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2167},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":2168},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2169},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":2171},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2172},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2179},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2181},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2193},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2194},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2198},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":2199},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":2205},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":2207},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":2310},
        ]
    },
    {
        id:'music_02_09_04_00_0',
        name:'相连的Connect(Short ver.)',
        cover_src:'https://www.738ngx.site/api/rinachanboard/images/cover/music_02_09_04.png',
        music_src:'https://www.738ngx.site/api/rinachanboard/musics/music_02_09_04_0.mp3',
        singer:'天王寺璃奈(田中ちえ美)',
        text:  'ツナガルコネクト是《LoveLive!虹咲学园学园偶像同好会》动画第一季第六集的插入曲，由天王寺璃奈演唱。歌曲收录于动画第一季第二张插入曲单曲《サイコーハート / La Bella Patria / ツナガルコネクト》中，发售于2020年12月2日。',
        faces:[
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":0},
            {"leye":6,"reye":6,"mouth":3,"cheek":0,"frame":30},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":32},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":35},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":36},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":37},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":39},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":41},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":44},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":45},
            {"leye":4,"reye":4,"mouth":6,"cheek":3,"frame":46},
            {"leye":4,"reye":4,"mouth":3,"cheek":3,"frame":47},
            {"leye":4,"reye":4,"mouth":9,"cheek":3,"frame":48},
            {"leye":4,"reye":4,"mouth":6,"cheek":3,"frame":49},
            {"leye":4,"reye":4,"mouth":12,"cheek":3,"frame":50},
            {"leye":4,"reye":4,"mouth":17,"cheek":3,"frame":51},
            {"leye":4,"reye":4,"mouth":6,"cheek":3,"frame":52},
            {"leye":4,"reye":4,"mouth":3,"cheek":3,"frame":54},
            {"leye":4,"reye":4,"mouth":6,"cheek":3,"frame":55},
            {"leye":2,"reye":2,"mouth":6,"cheek":2,"frame":62},
            {"leye":2,"reye":2,"mouth":12,"cheek":2,"frame":66},
            {"leye":2,"reye":2,"mouth":6,"cheek":2,"frame":67},
            {"leye":1,"reye":1,"mouth":9,"cheek":2,"frame":71},
            {"leye":1,"reye":1,"mouth":17,"cheek":2,"frame":72},
            {"leye":1,"reye":1,"mouth":6,"cheek":2,"frame":73},
            {"leye":1,"reye":1,"mouth":9,"cheek":2,"frame":76},
            {"leye":1,"reye":1,"mouth":6,"cheek":2,"frame":77},
            {"leye":1,"reye":1,"mouth":9,"cheek":2,"frame":83},
            {"leye":19,"reye":19,"mouth":10,"cheek":3,"frame":85},
            {"leye":19,"reye":19,"mouth":6,"cheek":3,"frame":86},
            {"leye":19,"reye":19,"mouth":12,"cheek":3,"frame":88},
            {"leye":2,"reye":2,"mouth":6,"cheek":2,"frame":90},
            {"leye":2,"reye":2,"mouth":12,"cheek":2,"frame":92},
            {"leye":4,"reye":4,"mouth":6,"cheek":2,"frame":94},
            {"leye":4,"reye":4,"mouth":12,"cheek":2,"frame":95},
            {"leye":4,"reye":4,"mouth":6,"cheek":2,"frame":96},
            {"leye":4,"reye":4,"mouth":12,"cheek":2,"frame":97},
            {"leye":4,"reye":4,"mouth":6,"cheek":2,"frame":98},
            {"leye":4,"reye":4,"mouth":17,"cheek":2,"frame":103},
            {"leye":4,"reye":4,"mouth":6,"cheek":2,"frame":104},
            {"leye":4,"reye":4,"mouth":10,"cheek":2,"frame":107},
            {"leye":4,"reye":4,"mouth":17,"cheek":2,"frame":109},
            {"leye":1,"reye":1,"mouth":6,"cheek":2,"frame":111},
            {"leye":1,"reye":1,"mouth":10,"cheek":2,"frame":112},
            {"leye":1,"reye":1,"mouth":17,"cheek":2,"frame":114},
            {"leye":1,"reye":1,"mouth":6,"cheek":2,"frame":115},
            {"leye":1,"reye":1,"mouth":12,"cheek":2,"frame":121},
            {"leye":1,"reye":1,"mouth":6,"cheek":2,"frame":123},
            {"leye":1,"reye":1,"mouth":9,"cheek":2,"frame":131},
            {"leye":19,"reye":19,"mouth":6,"cheek":2,"frame":132},
            {"leye":19,"reye":19,"mouth":17,"cheek":2,"frame":140},
            {"leye":19,"reye":19,"mouth":6,"cheek":2,"frame":141},
            {"leye":2,"reye":2,"mouth":17,"cheek":2,"frame":144},
            {"leye":2,"reye":2,"mouth":6,"cheek":2,"frame":145},
            {"leye":2,"reye":2,"mouth":17,"cheek":2,"frame":147},
            {"leye":6,"reye":6,"mouth":6,"cheek":0,"frame":149},
            {"leye":6,"reye":6,"mouth":6,"cheek":0,"frame":153},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":154},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":155},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":157},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":159},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":161},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":162},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":163},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":165},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":166},
            {"leye":4,"reye":4,"mouth":17,"cheek":0,"frame":167},
            {"leye":4,"reye":4,"mouth":9,"cheek":0,"frame":168},
            {"leye":4,"reye":4,"mouth":6,"cheek":0,"frame":170},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":198},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":202},
            {"leye":6,"reye":6,"mouth":6,"cheek":0,"frame":204},
            {"leye":6,"reye":6,"mouth":3,"cheek":0,"frame":206},
            {"leye":5,"reye":5,"mouth":6,"cheek":0,"frame":207},
            {"leye":5,"reye":5,"mouth":12,"cheek":0,"frame":209},
            {"leye":5,"reye":5,"mouth":6,"cheek":0,"frame":210},
            {"leye":5,"reye":5,"mouth":12,"cheek":0,"frame":211},
            {"leye":5,"reye":5,"mouth":6,"cheek":0,"frame":213},
            {"leye":5,"reye":5,"mouth":12,"cheek":0,"frame":214},
            {"leye":5,"reye":5,"mouth":17,"cheek":0,"frame":217},
            {"leye":5,"reye":5,"mouth":6,"cheek":0,"frame":218},
            {"leye":4,"reye":4,"mouth":17,"cheek":0,"frame":219},
            {"leye":4,"reye":4,"mouth":9,"cheek":0,"frame":220},
            {"leye":4,"reye":4,"mouth":10,"cheek":0,"frame":221},
            {"leye":4,"reye":4,"mouth":17,"cheek":0,"frame":224},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":225},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":229},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":230},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":233},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":238},
            {"leye":6,"reye":6,"mouth":6,"cheek":0,"frame":240},
            {"leye":6,"reye":6,"mouth":17,"cheek":0,"frame":242},
            {"leye":6,"reye":6,"mouth":12,"cheek":0,"frame":243},
            {"leye":6,"reye":6,"mouth":6,"cheek":0,"frame":244},
            {"leye":6,"reye":6,"mouth":15,"cheek":0,"frame":247},
            {"leye":6,"reye":6,"mouth":6,"cheek":0,"frame":252},
            {"leye":5,"reye":5,"mouth":12,"cheek":0,"frame":255},
            {"leye":4,"reye":4,"mouth":6,"cheek":0,"frame":257},
            {"leye":6,"reye":6,"mouth":12,"cheek":0,"frame":259},
            {"leye":6,"reye":6,"mouth":6,"cheek":0,"frame":260},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":264},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":265},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":266},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":268},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":269},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":272},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":273},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":275},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":276},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":278},
            {"leye":6,"reye":6,"mouth":10,"cheek":0,"frame":279},
            {"leye":6,"reye":6,"mouth":6,"cheek":0,"frame":280},
            {"leye":5,"reye":17,"mouth":12,"cheek":0,"frame":281},
            {"leye":5,"reye":17,"mouth":9,"cheek":0,"frame":287},
            {"leye":5,"reye":17,"mouth":6,"cheek":0,"frame":288},
            {"leye":5,"reye":17,"mouth":12,"cheek":0,"frame":289},
            {"leye":5,"reye":17,"mouth":6,"cheek":0,"frame":293},
            {"leye":5,"reye":17,"mouth":12,"cheek":0,"frame":295},
            {"leye":5,"reye":17,"mouth":17,"cheek":0,"frame":296},
            {"leye":5,"reye":17,"mouth":6,"cheek":0,"frame":297},
            {"leye":5,"reye":17,"mouth":12,"cheek":0,"frame":301},
            {"leye":5,"reye":17,"mouth":6,"cheek":0,"frame":302},
            {"leye":5,"reye":17,"mouth":12,"cheek":0,"frame":306},
            {"leye":4,"reye":4,"mouth":6,"cheek":0,"frame":307},
            {"leye":4,"reye":4,"mouth":12,"cheek":0,"frame":309},
            {"leye":4,"reye":4,"mouth":10,"cheek":0,"frame":310},
            {"leye":4,"reye":4,"mouth":6,"cheek":0,"frame":311},
            {"leye":4,"reye":4,"mouth":9,"cheek":0,"frame":312},
            {"leye":6,"reye":6,"mouth":6,"cheek":0,"frame":314},
            {"leye":6,"reye":6,"mouth":17,"cheek":0,"frame":315},
            {"leye":5,"reye":17,"mouth":9,"cheek":0,"frame":316},
            {"leye":5,"reye":17,"mouth":6,"cheek":0,"frame":317},
            {"leye":5,"reye":17,"mouth":9,"cheek":0,"frame":318},
            {"leye":5,"reye":17,"mouth":10,"cheek":0,"frame":319},
            {"leye":5,"reye":17,"mouth":9,"cheek":0,"frame":320},
            {"leye":5,"reye":17,"mouth":6,"cheek":0,"frame":321},
            {"leye":5,"reye":17,"mouth":9,"cheek":0,"frame":322},
            {"leye":5,"reye":17,"mouth":12,"cheek":0,"frame":323},
            {"leye":5,"reye":17,"mouth":6,"cheek":0,"frame":327},
            {"leye":5,"reye":17,"mouth":9,"cheek":0,"frame":328},
            {"leye":9,"reye":10,"mouth":6,"cheek":0,"frame":329},
            {"leye":9,"reye":10,"mouth":17,"cheek":0,"frame":334},
            {"leye":9,"reye":10,"mouth":12,"cheek":0,"frame":336},
            {"leye":9,"reye":10,"mouth":9,"cheek":0,"frame":340},
            {"leye":9,"reye":10,"mouth":6,"cheek":0,"frame":341},
            {"leye":9,"reye":10,"mouth":12,"cheek":0,"frame":342},
            {"leye":9,"reye":10,"mouth":17,"cheek":0,"frame":344},
            {"leye":9,"reye":10,"mouth":6,"cheek":0,"frame":348},
            {"leye":6,"reye":6,"mouth":12,"cheek":0,"frame":349},
            {"leye":6,"reye":6,"mouth":9,"cheek":0,"frame":350},
            {"leye":4,"reye":4,"mouth":17,"cheek":3,"frame":351},
            {"leye":4,"reye":4,"mouth":9,"cheek":3,"frame":353},
            {"leye":4,"reye":4,"mouth":17,"cheek":3,"frame":354},
            {"leye":4,"reye":4,"mouth":12,"cheek":3,"frame":355},
            {"leye":4,"reye":4,"mouth":6,"cheek":3,"frame":356},
            {"leye":4,"reye":4,"mouth":9,"cheek":3,"frame":360},
            {"leye":4,"reye":4,"mouth":17,"cheek":3,"frame":361},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":362},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":363},
            {"leye":6,"reye":6,"mouth":6,"cheek":0,"frame":364},
            {"leye":6,"reye":6,"mouth":12,"cheek":0,"frame":365},
            {"leye":6,"reye":6,"mouth":3,"cheek":0,"frame":368},
            {"leye":11,"reye":11,"mouth":6,"cheek":0,"frame":369},
            {"leye":11,"reye":11,"mouth":12,"cheek":0,"frame":371},
            {"leye":11,"reye":11,"mouth":6,"cheek":0,"frame":372},
            {"leye":11,"reye":11,"mouth":12,"cheek":0,"frame":377},
            {"leye":11,"reye":11,"mouth":6,"cheek":0,"frame":379},
            {"leye":11,"reye":11,"mouth":9,"cheek":2,"frame":381},
            {"leye":11,"reye":11,"mouth":6,"cheek":2,"frame":382},
            {"leye":11,"reye":11,"mouth":12,"cheek":2,"frame":385},
            {"leye":11,"reye":11,"mouth":6,"cheek":2,"frame":386},
            {"leye":11,"reye":11,"mouth":10,"cheek":2,"frame":387},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":389},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":390},
            {"leye":19,"reye":19,"mouth":17,"cheek":0,"frame":392},
            {"leye":19,"reye":19,"mouth":6,"cheek":0,"frame":395},
            {"leye":19,"reye":19,"mouth":12,"cheek":0,"frame":396},
            {"leye":19,"reye":19,"mouth":6,"cheek":0,"frame":401},
            {"leye":5,"reye":5,"mouth":12,"cheek":0,"frame":404},
            {"leye":5,"reye":5,"mouth":9,"cheek":0,"frame":405},
            {"leye":5,"reye":5,"mouth":6,"cheek":0,"frame":406},
            {"leye":5,"reye":5,"mouth":17,"cheek":0,"frame":407},
            {"leye":5,"reye":5,"mouth":6,"cheek":0,"frame":408},
            {"leye":5,"reye":5,"mouth":17,"cheek":0,"frame":409},
            {"leye":5,"reye":5,"mouth":10,"cheek":0,"frame":410},
            {"leye":5,"reye":5,"mouth":12,"cheek":0,"frame":411},
            {"leye":7,"reye":8,"mouth":6,"cheek":0,"frame":412},
            {"leye":7,"reye":8,"mouth":3,"cheek":0,"frame":414},
            {"leye":7,"reye":8,"mouth":6,"cheek":0,"frame":415},
            {"leye":4,"reye":2,"mouth":17,"cheek":0,"frame":424},
            {"leye":4,"reye":2,"mouth":6,"cheek":0,"frame":425},
            {"leye":4,"reye":2,"mouth":12,"cheek":0,"frame":427},
            {"leye":4,"reye":2,"mouth":6,"cheek":0,"frame":428},
            {"leye":2,"reye":4,"mouth":12,"cheek":0,"frame":430},
            {"leye":2,"reye":4,"mouth":17,"cheek":0,"frame":431},
            {"leye":2,"reye":4,"mouth":6,"cheek":0,"frame":433},
            {"leye":2,"reye":4,"mouth":17,"cheek":0,"frame":435},
            {"leye":2,"reye":4,"mouth":6,"cheek":0,"frame":436},
            {"leye":2,"reye":4,"mouth":12,"cheek":0,"frame":439},
            {"leye":2,"reye":4,"mouth":9,"cheek":0,"frame":441},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":442},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":444},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":445},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":447},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":449},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":451},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":452},
            {"leye":6,"reye":6,"mouth":12,"cheek":0,"frame":454},
            {"leye":6,"reye":6,"mouth":6,"cheek":0,"frame":456},
            {"leye":6,"reye":6,"mouth":12,"cheek":0,"frame":457},
            {"leye":6,"reye":6,"mouth":17,"cheek":0,"frame":458},
            {"leye":6,"reye":6,"mouth":9,"cheek":0,"frame":460},
            {"leye":6,"reye":6,"mouth":17,"cheek":0,"frame":461},
            {"leye":6,"reye":6,"mouth":6,"cheek":0,"frame":462},
            {"leye":6,"reye":6,"mouth":12,"cheek":0,"frame":463},
            {"leye":6,"reye":6,"mouth":6,"cheek":0,"frame":464},
            {"leye":6,"reye":6,"mouth":12,"cheek":0,"frame":466},
            {"leye":6,"reye":6,"mouth":6,"cheek":0,"frame":467},
            {"leye":6,"reye":6,"mouth":12,"cheek":0,"frame":470},
            {"leye":2,"reye":2,"mouth":6,"cheek":3,"frame":471},
            {"leye":2,"reye":2,"mouth":12,"cheek":3,"frame":472},
            {"leye":2,"reye":2,"mouth":6,"cheek":3,"frame":473},
            {"leye":2,"reye":2,"mouth":9,"cheek":3,"frame":474},
            {"leye":2,"reye":2,"mouth":6,"cheek":3,"frame":475},
            {"leye":2,"reye":2,"mouth":17,"cheek":3,"frame":476},
            {"leye":2,"reye":2,"mouth":12,"cheek":3,"frame":480},
            {"leye":2,"reye":2,"mouth":9,"cheek":3,"frame":481},
            {"leye":2,"reye":2,"mouth":6,"cheek":3,"frame":482},
            {"leye":2,"reye":2,"mouth":9,"cheek":3,"frame":484},
            {"leye":2,"reye":2,"mouth":6,"cheek":3,"frame":488},
            {"leye":2,"reye":2,"mouth":9,"cheek":3,"frame":492},
            {"leye":2,"reye":2,"mouth":6,"cheek":3,"frame":494},
            {"leye":2,"reye":2,"mouth":9,"cheek":3,"frame":516},
            {"leye":2,"reye":2,"mouth":17,"cheek":3,"frame":517},
            {"leye":2,"reye":2,"mouth":6,"cheek":3,"frame":518},
            {"leye":2,"reye":2,"mouth":17,"cheek":3,"frame":520},
            {"leye":4,"reye":4,"mouth":12,"cheek":0,"frame":522},
            {"leye":4,"reye":4,"mouth":6,"cheek":0,"frame":525},
            {"leye":4,"reye":4,"mouth":3,"cheek":0,"frame":528},
            {"leye":4,"reye":4,"mouth":9,"cheek":0,"frame":529},
            {"leye":4,"reye":4,"mouth":6,"cheek":0,"frame":530},
            {"leye":4,"reye":4,"mouth":12,"cheek":0,"frame":544},
            {"leye":4,"reye":4,"mouth":6,"cheek":0,"frame":545},
            {"leye":4,"reye":4,"mouth":12,"cheek":0,"frame":546},
            {"leye":4,"reye":4,"mouth":9,"cheek":0,"frame":550},
            {"leye":4,"reye":4,"mouth":3,"cheek":0,"frame":552},
            {"leye":4,"reye":4,"mouth":17,"cheek":0,"frame":554},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":555},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":556},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":558},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":559},
            {"leye":4,"reye":4,"mouth":9,"cheek":2,"frame":563},
            {"leye":4,"reye":4,"mouth":6,"cheek":2,"frame":564},
            {"leye":4,"reye":4,"mouth":12,"cheek":2,"frame":565},
            {"leye":4,"reye":4,"mouth":6,"cheek":2,"frame":566},
            {"leye":4,"reye":4,"mouth":9,"cheek":2,"frame":568},
            {"leye":4,"reye":4,"mouth":6,"cheek":2,"frame":569},
            {"leye":1,"reye":1,"mouth":12,"cheek":3,"frame":570},
            {"leye":1,"reye":1,"mouth":6,"cheek":3,"frame":572},
            {"leye":1,"reye":1,"mouth":12,"cheek":3,"frame":573},
            {"leye":1,"reye":1,"mouth":6,"cheek":3,"frame":575},
            {"leye":4,"reye":4,"mouth":17,"cheek":3,"frame":578},
            {"leye":4,"reye":4,"mouth":3,"cheek":3,"frame":580},
            {"leye":4,"reye":4,"mouth":6,"cheek":3,"frame":581},
            {"leye":4,"reye":4,"mouth":12,"cheek":3,"frame":582},
            {"leye":4,"reye":4,"mouth":17,"cheek":0,"frame":584},
            {"leye":2,"reye":2,"mouth":12,"cheek":0,"frame":586},
            {"leye":2,"reye":2,"mouth":6,"cheek":0,"frame":588},
            {"leye":2,"reye":2,"mouth":17,"cheek":0,"frame":589},
            {"leye":2,"reye":2,"mouth":6,"cheek":0,"frame":594},
            {"leye":2,"reye":2,"mouth":9,"cheek":0,"frame":596},
            {"leye":6,"reye":6,"mouth":10,"cheek":0,"frame":599},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":602},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":603},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":605},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":606},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":608},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":609},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":611},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":613},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":615},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":616},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":617},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":618},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":624},
            {"leye":6,"reye":6,"mouth":12,"cheek":0,"frame":626},
            {"leye":6,"reye":6,"mouth":6,"cheek":0,"frame":628},
            {"leye":6,"reye":6,"mouth":17,"cheek":0,"frame":629},
            {"leye":6,"reye":6,"mouth":9,"cheek":0,"frame":630},
            {"leye":6,"reye":6,"mouth":17,"cheek":0,"frame":632},
            {"leye":6,"reye":6,"mouth":6,"cheek":0,"frame":633},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":636},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":637},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":638},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":639},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":641},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":642},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":644},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":646},
            {"leye":4,"reye":2,"mouth":6,"cheek":3,"frame":648},
            {"leye":4,"reye":2,"mouth":9,"cheek":3,"frame":649},
            {"leye":4,"reye":2,"mouth":17,"cheek":3,"frame":650},
            {"leye":4,"reye":2,"mouth":6,"cheek":3,"frame":651},
            {"leye":4,"reye":2,"mouth":17,"cheek":3,"frame":653},
            {"leye":4,"reye":2,"mouth":10,"cheek":3,"frame":654},
            {"leye":4,"reye":2,"mouth":6,"cheek":3,"frame":656},
            {"leye":5,"reye":5,"mouth":12,"cheek":3,"frame":662},
            {"leye":5,"reye":5,"mouth":6,"cheek":3,"frame":663},
            {"leye":5,"reye":5,"0mouth":3,"cheek":3,"frame":664},
            {"leye":4,"reye":4,"mouth":6,"cheek":3,"frame":665},
            {"leye":4,"reye":4,"mouth":17,"cheek":3,"frame":666},
            {"leye":4,"reye":4,"mouth":10,"cheek":3,"frame":670},
            {"leye":4,"reye":4,"mouth":9,"cheek":3,"frame":671},
            {"leye":4,"reye":4,"mouth":17,"cheek":3,"frame":672},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":676},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":678},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":679},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":680},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":684},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":685},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":686},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":687},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":688},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":689},
            {"leye":2,"reye":4,"mouth":6,"cheek":3,"frame":690},
            {"leye":2,"reye":4,"mouth":3,"cheek":3,"frame":692},
            {"leye":2,"reye":4,"mouth":9,"cheek":3,"frame":693},
            {"leye":2,"reye":4,"mouth":12,"cheek":3,"frame":694},
            {"leye":2,"reye":4,"mouth":17,"cheek":3,"frame":695},
            {"leye":2,"reye":4,"mouth":12,"cheek":3,"frame":696},
            {"leye":2,"reye":4,"mouth":17,"cheek":3,"frame":699},
            {"leye":2,"reye":4,"mouth":6,"cheek":3,"frame":700},
            {"leye":5,"reye":5,"mouth":9,"cheek":0,"frame":707},
            {"leye":5,"reye":5,"mouth":17,"cheek":0,"frame":708},
            {"leye":5,"reye":5,"mouth":10,"cheek":0,"frame":709},
            {"leye":5,"reye":5,"mouth":12,"cheek":0,"frame":712},
            {"leye":5,"reye":5,"mouth":17,"cheek":0,"frame":713},
            {"leye":5,"reye":5,"mouth":9,"cheek":0,"frame":714},
            {"leye":5,"reye":5,"mouth":6,"cheek":0,"frame":715},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":720},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":722},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":723},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":726},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":727},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":728},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":733},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":734},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":735},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":737},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":738},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":739},
            {"leye":4,"reye":4,"mouth":9,"cheek":3,"frame":741},
            {"leye":4,"reye":4,"mouth":6,"cheek":3,"frame":742},
            {"leye":4,"reye":4,"mouth":12,"cheek":3,"frame":743},
            {"leye":4,"reye":4,"mouth":6,"cheek":3,"frame":744},
            {"leye":4,"reye":4,"mouth":9,"cheek":3,"frame":748},
            {"leye":4,"reye":4,"mouth":12,"cheek":3,"frame":749},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":750},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":752},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":754},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":755},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":756},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":757},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":759},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":761},
            {"leye":6,"reye":6,"mouth":9,"cheek":3,"frame":762},
            {"leye":6,"reye":6,"mouth":6,"cheek":3,"frame":763},
            {"leye":6,"reye":6,"mouth":9,"cheek":3,"frame":767},
            {"leye":6,"reye":6,"mouth":6,"cheek":3,"frame":768},
            {"leye":6,"reye":6,"mouth":12,"cheek":3,"frame":771},
            {"leye":2,"reye":2,"mouth":6,"cheek":2,"frame":772},
            {"leye":2,"reye":2,"mouth":12,"cheek":2,"frame":773},
            {"leye":2,"reye":2,"mouth":6,"cheek":2,"frame":774},
            {"leye":2,"reye":2,"mouth":12,"cheek":2,"frame":776},
            {"leye":2,"reye":2,"mouth":6,"cheek":2,"frame":777},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":782},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":783},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":784},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":785},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":789},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":790},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":791},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":792},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":793},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":794},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":801},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":802},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":807},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":808},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":809},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":810},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":811},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":813},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":814},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":816},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":817},
            {"leye":19,"reye":19,"mouth":6,"cheek":3,"frame":818},
            {"leye":19,"reye":19,"mouth":9,"cheek":3,"frame":823},
            {"leye":19,"reye":19,"mouth":17,"cheek":3,"frame":825},
            {"leye":19,"reye":19,"mouth":12,"cheek":3,"frame":826},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":827},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":829},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":830},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":833},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":834},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":837},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":838},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":842},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":845},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":848},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":849},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":850},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":851},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":852},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":853},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":854},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":855},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":856},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":857},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":860},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":861},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":862},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":863},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":880},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":881},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":882},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":884},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":885},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":888},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":889},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":892},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":893},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":895},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":899},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":900},
            {"leye":1,"reye":1,"mouth":10,"cheek":0,"frame":903},
            {"leye":1,"reye":1,"mouth":17,"cheek":0,"frame":904},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":908},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":909},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":910},
            {"leye":1,"reye":1,"mouth":9,"cheek":0,"frame":926},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":927},
            {"leye":1,"reye":1,"mouth":12,"cheek":0,"frame":939},
            {"leye":1,"reye":1,"mouth":6,"cheek":0,"frame":940},
            {"leye":2,"reye":2,"mouth":4,"cheek":2,"frame":940},
            {"leye":1,"reye":1,"mouth":3,"cheek":0,"frame":1019},
        ]
    },
    {
        id:'music_02_00_02_09_0',
        name:'Love U my friends(Short ver.)',
        cover_src:'https://www.738ngx.site/api/rinachanboard/images/cover/music_02_00_02.png',
        music_src:'https://www.738ngx.site/api/rinachanboard/musics/music_02_00_02_0.mp3',
        singer:'虹ヶ咲学園スクールアイドル同好会',
        text:  'Love U my friends是虹咲学园学园偶像同好会第二张专辑《Love U my friends》中收录的同名歌曲，由虹咲学园学园偶像同好会演唱，发售于2019年10月2日。',
        faces:[
            {leye: 6,reye: 6,mouth: 3,cheek: 0,frame:   0},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,frame:  69},
            {leye: 6,reye: 6,mouth: 3,cheek: 0,frame: 112},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,frame: 117},
            {leye: 6,reye: 6,mouth: 3,cheek: 0,frame: 127},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,frame: 131},
            {leye: 6,reye: 6,mouth: 3,cheek: 0,frame: 141},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,frame: 146},
            {leye: 6,reye: 6,mouth: 5,cheek: 0,frame: 160},
            {leye: 1,reye: 1,mouth: 5,cheek: 0,frame: 164},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,frame: 168},
            {leye: 2,reye: 2,mouth: 3,cheek: 0,frame: 186},
            {leye: 1,reye: 4,mouth: 3,cheek: 2,frame: 193},
            {leye: 2,reye: 2,mouth: 3,cheek: 0,frame: 196},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,frame: 200},
            {leye: 1,reye: 1,mouth: 5,cheek: 0,frame: 202},
            {leye: 1,reye: 1,mouth:10,cheek: 0,frame: 204},
            {leye: 1,reye: 1,mouth: 7,cheek: 0,frame: 207},
            {leye: 1,reye: 1,mouth: 9,cheek: 0,frame: 208},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,frame: 212},
            {leye: 1,reye: 1,mouth: 9,cheek: 0,frame: 214},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,frame: 216},
            {leye: 1,reye: 1,mouth:10,cheek: 0,frame: 218},
            {leye: 1,reye: 1,mouth: 7,cheek: 0,frame: 221},
            {leye: 1,reye: 1,mouth: 9,cheek: 0,frame: 223},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,frame: 226},
            {leye: 1,reye: 1,mouth: 9,cheek: 0,frame: 228},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,frame: 230},
            {leye: 1,reye: 1,mouth: 9,cheek: 0,frame: 234},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,frame: 238},
            {leye: 1,reye: 1,mouth: 9,cheek: 0,frame: 245},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,frame: 249},
            {leye: 1,reye: 1,mouth: 7,cheek: 0,frame: 261},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,frame: 271},
            {leye: 1,reye: 1,mouth:10,cheek: 0,frame: 275},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,frame: 277},
            {leye: 1,reye: 1,mouth: 9,cheek: 0,frame: 279},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,frame: 283},
            {leye: 1,reye: 1,mouth: 9,cheek: 0,frame: 284},
            {leye: 2,reye: 2,mouth: 9,cheek: 0,frame: 302},
            {leye: 2,reye: 2,mouth: 3,cheek: 0,frame: 304},
            {leye: 6,reye: 6,mouth: 3,cheek: 0,frame: 306},
            {leye: 2,reye: 2,mouth: 3,cheek: 0,frame: 308},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,frame: 314},
            {leye: 6,reye: 6,mouth: 3,cheek: 0,frame: 317},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,frame: 334},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,frame: 401},
            {leye: 1,reye: 1,mouth: 9,cheek: 0,frame: 404},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,frame: 407},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,frame: 411},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,frame: 413},
            {leye: 1,reye: 1,mouth: 9,cheek: 0,frame: 415},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,frame: 417},
            {leye: 1,reye: 1,mouth: 9,cheek: 0,frame: 418},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,frame: 422},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,frame: 425},
            {leye: 6,reye: 6,mouth: 3,cheek: 0,frame: 432},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,frame: 437},
            {leye: 6,reye: 6,mouth: 3,cheek: 0,frame: 439},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,frame: 444},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,frame: 488},
            {leye: 1,reye: 1,mouth: 9,cheek: 0,frame: 489},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,frame: 491},
            {leye: 1,reye: 1,mouth: 9,cheek: 0,frame: 492},
            {leye: 1,reye: 1,mouth: 7,cheek: 0,frame: 493},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,frame: 497},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,frame: 501},
            {leye: 1,reye: 1,mouth: 9,cheek: 0,frame: 503},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,frame: 505},
            {leye: 1,reye: 1,mouth: 9,cheek: 0,frame: 506},
            {leye: 1,reye: 1,mouth: 7,cheek: 0,frame: 507},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,frame: 514},
            {leye: 6,reye: 6,mouth: 3,cheek: 0,frame: 524},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,frame: 532},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,frame: 533},
            {leye: 1,reye: 1,mouth: 7,cheek: 0,frame: 535},
            {leye: 6,reye: 6,mouth: 7,cheek: 0,frame: 537},
            {leye: 1,reye: 1,mouth: 7,cheek: 0,frame: 539},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,frame: 545},
            {leye: 4,reye: 4,mouth: 3,cheek: 2,frame: 554},
            {leye: 6,reye: 6,mouth: 3,cheek: 0,frame: 558},
            {leye: 2,reye: 2,mouth: 3,cheek: 0,frame: 563},
            {leye: 2,reye: 2,mouth: 6,cheek: 0,frame: 566},
            {leye: 2,reye: 2,mouth: 9,cheek: 0,frame: 568},
            {leye: 2,reye: 2,mouth: 6,cheek: 0,frame: 570},
            {leye: 2,reye: 2,mouth: 9,cheek: 0,frame: 571},
            {leye: 2,reye: 2,mouth:10,cheek: 0,frame: 574},
            {leye: 2,reye: 2,mouth: 6,cheek: 0,frame: 578},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,frame: 580},
            {leye: 1,reye: 1,mouth: 9,cheek: 0,frame: 588},
            {leye: 1,reye: 1,mouth: 5,cheek: 0,frame: 592},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,frame: 594},
            {leye: 1,reye: 1,mouth: 9,cheek: 0,frame: 597},
            {leye: 1,reye: 1,mouth: 7,cheek: 0,frame: 602},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,frame: 604},
            {leye: 1,reye: 1,mouth:10,cheek: 0,frame: 610},
            {leye: 1,reye: 1,mouth: 9,cheek: 0,frame: 612},
            {leye: 1,reye: 1,mouth:10,cheek: 0,frame: 614},
            {leye: 1,reye: 1,mouth: 5,cheek: 0,frame: 620},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,frame: 626},
            {leye: 1,reye: 1,mouth: 9,cheek: 0,frame: 629},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,frame: 634},
            {leye: 1,reye: 1,mouth: 9,cheek: 0,frame: 637},
            {leye: 1,reye: 1,mouth:10,cheek: 0,frame: 644},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,frame: 646},
            {leye: 1,reye: 1,mouth: 9,cheek: 0,frame: 655},
            {leye: 1,reye: 1,mouth: 7,cheek: 0,frame: 657},
            {leye: 1,reye: 1,mouth: 9,cheek: 0,frame: 658},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,frame: 661},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,frame: 669},
            {leye: 1,reye: 1,mouth: 7,cheek: 0,frame: 671},
            {leye: 1,reye: 1,mouth: 9,cheek: 0,frame: 682},
            {leye: 1,reye: 1,mouth:10,cheek: 0,frame: 684},
            {leye: 1,reye: 1,mouth: 9,cheek: 0,frame: 686},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,frame: 688},
            {leye: 1,reye: 1,mouth: 9,cheek: 0,frame: 694},
            {leye: 1,reye: 1,mouth:10,cheek: 0,frame: 702},
            {leye: 1,reye: 1,mouth: 5,cheek: 0,frame: 705},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,frame: 707},
            {leye: 1,reye: 1,mouth: 7,cheek: 0,frame: 709},
            {leye: 1,reye: 1,mouth:10,cheek: 0,frame: 711},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,frame: 713},
            {leye: 1,reye: 1,mouth: 9,cheek: 0,frame: 714},
            {leye: 1,reye: 1,mouth: 7,cheek: 0,frame: 717},
            {leye: 1,reye: 1,mouth: 9,cheek: 0,frame: 724},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,frame: 726},
            {leye: 1,reye: 1,mouth:10,cheek: 0,frame: 727},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,frame: 729},
            {leye: 1,reye: 1,mouth: 5,cheek: 0,frame: 735},
            {leye: 1,reye: 1,mouth: 9,cheek: 0,frame: 737},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,frame: 740},
            {leye: 1,reye: 1,mouth: 7,cheek: 0,frame: 743},
            {leye: 1,reye: 1,mouth: 9,cheek: 0,frame: 746},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,frame: 751},
            {leye: 1,reye: 1,mouth: 9,cheek: 0,frame: 756},
            {leye: 1,reye: 1,mouth: 7,cheek: 0,frame: 757},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,frame: 760},
            {leye: 2,reye: 2,mouth: 6,cheek: 0,frame: 763},
            {leye: 6,reye: 6,mouth: 3,cheek: 0,frame: 767},
            {leye: 6,reye: 6,mouth: 9,cheek: 0,frame: 769},
            {leye: 1,reye: 1,mouth: 7,cheek: 0,frame: 773},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,frame: 776},
            {leye: 1,reye: 1,mouth: 9,cheek: 0,frame: 778},
            {leye: 1,reye: 1,mouth:10,cheek: 0,frame: 786},
            {leye: 1,reye: 1,mouth: 9,cheek: 0,frame: 791},
            {leye: 1,reye: 1,mouth: 7,cheek: 0,frame: 794},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,frame: 820},
            {leye: 6,reye: 6,mouth: 3,cheek: 0,frame: 823},
            {leye: 6,reye: 6,mouth: 5,cheek: 0,frame: 828},
            {leye: 6,reye: 6,mouth: 6,cheek: 0,frame: 829},
            {leye: 2,reye: 2,mouth: 6,cheek: 0,frame: 830},
            {leye: 2,reye: 2,mouth: 3,cheek: 0,frame: 831},
            {leye: 2,reye: 2,mouth:10,cheek: 0,frame: 832},
            {leye: 1,reye: 1,mouth:10,cheek: 0,frame: 833},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,frame: 834},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,frame: 835},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,frame: 836},
            {leye: 1,reye: 1,mouth: 9,cheek: 0,frame: 838},
            {leye: 1,reye: 1,mouth: 6,cheek: 0,frame: 839},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,frame: 842},
            {leye: 1,reye: 1,mouth: 7,cheek: 0,frame: 866},
            {leye: 6,reye: 6,mouth: 7,cheek: 0,frame: 875},
            {leye: 1,reye: 1,mouth: 7,cheek: 0,frame: 881},
            {leye: 6,reye: 6,mouth: 3,cheek: 0,frame: 889},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,frame: 895},
            {leye: 6,reye: 6,mouth: 3,cheek: 0,frame: 937},
            {leye: 1,reye: 4,mouth: 3,cheek: 2,frame: 941},
            {leye: 1,reye: 1,mouth: 3,cheek: 0,frame: 946},
            {leye: 1,reye: 1,mouth:10,cheek: 0,frame: 978},
            {leye: 6,reye: 6,mouth: 3,cheek: 0,frame:1023},
            {leye: 6,reye: 6,mouth: 3,cheek: 0,frame:1031},
        ]
    },
]

window.RINA_MUSIC_DATA = music_data;

window.RINA_UNITY_DB={"ascii":[{"id":32,"symbol":" ","content":[[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0]]},{"id":33,"symbol":"!","content":[[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,0,0,0],[0,0,1,0,0]]},{"id":34,"symbol":"\"","content":[[0,1,0,1,0],[0,1,0,1,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0]]},{"id":35,"symbol":"#","content":[[0,1,0,1,0],[0,1,0,1,0],[1,1,1,1,1],[0,1,0,1,0],[1,1,1,1,1],[0,1,0,1,0],[0,1,0,1,0]]},{"id":36,"symbol":"$","content":[[0,0,1,0,0],[0,1,1,1,1],[1,0,1,0,0],[0,1,1,1,0],[0,0,1,0,1],[1,1,1,1,0],[0,0,1,0,0]]},{"id":37,"symbol":"%","content":[[1,1,0,0,0],[1,1,0,0,1],[0,0,0,1,0],[0,0,1,0,0],[0,1,0,0,0],[1,0,0,1,1],[0,0,0,1,1]]},{"id":38,"symbol":"&","content":[[0,1,1,0,0],[1,0,0,1,0],[1,0,1,0,0],[0,1,0,0,0],[1,0,1,0,1],[1,0,0,1,0],[0,1,1,0,1]]},{"id":39,"symbol":"'","content":[[0,0,1,0,0],[0,0,1,0,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0]]},{"id":40,"symbol":"(","content":[[0,0,0,1,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,0,1,0]]},{"id":41,"symbol":")","content":[[0,1,0,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,1,0,0,0]]},{"id":42,"symbol":"*","content":[[0,0,0,0,0],[0,0,1,0,0],[1,0,1,0,1],[0,1,1,1,0],[1,0,1,0,1],[0,0,1,0,0],[0,0,0,0,0]]},{"id":43,"symbol":"+","content":[[0,0,0,0,0],[0,0,1,0,0],[0,0,1,0,0],[1,1,1,1,1],[0,0,1,0,0],[0,0,1,0,0],[0,0,0,0,0]]},{"id":44,"symbol":",","content":[[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,1,0,0],[0,1,0,0,0]]},{"id":45,"symbol":"-","content":[[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[1,1,1,1,1],[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0]]},{"id":46,"symbol":".","content":[[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[0,1,0,0,0]]},{"id":47,"symbol":"/","content":[[0,0,0,0,1],[0,0,0,0,1],[0,0,0,1,0],[0,0,1,0,0],[0,1,0,0,0],[1,0,0,0,0],[1,0,0,0,0]]},{"id":48,"symbol":"0","content":[[0,1,1,1,0],[1,0,0,0,1],[1,1,0,0,1],[1,0,1,0,1],[1,0,0,1,1],[1,0,0,0,1],[0,1,1,1,0]]},{"id":49,"symbol":"1","content":[[0,0,1,0,0],[0,1,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,1,1,1,0]]},{"id":50,"symbol":"2","content":[[0,1,1,1,0],[1,0,0,0,1],[0,0,0,0,1],[0,0,0,1,0],[0,0,1,0,0],[0,1,0,0,0],[1,1,1,1,1]]},{"id":51,"symbol":"3","content":[[1,1,1,1,1],[0,0,0,0,1],[0,0,0,1,0],[0,0,1,1,0],[0,0,0,0,1],[1,0,0,0,1],[0,1,1,1,0]]},{"id":52,"symbol":"4","content":[[0,0,0,1,0],[0,0,1,1,0],[0,1,0,1,0],[1,0,0,1,0],[1,1,1,1,1],[0,0,0,1,0],[0,0,0,1,0]]},{"id":53,"symbol":"5","content":[[1,1,1,1,1],[1,0,0,0,0],[1,1,1,1,0],[0,0,0,0,1],[0,0,0,0,1],[1,0,0,0,1],[0,1,1,1,0]]},{"id":54,"symbol":"6","content":[[0,1,1,1,0],[1,0,0,0,1],[1,0,0,0,0],[1,1,1,1,0],[1,0,0,0,1],[1,0,0,0,1],[0,1,1,1,0]]},{"id":55,"symbol":"7","content":[[1,1,1,1,1],[0,0,0,0,1],[0,0,0,1,0],[0,0,1,0,0],[0,1,0,0,0],[0,1,0,0,0],[0,1,0,0,0]]},{"id":56,"symbol":"8","content":[[0,1,1,1,0],[1,0,0,0,1],[1,0,0,0,1],[0,1,1,1,0],[1,0,0,0,1],[1,0,0,0,1],[0,1,1,1,0]]},{"id":57,"symbol":"9","content":[[0,1,1,1,0],[1,0,0,0,1],[1,0,0,0,1],[0,1,1,1,1],[0,0,0,0,1],[1,0,0,0,1],[0,1,1,1,0]]},{"id":58,"symbol":":","content":[[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,1,0,0],[0,0,0,0,0],[0,0,1,0,0],[0,0,0,0,0]]},{"id":59,"symbol":";","content":[[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,1,0,0],[0,0,0,0,0],[0,0,1,0,0],[0,1,0,0,0]]},{"id":60,"symbol":"<","content":[[0,0,0,0,0],[0,0,0,1,0],[0,0,1,0,0],[0,1,0,0,0],[0,0,1,0,0],[0,0,0,1,0],[0,0,0,0,0]]},{"id":61,"symbol":"=","content":[[0,0,0,0,0],[0,0,0,0,0],[1,1,1,1,1],[0,0,0,0,0],[1,1,1,1,1],[0,0,0,0,0],[0,0,0,0,0]]},{"id":62,"symbol":">","content":[[0,0,0,0,0],[0,1,0,0,0],[0,0,1,0,0],[0,0,0,1,0],[0,0,1,0,0],[0,1,0,0,0],[0,0,0,0,0]]},{"id":63,"symbol":"?","content":[[0,1,1,1,0],[1,0,0,0,1],[0,0,0,0,1],[0,0,1,1,0],[0,0,1,0,0],[0,0,0,0,0],[0,0,1,0,0]]},{"id":64,"symbol":"@","content":[[0,1,1,1,0],[1,0,0,0,1],[1,0,1,1,1],[1,0,1,0,1],[1,0,1,1,1],[1,0,0,0,0],[0,1,1,1,0]]},{"id":65,"symbol":"A","content":[[0,1,1,1,0],[1,0,0,0,1],[1,0,0,0,1],[1,1,1,1,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1]]},{"id":66,"symbol":"B","content":[[1,1,1,1,0],[1,0,0,0,1],[1,0,0,0,1],[1,1,1,1,0],[1,0,0,0,1],[1,0,0,0,1],[1,1,1,1,0]]},{"id":67,"symbol":"C","content":[[0,1,1,1,0],[1,0,0,0,1],[1,0,0,0,0],[1,0,0,0,0],[1,0,0,0,0],[1,0,0,0,1],[0,1,1,1,0]]},{"id":68,"symbol":"D","content":[[1,1,1,1,0],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,1,1,1,0]]},{"id":69,"symbol":"E","content":[[1,1,1,1,1],[1,0,0,0,0],[1,0,0,0,0],[1,1,1,1,0],[1,0,0,0,0],[1,0,0,0,0],[1,1,1,1,1]]},{"id":70,"symbol":"F","content":[[1,1,1,1,1],[1,0,0,0,0],[1,0,0,0,0],[1,1,1,1,0],[1,0,0,0,0],[1,0,0,0,0],[1,0,0,0,0]]},{"id":71,"symbol":"G","content":[[0,1,1,1,0],[1,0,0,0,1],[1,0,0,0,0],[1,0,1,1,1],[1,0,0,0,1],[1,0,0,0,1],[0,1,1,1,0]]},{"id":72,"symbol":"H","content":[[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,1,1,1,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1]]},{"id":73,"symbol":"I","content":[[0,1,1,1,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,1,1,1,0]]},{"id":74,"symbol":"J","content":[[0,1,1,1,1],[0,0,0,1,0],[0,0,0,1,0],[0,0,0,1,0],[0,0,0,1,0],[1,0,0,1,0],[0,1,1,0,0]]},{"id":75,"symbol":"K","content":[[1,0,0,0,1],[1,0,0,1,0],[1,0,1,0,0],[1,1,0,0,0],[1,0,1,0,0],[1,0,0,1,0],[1,0,0,0,1]]},{"id":76,"symbol":"L","content":[[1,0,0,0,0],[1,0,0,0,0],[1,0,0,0,0],[1,0,0,0,0],[1,0,0,0,0],[1,0,0,0,0],[1,1,1,1,1]]},{"id":77,"symbol":"M","content":[[1,0,0,0,1],[1,1,0,1,1],[1,0,1,0,1],[1,0,1,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1]]},{"id":78,"symbol":"N","content":[[1,0,0,0,1],[1,1,0,0,1],[1,0,1,0,1],[1,0,0,1,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1]]},{"id":79,"symbol":"O","content":[[0,1,1,1,0],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[0,1,1,1,0]]},{"id":80,"symbol":"P","content":[[1,1,1,1,0],[1,0,0,0,1],[1,0,0,0,1],[1,1,1,1,0],[1,0,0,0,0],[1,0,0,0,0],[1,0,0,0,0]]},{"id":81,"symbol":"Q","content":[[0,1,1,1,0],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,1,0,1],[1,0,0,1,0],[0,1,1,0,1]]},{"id":82,"symbol":"R","content":[[1,1,1,1,0],[1,0,0,0,1],[1,0,0,0,1],[1,1,1,1,0],[1,0,1,0,0],[1,0,0,1,0],[1,0,0,0,1]]},{"id":83,"symbol":"S","content":[[0,1,1,1,0],[1,0,0,0,1],[1,0,0,0,0],[0,1,1,1,0],[0,0,0,0,1],[1,0,0,0,1],[0,1,1,1,0]]},{"id":84,"symbol":"T","content":[[1,1,1,1,1],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0]]},{"id":85,"symbol":"U","content":[[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[0,1,1,1,0]]},{"id":86,"symbol":"V","content":[[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[0,1,0,1,0],[0,0,1,0,0]]},{"id":87,"symbol":"W","content":[[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,1,0,1],[1,0,1,0,1],[0,1,0,1,0]]},{"id":88,"symbol":"X","content":[[1,0,0,0,1],[1,0,0,0,1],[0,1,0,1,0],[0,0,1,0,0],[0,1,0,1,0],[1,0,0,0,1],[1,0,0,0,1]]},{"id":89,"symbol":"Y","content":[[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[0,1,0,1,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0]]},{"id":90,"symbol":"Z","content":[[1,1,1,1,1],[0,0,0,0,1],[0,0,0,1,0],[0,0,1,0,0],[0,1,0,0,0],[1,0,0,0,0],[1,1,1,1,1]]},{"id":91,"symbol":"[","content":[[0,0,1,1,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,1,0]]},{"id":92,"symbol":"\\","content":[[1,0,0,0,0],[1,0,0,0,0],[0,1,0,0,0],[0,0,1,0,0],[0,0,0,1,0],[0,0,0,0,1],[0,0,0,0,1]]},{"id":93,"symbol":"]","content":[[0,1,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,1,1,0,0]]},{"id":94,"symbol":"^","content":[[0,0,1,0,0],[0,1,0,1,0],[1,0,0,0,1],[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0]]},{"id":95,"symbol":"_","content":[[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[1,1,1,1,1]]},{"id":96,"symbol":"`","content":[[0,0,1,0,0],[0,0,0,1,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0]]},{"id":97,"symbol":"a","content":[[0,0,0,0,0],[0,0,0,0,0],[0,1,1,1,0],[0,0,0,0,1],[0,1,1,1,1],[1,0,0,0,1],[0,1,1,1,1]]},{"id":98,"symbol":"b","content":[[1,0,0,0,0],[1,0,0,0,0],[1,0,1,1,0],[1,1,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,1,1,1,0]]},{"id":99,"symbol":"c","content":[[0,0,0,0,0],[0,0,0,0,0],[0,1,1,1,0],[1,0,0,0,0],[1,0,0,0,0],[1,0,0,0,1],[0,1,1,1,0]]},{"id":100,"symbol":"d","content":[[0,0,0,0,1],[0,0,0,0,1],[0,1,1,0,1],[1,0,0,1,1],[1,0,0,0,1],[1,0,0,0,1],[0,1,1,1,1]]},{"id":101,"symbol":"e","content":[[0,0,0,0,0],[0,0,0,0,0],[0,1,1,1,0],[1,0,0,0,1],[1,1,1,1,1],[1,0,0,0,0],[0,1,1,1,0]]},{"id":102,"symbol":"f","content":[[0,0,1,1,0],[0,1,0,0,1],[0,1,0,0,0],[1,1,1,0,0],[0,1,0,0,0],[0,1,0,0,0],[0,1,0,0,0]]},{"id":103,"symbol":"g","content":[[0,0,0,0,0],[0,0,0,0,0],[0,1,1,1,1],[1,0,0,0,1],[0,1,1,1,1],[0,0,0,0,1],[0,1,1,1,0]]},{"id":104,"symbol":"h","content":[[1,0,0,0,0],[1,0,0,0,0],[1,0,1,1,0],[1,1,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1]]},{"id":105,"symbol":"i","content":[[0,0,1,0,0],[0,0,0,0,0],[0,0,1,0,0],[0,1,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,1,1,1,0]]},{"id":106,"symbol":"j","content":[[0,0,0,1,0],[0,0,0,0,0],[0,0,1,1,0],[0,0,0,1,0],[0,0,0,1,0],[1,0,0,1,0],[0,1,1,0,0]]},{"id":107,"symbol":"k","content":[[1,0,0,0,0],[1,0,0,0,0],[1,0,0,1,0],[1,0,1,0,0],[1,1,0,0,0],[1,0,1,0,0],[1,0,0,1,0]]},{"id":108,"symbol":"l","content":[[0,1,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,1,1,1,0]]},{"id":109,"symbol":"m","content":[[0,0,0,0,0],[0,0,0,0,0],[1,1,0,1,0],[1,0,1,0,1],[1,0,1,0,1],[1,0,1,0,1],[1,0,1,0,1]]},{"id":110,"symbol":"n","content":[[0,0,0,0,0],[0,0,0,0,0],[1,0,1,1,0],[1,1,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1]]},{"id":111,"symbol":"o","content":[[0,0,0,0,0],[0,0,0,0,0],[0,1,1,1,0],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[0,1,1,1,0]]},{"id":112,"symbol":"p","content":[[0,0,0,0,0],[0,0,0,0,0],[1,1,1,1,0],[1,0,0,0,1],[1,1,1,1,0],[1,0,0,0,0],[1,0,0,0,0]]},{"id":113,"symbol":"q","content":[[0,0,0,0,0],[0,0,0,0,0],[0,1,1,1,1],[1,0,0,0,1],[0,1,1,1,1],[0,0,0,0,1],[0,0,0,0,1]]},{"id":114,"symbol":"r","content":[[0,0,0,0,0],[0,0,0,0,0],[1,0,1,1,0],[1,1,0,0,1],[1,0,0,0,0],[1,0,0,0,0],[1,0,0,0,0]]},{"id":115,"symbol":"s","content":[[0,0,0,0,0],[0,0,0,0,0],[0,1,1,1,0],[1,0,0,0,0],[0,1,1,1,0],[0,0,0,0,1],[1,1,1,1,0]]},{"id":116,"symbol":"t","content":[[0,1,0,0,0],[0,1,0,0,0],[1,1,1,0,0],[0,1,0,0,0],[0,1,0,0,0],[0,1,0,0,1],[0,0,1,1,0]]},{"id":117,"symbol":"u","content":[[0,0,0,0,0],[0,0,0,0,0],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,1,1],[0,1,1,0,1]]},{"id":118,"symbol":"v","content":[[0,0,0,0,0],[0,0,0,0,0],[1,0,0,0,1],[1,0,0,0,1],[1,0,0,0,1],[0,1,0,1,0],[0,0,1,0,0]]},{"id":119,"symbol":"w","content":[[0,0,0,0,0],[0,0,0,0,0],[1,0,0,0,1],[1,0,0,0,1],[1,0,1,0,1],[1,0,1,0,1],[0,1,0,1,0]]},{"id":120,"symbol":"x","content":[[0,0,0,0,0],[0,0,0,0,0],[1,0,0,0,1],[0,1,0,1,0],[0,0,1,0,0],[0,1,0,1,0],[1,0,0,0,1]]},{"id":121,"symbol":"y","content":[[0,0,0,0,0],[0,0,0,0,0],[1,0,0,0,1],[1,0,0,0,1],[0,1,1,1,1],[0,0,0,0,1],[0,1,1,1,0]]},{"id":122,"symbol":"z","content":[[0,0,0,0,0],[0,0,0,0,0],[1,1,1,1,1],[0,0,0,1,0],[0,0,1,0,0],[0,1,0,0,0],[1,1,1,1,1]]},{"id":123,"symbol":"{","content":[[0,0,0,1,0],[0,0,1,0,0],[0,0,1,0,0],[0,1,0,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,0,1,0]]},{"id":124,"symbol":"|","content":[[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,1,0,0]]},{"id":125,"symbol":"}","content":[[0,1,0,0,0],[0,0,1,0,0],[0,0,1,0,0],[0,0,0,1,0],[0,0,1,0,0],[0,0,1,0,0],[0,1,0,0,0]]},{"id":126,"symbol":"~","content":[[0,0,0,0,0],[0,1,0,0,1],[1,0,1,1,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0]]}],"faceModules":{"0":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]],"101":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,1,1,0,0,0,0],[0,0,1,1,0,0,0,0],[0,0,1,1,0,0,0,0],[0,0,1,1,0,0,0,0],[0,0,0,0,0,0,0,0]],"102":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,1,0,0,0,0,0,0],[0,0,1,1,0,0,0,0],[0,0,1,1,0,0,0,0],[0,0,1,1,0,0,0,0],[0,0,1,1,0,0,0,0],[0,0,0,0,0,0,0,0]],"103":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,1,0,0,0,0],[0,0,1,0,1,0,0,0],[0,1,0,0,0,1,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]],"104":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,1,1,0,0,0],[0,0,1,0,0,1,0,0],[0,1,0,0,0,0,1,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]],"105":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,1,0,0,0,0],[0,0,1,0,1,0,0,0],[0,1,0,0,0,1,0,0],[1,0,0,0,0,0,1,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]],"106":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,1,1,0,0,0,0,0],[0,0,0,1,1,0,0,0],[0,0,0,0,0,1,0,0],[0,0,0,1,1,0,0,0],[0,1,1,0,0,0,0,0],[0,0,0,0,0,0,0,0]],"107":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,1,1,0,0,0,0,0],[0,0,0,1,1,0,0,0],[0,0,0,0,0,1,0,0],[0,1,1,1,1,0,0,0],[0,0,0,0,0,0,0,0]],"108":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,1,1,1,1,1,1,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]],"109":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,1,1,1,1,1,1,0],[1,0,1,0,0,0,0,0],[0,1,0,0,0,0,0,0]],"110":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,1,0,0,0,0,0,0],[0,0,1,1,1,1,0,0],[0,0,0,0,0,0,0,0]],"111":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,1,0,0,0,1,0,0],[0,0,1,1,1,0,0,0],[0,0,0,0,0,0,0,0]],"112":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,1,0,0,0,0,1,0],[0,0,1,0,0,1,0,0],[0,0,0,1,1,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]],"113":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,1,1,0,0,0,0,0],[0,0,0,1,1,1,1,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]],"114":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,1,1,1,0,0,0,0],[0,0,0,0,1,1,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]],"115":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,1,1,0,0,0,0,0],[0,0,0,1,0,0,0,0],[0,0,0,0,1,1,0,0],[0,0,0,0,0,0,0,0]],"116":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,1,1,0,0,0,0],[0,0,1,1,1,1,0,0],[0,0,0,1,1,0,0,0],[0,0,0,0,0,0,0,0]],"117":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,1,0,0,0],[0,0,0,1,0,0,0,0],[0,1,1,1,0,0,0,0],[0,0,1,1,0,0,0,0],[0,0,1,1,0,0,0,0],[0,0,0,0,0,0,0,0]],"118":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,1,0,0,0,0,0,0],[0,0,1,0,0,0,0,0],[0,0,1,1,1,0,0,0],[0,0,1,1,0,0,0,0],[0,0,1,1,0,0,0,0],[0,0,0,0,0,0,0,0]],"119":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,1,1,0,0,0,0],[0,1,1,0,1,0,0,0],[0,1,1,1,1,0,0,0],[0,0,1,1,0,0,0,0],[0,0,0,0,0,0,0,0]],"120":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,1,1,0,0,0,0],[0,1,1,0,1,0,0,0],[0,1,1,1,1,0,0,0],[1,0,1,1,0,0,0,0],[0,1,0,0,0,0,0,0]],"121":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,1,1,0,0,0,0],[0,1,1,1,0,0,0,0],[0,1,1,1,1,0,0,0],[0,0,1,1,0,0,0,0],[0,0,0,0,0,0,0,0]],"122":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,1,1,1,0,0,0],[0,1,0,0,0,1,0,0],[0,0,0,0,1,0,0,0],[0,0,0,1,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,1,0,0,0,0]],"123":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,1,0,0,0,1,0,0],[0,0,1,0,1,0,0,0],[0,0,0,1,0,0,0,0],[0,0,1,0,1,0,0,0],[0,1,0,0,0,1,0,0],[0,0,0,0,0,0,0,0]],"124":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,1,0,0,0,0],[0,0,1,1,1,0,0,0],[0,1,1,1,1,1,0,0],[0,0,1,1,1,0,0,0],[0,0,0,1,0,0,0,0],[0,0,0,0,0,0,0,0]],"125":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,1,1,1,0,0,0],[0,1,0,0,0,1,0,0],[0,1,0,0,0,1,0,0],[0,1,0,0,0,1,0,0],[0,0,1,1,1,0,0,0],[0,0,0,0,0,0,0,0]],"126":[[0,0,0,0,0,0,0,0],[0,0,0,1,0,0,0,0],[0,0,1,0,1,0,0,0],[0,1,0,0,0,1,0,0],[1,0,0,0,0,0,1,0],[0,1,0,0,0,1,0,0],[0,0,1,0,1,0,0,0],[0,0,0,1,0,0,0,0]],"127":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,1,1,0,1,1,0,0],[1,0,0,1,0,0,1,0],[1,0,0,0,0,0,1,0],[0,1,0,0,0,1,0,0],[0,0,1,0,1,0,0,0],[0,0,0,1,0,0,0,0]],"201":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,1,1,0,0],[0,0,0,0,1,1,0,0],[0,0,0,0,1,1,0,0],[0,0,0,0,1,1,0,0],[0,0,0,0,0,0,0,0]],"202":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,1,0],[0,0,0,0,1,1,0,0],[0,0,0,0,1,1,0,0],[0,0,0,0,1,1,0,0],[0,0,0,0,1,1,0,0],[0,0,0,0,0,0,0,0]],"203":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,1,0,0,0],[0,0,0,1,0,1,0,0],[0,0,1,0,0,0,1,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]],"204":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,1,1,0,0,0],[0,0,1,0,0,1,0,0],[0,1,0,0,0,0,1,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]],"205":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,1,0,0,0],[0,0,0,1,0,1,0,0],[0,0,1,0,0,0,1,0],[0,1,0,0,0,0,0,1],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]],"206":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,1,1,0],[0,0,0,1,1,0,0,0],[0,0,1,0,0,0,0,0],[0,0,0,1,1,0,0,0],[0,0,0,0,0,1,1,0],[0,0,0,0,0,0,0,0]],"207":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,1,1,0],[0,0,0,1,1,0,0,0],[0,0,1,0,0,0,0,0],[0,0,0,1,1,1,1,0],[0,0,0,0,0,0,0,0]],"208":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,1,1,1,1,1,1,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]],"209":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,1,1,1,1,1,1,0],[0,0,0,0,0,1,0,1],[0,0,0,0,0,0,1,0]],"210":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,1,0],[0,0,1,1,1,1,0,0],[0,0,0,0,0,0,0,0]],"211":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,1,0,0,0,1,0],[0,0,0,1,1,1,0,0],[0,0,0,0,0,0,0,0]],"212":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,1,0,0,0,0,1,0],[0,0,1,0,0,1,0,0],[0,0,0,1,1,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]],"213":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,1,1,0],[0,1,1,1,1,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]],"214":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,1,1,1,0],[0,0,1,1,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]],"215":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,1,1,0],[0,0,0,0,1,0,0,0],[0,0,1,1,0,0,0,0],[0,0,0,0,0,0,0,0]],"216":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,1,1,0,0],[0,0,1,1,1,1,0,0],[0,0,0,1,1,0,0,0],[0,0,0,0,0,0,0,0]],"217":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,1,0,0,0,0],[0,0,0,0,1,0,0,0],[0,0,0,0,1,1,1,0],[0,0,0,0,1,1,0,0],[0,0,0,0,1,1,0,0],[0,0,0,0,0,0,0,0]],"218":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,1,0],[0,0,0,0,0,1,0,0],[0,0,0,1,1,1,0,0],[0,0,0,0,1,1,0,0],[0,0,0,0,1,1,0,0],[0,0,0,0,0,0,0,0]],"219":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,1,1,0,0],[0,0,0,1,0,1,1,0],[0,0,0,1,1,1,1,0],[0,0,0,0,1,1,0,0],[0,0,0,0,0,0,0,0]],"220":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,1,1,0,0],[0,0,0,1,0,1,1,0],[0,0,0,1,1,1,1,0],[0,0,0,0,1,1,0,1],[0,0,0,0,0,0,1,0]],"221":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,1,1,0,0],[0,0,0,0,1,1,1,0],[0,0,0,1,1,1,1,0],[0,0,0,0,1,1,0,0],[0,0,0,0,0,0,0,0]],"222":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,1,0,0,0],[0,0,0,0,1,0,0,0],[0,0,0,0,1,0,0,0],[0,0,0,0,1,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,1,0,0,0]],"223":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,1,0,0,0,1,0],[0,0,0,1,0,1,0,0],[0,0,0,0,1,0,0,0],[0,0,0,1,0,1,0,0],[0,0,1,0,0,0,1,0],[0,0,0,0,0,0,0,0]],"224":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,1,0,0,0],[0,0,0,1,1,1,0,0],[0,0,1,1,1,1,1,0],[0,0,0,1,1,1,0,0],[0,0,0,0,1,0,0,0],[0,0,0,0,0,0,0,0]],"225":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,1,1,1,0,0],[0,0,1,0,0,0,1,0],[0,0,1,0,0,0,1,0],[0,0,1,0,0,0,1,0],[0,0,0,1,1,1,0,0],[0,0,0,0,0,0,0,0]],"226":[[0,0,0,0,0,0,0,0],[0,0,0,0,1,0,0,0],[0,0,0,1,0,1,0,0],[0,0,1,0,0,0,1,0],[0,1,0,0,0,0,0,1],[0,0,1,0,0,0,1,0],[0,0,0,1,0,1,0,0],[0,0,0,0,1,0,0,0]],"227":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,1,1,0,1,1,0],[0,1,0,0,1,0,0,1],[0,1,0,0,0,0,0,1],[0,0,1,0,0,0,1,0],[0,0,0,1,0,1,0,0],[0,0,0,0,1,0,0,0]],"301":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,1,1,1,1,1,1,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]],"302":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[1,0,0,0,0,0,0,1],[0,1,1,1,1,1,1,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]],"303":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,1,1,1,1,1,1,0],[1,0,0,0,0,0,0,1],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]],"304":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[1,0,0,0,0,0,0,1],[0,1,0,0,0,0,1,0],[0,0,1,1,1,1,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]],"305":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[1,0,0,0,0,0,0,1],[0,1,0,0,0,0,1,0],[0,0,1,0,0,1,0,0],[0,0,0,1,1,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]],"306":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,1,0,0,0,0,1,0],[0,0,1,0,0,1,0,0],[0,0,0,1,1,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]],"307":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,1,1,0,0,0],[0,0,1,0,0,1,0,0],[0,1,0,0,0,0,1,0],[1,0,0,0,0,0,0,1],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]],"308":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,1,1,0,0,0],[0,0,1,0,0,1,0,0],[0,1,0,0,0,0,1,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]],"309":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,1,0],[1,0,0,0,0,1,0,1],[0,1,0,0,0,1,1,0],[0,0,1,1,1,1,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]],"310":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[1,1,1,1,1,1,1,1],[1,0,0,0,0,0,0,1],[0,1,0,0,0,0,1,0],[0,0,1,0,0,1,0,0],[0,0,0,1,1,0,0,0],[0,0,0,0,0,0,0,0]],"311":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[1,1,1,1,1,1,1,1],[1,0,0,0,0,0,0,1],[1,0,0,0,0,0,0,1],[0,1,0,0,0,0,1,0],[0,0,1,1,1,1,0,0],[0,0,0,0,0,0,0,0]],"312":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,1,1,1,1,0,0],[0,1,0,0,0,0,1,0],[0,1,0,0,0,0,1,0],[0,0,1,0,0,1,0,0],[0,0,0,1,1,0,0,0],[0,0,0,0,0,0,0,0]],"313":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,1,1,1,1,1,1,0],[0,1,0,0,0,0,1,0],[0,0,1,0,0,1,0,0],[0,0,0,1,1,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]],"314":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,1,1,1,1,0,0],[0,1,0,0,0,0,1,0],[1,0,0,0,0,0,0,1],[1,0,0,0,0,0,0,1],[1,1,1,1,1,1,1,1],[0,0,0,0,0,0,0,0]],"315":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,1,1,1,1,0,0],[0,1,0,0,0,0,1,0],[0,1,0,0,0,0,1,0],[1,0,0,0,0,0,0,1],[0,1,1,1,1,1,1,0],[0,0,0,0,0,0,0,0]],"316":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,1,1,0,0,0],[0,0,1,0,0,1,0,0],[0,1,0,0,0,0,1,0],[0,1,0,0,0,0,1,0],[0,0,1,0,0,1,0,0],[0,0,0,1,1,0,0,0]],"317":[[0,0,0,0,0,0,0,0],[0,0,0,1,1,0,0,0],[0,0,1,0,0,1,0,0],[0,0,1,0,0,1,0,0],[0,0,1,0,0,1,0,0],[0,0,1,0,0,1,0,0],[0,0,0,1,1,0,0,0],[0,0,0,0,0,0,0,0]],"318":[[0,0,0,1,1,0,0,0],[0,0,1,0,0,1,0,0],[0,0,1,0,0,1,0,0],[0,0,1,0,0,1,0,0],[0,0,1,0,0,1,0,0],[0,0,1,0,0,1,0,0],[0,0,0,1,1,0,0,0],[0,0,0,0,0,0,0,0]],"319":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,1,1,0,0,0],[0,0,1,0,0,1,0,0],[0,0,1,0,0,1,0,0],[0,0,0,1,1,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]],"320":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[1,1,1,1,1,1,1,1],[1,0,0,0,0,0,0,1],[1,1,1,1,1,1,1,1],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]],"321":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[1,1,1,1,1,1,1,1],[1,0,0,0,0,0,0,1],[0,1,1,1,1,1,1,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]],"322":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,1,1,1,1,1,1,0],[1,0,0,0,0,0,0,1],[1,1,1,1,1,1,1,1],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]],"323":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,1,1,1,1,1,1,0],[0,1,0,0,0,0,1,0],[0,0,1,1,1,1,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]],"324":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,1,1,1,1,0,0],[0,1,0,0,0,0,1,0],[0,1,1,1,1,1,1,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]],"325":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,1,1,1,1,1,1,0],[0,1,0,0,0,0,1,0],[0,1,1,1,1,1,1,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]],"326":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[1,0,0,0,0,0,0,1],[0,1,0,0,0,0,1,0],[0,1,1,1,1,1,1,0],[0,1,0,0,0,0,1,0],[1,0,0,0,0,0,0,1],[0,0,0,0,0,0,0,0]],"327":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,1,1,0,0,1,1,0],[1,0,0,1,1,0,0,1],[1,0,0,0,0,0,0,1],[1,0,0,1,1,0,0,1],[0,1,1,0,0,1,1,0],[0,0,0,0,0,0,0,0]],"328":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,1,1,0,0,1,1,0],[1,0,0,1,1,0,0,1],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]],"329":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,1,0,0,1,0,0],[0,1,0,1,1,0,1,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]],"330":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,1,0,0,0,0,1,0],[0,1,0,1,1,0,1,0],[0,0,1,0,0,1,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]],"331":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,1,0,0,0,0,1,0],[0,1,0,1,1,0,1,0],[0,0,1,0,0,1,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]],"332":[[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,1,0],[0,1,0,1,0,0,1,0],[0,0,1,0,1,1,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]],"400":[[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0]],"401":[[0,0,0,0],[0,1,1,0],[0,0,0,0],[0,0,0,0]],"402":[[0,0,0,0],[0,1,0,1],[0,0,0,0],[0,0,0,0]],"403":[[0,1,0,1],[1,0,1,0],[0,0,0,0],[0,0,0,0]],"404":[[1,0,1,0],[0,1,0,1],[0,0,0,0],[0,0,0,0]],"405":[[0,0,0,0],[0,1,1,1],[0,0,0,0],[0,1,1,1]]},"voiceDb":[{"id":0,"content":"璃奈板 笑眯眯"},{"id":1,"content":"璃奈板 害羞"},{"id":2,"content":"璃奈板 呒"},{"id":3,"content":"璃奈板 激动"},{"id":4,"content":"璃奈板 兴奋"},{"id":5,"content":"璃奈板 犀利"},{"id":6,"content":"璃奈板 熊熊燃烧"},{"id":7,"content":"璃奈板 ？"},{"id":8,"content":"璃奈板 啊哇哇"},{"id":9,"content":"璃奈板 头晕目眩"},{"id":10,"content":"璃奈板 呜"},{"id":11,"content":"璃奈板 沮丧"},{"id":12,"content":"璃奈板 泪眼汪汪"},{"id":13,"content":"璃奈板 感动"},{"id":14,"content":"璃奈板 啵哇旺"},{"id":15,"content":"璃奈板 闪闪发光"},{"id":16,"content":"璃奈板 高高兴兴"},{"id":17,"content":"璃奈板 点头"},{"id":18,"content":"璃奈板 V"},{"id":19,"content":"璃奈板 努力 冲"},{"id":20,"content":"璃奈板 加了个油"},{"id":21,"content":"璃奈板 干劲满满"},{"id":22,"content":"璃奈板 AAO"},{"id":23,"content":"璃奈板 竭尽全力嘞"},{"id":24,"content":"璃奈板 走吧"},{"id":25,"content":"璃奈板 加油"},{"id":26,"content":"璃奈板 加油啊"},{"id":27,"content":"璃奈板 鼓足气势"},{"id":28,"content":"璃奈板 大呼一口气"},{"id":29,"content":"璃奈板 好耶"},{"id":30,"content":"璃奈板 哇"},{"id":31,"content":"璃奈板 干的漂亮"},{"id":32,"content":"璃奈板 状态饱满"},{"id":33,"content":"璃奈板 超兴奋"},{"id":34,"content":"璃奈板 号角登登"},{"id":35,"content":"璃奈板 让我们上吧"},{"id":36,"content":"璃奈板 噜噜"},{"id":37,"content":"璃奈板 啦啦噜噜"},{"id":38,"content":"璃奈板 躁动不已"},{"id":39,"content":"璃奈板 兴奋不已"},{"id":40,"content":"璃奈板 激动兴奋"},{"id":41,"content":"璃奈板 激奋"},{"id":42,"content":"璃奈板 激动激动噜噜噜"},{"id":43,"content":"璃奈板 高高兴兴笑眯眯"},{"id":44,"content":"璃奈板 耶"},{"id":45,"content":"璃奈板 抿嘴一笑"},{"id":46,"content":"璃奈板 嘿嘿嘿"},{"id":47,"content":"璃奈板 窃笑"},{"id":48,"content":"璃奈板 嘲笑"},{"id":49,"content":"璃奈板 生气气"},{"id":50,"content":"璃奈板 气鼓鼓"},{"id":51,"content":"璃奈板 思索思索"},{"id":52,"content":"璃奈板 无奈"},{"id":53,"content":"璃奈板 无语"},{"id":54,"content":"璃奈板 无话可说"},{"id":55,"content":"璃奈板 哔哔哔"},{"id":56,"content":"璃奈板 哔空"},{"id":57,"content":"璃奈板 叮咚"},{"id":58,"content":"璃奈板 错错"},{"id":59,"content":"璃奈板 吓一跳"},{"id":60,"content":"璃奈板 完美"},{"id":61,"content":"璃奈板 得意"},{"id":62,"content":"璃奈板 咻咻"},{"id":63,"content":"璃奈板 闪亮亮"},{"id":64,"content":"璃奈板 闪亮"},{"id":65,"content":"璃奈板 亮"},{"id":66,"content":"璃奈板 大开灯"},{"id":67,"content":"璃奈板 嗨的很"},{"id":68,"content":"璃奈板 受惊"},{"id":69,"content":"璃奈板 颓废"},{"id":70,"content":"璃奈板 眼冒金星"},{"id":71,"content":"璃奈板 不可置信"},{"id":72,"content":"璃奈板 我倒"},{"id":73,"content":"璃奈板 我躺"},{"id":74,"content":"璃奈板 郁闷"},{"id":75,"content":"璃奈板 抽泣"},{"id":76,"content":"璃奈板 无精打采"},{"id":77,"content":"璃奈板 提不起劲"},{"id":78,"content":"璃奈板 喜出望外"},{"id":79,"content":"璃奈板 断然"},{"id":80,"content":"璃奈板 哼唧唧"},{"id":81,"content":"璃奈板 好气啊"},{"id":82,"content":"璃奈板 生气"},{"id":83,"content":"璃奈板 怒火中烧"},{"id":84,"content":"璃奈板 晃眼"},{"id":85,"content":"璃奈板 咽口水"},{"id":86,"content":"璃奈板 担心"},{"id":87,"content":"璃奈板 泪眼婆娑"},{"id":88,"content":"璃奈板 扭扭捏捏"},{"id":89,"content":"璃奈板 乖巧"},{"id":90,"content":"璃奈板 坐立不安"},{"id":91,"content":"璃奈板 起鸡皮疙瘩"},{"id":92,"content":"璃奈板 紧张兮兮"},{"id":93,"content":"璃奈板 哆哆嗦嗦"},{"id":94,"content":"璃奈板 瑟瑟发抖"},{"id":95,"content":"璃奈板 风尘仆仆"},{"id":96,"content":"璃奈板 筋疲力尽"},{"id":97,"content":"璃奈板 瘫倒无力"},{"id":98,"content":"璃奈板 晕倒"},{"id":99,"content":"璃奈板 吼"},{"id":100,"content":"璃奈板 落泪"},{"id":101,"content":"璃奈板 泪汪汪"},{"id":102,"content":"璃奈板 暖洋洋"},{"id":103,"content":"璃奈板 悠哉游哉"},{"id":104,"content":"璃奈板 心荡神驰"},{"id":105,"content":"璃奈板 发呆"},{"id":106,"content":"璃奈板 治愈"},{"id":107,"content":"璃奈板 暖心"},{"id":108,"content":"璃奈板 轻飘飘"},{"id":109,"content":"璃奈板 慢悠悠"},{"id":110,"content":"璃奈板 耐人寻味"},{"id":111,"content":"璃奈板 抱紧"},{"id":112,"content":"璃奈板 啾啾"},{"id":113,"content":"璃奈板 比心"},{"id":114,"content":"璃奈板 啾噜噜"},{"id":115,"content":"璃奈板 亲"},{"id":116,"content":"璃奈板 笑眯眯 笑眯眯"},{"id":117,"content":"璃奈板 笑容满面"},{"id":118,"content":"璃奈板 舔舌头"},{"id":119,"content":"璃奈板 咀嚼"},{"id":120,"content":"璃奈板 吹吹冷"},{"id":121,"content":"璃奈板 软乎乎"},{"id":122,"content":"璃奈板 太软啦"},{"id":123,"content":"璃奈板 吃饱饱"},{"id":124,"content":"璃奈板 困困"},{"id":125,"content":"璃奈板 傻眼"},{"id":126,"content":"璃奈板 闪亮登场"},{"id":127,"content":"璃奈板 坚定"},{"id":128,"content":"璃奈板 水灵灵"},{"id":129,"content":"璃奈板 哈喽"},{"id":130,"content":"璃奈板 早上中午晚上好"},{"id":131,"content":"璃奈板 欢迎回来"},{"id":132,"content":"璃奈板 不能摘下来"},{"id":133,"content":"璃奈板 嗨起来"},{"id":134,"content":"璃奈板 兔子跳"},{"id":135,"content":"璃奈板 喵喵"},{"id":136,"content":"璃奈板 喵"},{"id":137,"content":"璃奈板 收到"},{"id":138,"content":"璃奈板 开心"},{"id":139,"content":"璃奈板 热血沸腾"},{"id":140,"content":"璃奈板 谢谢"},{"id":141,"content":"璃奈板 接下来也请多关照了"},{"id":142,"content":"璃奈板 再见"}],"musicDb":[{"id":200001,"title":"TOKIMEKI Runners (心动逐梦人)","cover":"tkmk","artist":"虹ヶ咲学園スクールアイドル同好会","description":"手机游戏《Love Live!学园偶像祭 ALL STARS》主题曲，同时也是首张 专辑的主打歌。这首歌既是虹咲学园学园偶像同好会的起点，也是Live的定番歌曲。开场动画中由μ's、Aqours以及虹咲学园的三校27人一同表演的场面也令人印象深刻。"},{"id":209000,"title":"ツナガルコネクト (相连的connect)","cover":"solo0","artist":"天王寺璃奈","description":"TV动画《Love Live! 虹咲学园学园偶像同好会》第一季第6话插曲。不擅 表达感情的璃奈完全活用“小璃奈板”展开Solo Live时首度演出的歌曲。 歌词用“［Ctrl］+［Z］又没用”表现日常情境无法取消已说出的话，配上衬托擅长操作机械的璃奈的垫音，完整展现了璃奈独有特色。"},{"id":209001,"title":"ドキピポ☆エモーション (心跳☆加速)","cover":"solo1","artist":"天王寺璃奈","description":"虹咲学园学园偶像同好会首张专辑收录曲。SIFAS剧情2章插曲。璃奈的第一首Solo曲。描述的是不擅表达感情的璃奈在装上“小璃奈板”时的心境。整体而言是首电子音效突出的电波歌曲，“小璃奈板”呼声也是大家High起的定番桥段。"},{"id":209002,"title":"テレテレパシー (心灵心灵感应)","cover":"solo2","artist":"天王寺璃奈","description":"虹咲学园学园偶像同好会第二张专辑收录曲。SIFAS璃奈羁绊剧情12话插曲。在羁绊剧情中，璃奈首度卸下“小璃奈板”歌唱的歌曲。羁绊剧情第12话释出时引起了相当大的讨论。Live时挥舞心电感应杖的舞蹈也令人印象深刻。"},{"id":209003,"title":"アナログハート (电波之心)","cover":"solo3","artist":"天王寺璃奈","description":"虹咲学园学园偶像同好会第三张专辑收录曲。SIFAS璃奈羁绊剧情21话插曲。SIFAS羁绊剧情中，粉丝俱乐部活动时为了“想要静静地聆听璃奈的歌声”的粉丝们，选择线上转播的歌曲。曲中寄托了璃奈想要跟大家更加友好，更加密切的心愿。"},{"id":209004,"title":"First Love Again (再一次初恋)","cover":"solo4","artist":"天王寺璃奈","description":"虹咲学园学园偶像同好会第四张专辑收录曲。SIFAS璃奈羁绊剧情27话插曲。在羁绊剧情中，负责为电玩研究部拍的校内影像祭电影制作主题曲的璃奈挑战作曲的歌曲。描写记忆只能维持一天的主角心境，温柔窝心的抒情歌曲。"},{"id":209005,"title":"私はマグネット (我是磁石)","cover":"solo5","artist":"天王寺璃奈","description":"虹咲学园学园偶像同好会第五张专辑收录曲。由受邀参加学园偶像祭2的“学园偶像的日常”之“情歌嘉年华”的虹咲学园成员制作。因为从你那里得到了爱而获得救赎的璃奈。这首歌融合了澎湃的福音歌曲旋律，描绘出璃奈那辽阔的世界。"},{"id":200002,"title":"Love U my friends (爱你我的朋友们)","cover":"lumf","artist":"虹ヶ咲学園スクールアイドル同好会","description":"虹咲学园学园偶像同好会第二张专辑的主打歌，也是虹咲首度全员穿上相同舞台装的歌曲。开头成员们各自被打上自己代表色的姿态令人难忘。情感丰沛的吉他主奏，以及满满对你的感谢的歌词都令人热泪满盈。"}],"videoDb":[{"id":1,"title":"Call&Response前半","cover":"C&R01"},{"id":2,"title":"Call&Response后半","cover":"C&R02"},{"id":3,"title":"Call&Response前半(纯享)","cover":"C&R11"},{"id":4,"title":"Call&Response后半(纯享)","cover":"C&R12"},{"id":5,"title":"TV一期第六话Part1","cover":"TVS101"},{"id":6,"title":"TV一期第六话Part2","cover":"TVS102"},{"id":7,"title":"TV一期第六话Part3","cover":"TVS103"}],"voiceTimelines":{},"musicTimelines":{},"videoTimelines":{}};
window.RINA_UNITY_TIMELINE_MANIFEST={"version":3,"strategy":"lazy-load-timeline-packages","packaging":{"format":"rina-unity-timeline-package-v1","root":"/assets/unity_pack","note":"Small Unity timeline JSON assets are grouped into multiple gzip packages. WebUI loads only the package that contains the selected media and keeps only the selected timeline in memory."},"voice":[{"key":"voice_0","frames":9,"last_frame":24,"old_path":"/assets/unity_db/timeline_voice_voice_0.json","package":"/assets/unity_pack/pack_voice_000_015.json","package_key":"voice_0","package_asset_count":16},{"key":"voice_1","frames":8,"last_frame":22,"old_path":"/assets/unity_db/timeline_voice_voice_1.json","package":"/assets/unity_pack/pack_voice_000_015.json","package_key":"voice_1","package_asset_count":16},{"key":"voice_2","frames":6,"last_frame":15,"old_path":"/assets/unity_db/timeline_voice_voice_2.json","package":"/assets/unity_pack/pack_voice_000_015.json","package_key":"voice_2","package_asset_count":16},{"key":"voice_3","frames":9,"last_frame":21,"old_path":"/assets/unity_db/timeline_voice_voice_3.json","package":"/assets/unity_pack/pack_voice_000_015.json","package_key":"voice_3","package_asset_count":16},{"key":"voice_4","frames":8,"last_frame":19,"old_path":"/assets/unity_db/timeline_voice_voice_4.json","package":"/assets/unity_pack/pack_voice_000_015.json","package_key":"voice_4","package_asset_count":16},{"key":"voice_5","frames":5,"last_frame":14,"old_path":"/assets/unity_db/timeline_voice_voice_5.json","package":"/assets/unity_pack/pack_voice_000_015.json","package_key":"voice_5","package_asset_count":16},{"key":"voice_6","frames":9,"last_frame":32,"old_path":"/assets/unity_db/timeline_voice_voice_6.json","package":"/assets/unity_pack/pack_voice_000_015.json","package_key":"voice_6","package_asset_count":16},{"key":"voice_7","frames":5,"last_frame":16,"old_path":"/assets/unity_db/timeline_voice_voice_7.json","package":"/assets/unity_pack/pack_voice_000_015.json","package_key":"voice_7","package_asset_count":16},{"key":"voice_8","frames":11,"last_frame":22,"old_path":"/assets/unity_db/timeline_voice_voice_8.json","package":"/assets/unity_pack/pack_voice_000_015.json","package_key":"voice_8","package_asset_count":16},{"key":"voice_9","frames":8,"last_frame":26,"old_path":"/assets/unity_db/timeline_voice_voice_9.json","package":"/assets/unity_pack/pack_voice_000_015.json","package_key":"voice_9","package_asset_count":16},{"key":"voice_10","frames":4,"last_frame":20,"old_path":"/assets/unity_db/timeline_voice_voice_10.json","package":"/assets/unity_pack/pack_voice_000_015.json","package_key":"voice_10","package_asset_count":16},{"key":"voice_11","frames":8,"last_frame":23,"old_path":"/assets/unity_db/timeline_voice_voice_11.json","package":"/assets/unity_pack/pack_voice_000_015.json","package_key":"voice_11","package_asset_count":16},{"key":"voice_12","frames":10,"last_frame":24,"old_path":"/assets/unity_db/timeline_voice_voice_12.json","package":"/assets/unity_pack/pack_voice_000_015.json","package_key":"voice_12","package_asset_count":16},{"key":"voice_13","frames":8,"last_frame":29,"old_path":"/assets/unity_db/timeline_voice_voice_13.json","package":"/assets/unity_pack/pack_voice_000_015.json","package_key":"voice_13","package_asset_count":16},{"key":"voice_14","frames":8,"last_frame":23,"old_path":"/assets/unity_db/timeline_voice_voice_14.json","package":"/assets/unity_pack/pack_voice_000_015.json","package_key":"voice_14","package_asset_count":16},{"key":"voice_15","frames":7,"last_frame":19,"old_path":"/assets/unity_db/timeline_voice_voice_15.json","package":"/assets/unity_pack/pack_voice_000_015.json","package_key":"voice_15","package_asset_count":16},{"key":"voice_16","frames":10,"last_frame":20,"old_path":"/assets/unity_db/timeline_voice_voice_16.json","package":"/assets/unity_pack/pack_voice_016_031.json","package_key":"voice_16","package_asset_count":16},{"key":"voice_17","frames":9,"last_frame":202,"old_path":"/assets/unity_db/timeline_voice_voice_17.json","package":"/assets/unity_pack/pack_voice_016_031.json","package_key":"voice_17","package_asset_count":16},{"key":"voice_18","frames":6,"last_frame":14,"old_path":"/assets/unity_db/timeline_voice_voice_18.json","package":"/assets/unity_pack/pack_voice_016_031.json","package_key":"voice_18","package_asset_count":16},{"key":"voice_19","frames":11,"last_frame":40,"old_path":"/assets/unity_db/timeline_voice_voice_19.json","package":"/assets/unity_pack/pack_voice_016_031.json","package_key":"voice_19","package_asset_count":16},{"key":"voice_20","frames":11,"last_frame":25,"old_path":"/assets/unity_db/timeline_voice_voice_20.json","package":"/assets/unity_pack/pack_voice_016_031.json","package_key":"voice_20","package_asset_count":16},{"key":"voice_21","frames":12,"last_frame":27,"old_path":"/assets/unity_db/timeline_voice_voice_21.json","package":"/assets/unity_pack/pack_voice_016_031.json","package_key":"voice_21","package_asset_count":16},{"key":"voice_22","frames":9,"last_frame":34,"old_path":"/assets/unity_db/timeline_voice_voice_22.json","package":"/assets/unity_pack/pack_voice_016_031.json","package_key":"voice_22","package_asset_count":16},{"key":"voice_23","frames":9,"last_frame":26,"old_path":"/assets/unity_db/timeline_voice_voice_23.json","package":"/assets/unity_pack/pack_voice_016_031.json","package_key":"voice_23","package_asset_count":16},{"key":"voice_24","frames":10,"last_frame":28,"old_path":"/assets/unity_db/timeline_voice_voice_24.json","package":"/assets/unity_pack/pack_voice_016_031.json","package_key":"voice_24","package_asset_count":16},{"key":"voice_25","frames":7,"last_frame":17,"old_path":"/assets/unity_db/timeline_voice_voice_25.json","package":"/assets/unity_pack/pack_voice_016_031.json","package_key":"voice_25","package_asset_count":16},{"key":"voice_26","frames":8,"last_frame":20,"old_path":"/assets/unity_db/timeline_voice_voice_26.json","package":"/assets/unity_pack/pack_voice_016_031.json","package_key":"voice_26","package_asset_count":16},{"key":"voice_27","frames":8,"last_frame":28,"old_path":"/assets/unity_db/timeline_voice_voice_27.json","package":"/assets/unity_pack/pack_voice_016_031.json","package_key":"voice_27","package_asset_count":16},{"key":"voice_28","frames":8,"last_frame":20,"old_path":"/assets/unity_db/timeline_voice_voice_28.json","package":"/assets/unity_pack/pack_voice_016_031.json","package_key":"voice_28","package_asset_count":16},{"key":"voice_29","frames":9,"last_frame":23,"old_path":"/assets/unity_db/timeline_voice_voice_29.json","package":"/assets/unity_pack/pack_voice_016_031.json","package_key":"voice_29","package_asset_count":16},{"key":"voice_30","frames":9,"last_frame":25,"old_path":"/assets/unity_db/timeline_voice_voice_30.json","package":"/assets/unity_pack/pack_voice_016_031.json","package_key":"voice_30","package_asset_count":16},{"key":"voice_31","frames":6,"last_frame":16,"old_path":"/assets/unity_db/timeline_voice_voice_31.json","package":"/assets/unity_pack/pack_voice_016_031.json","package_key":"voice_31","package_asset_count":16},{"key":"voice_32","frames":8,"last_frame":21,"old_path":"/assets/unity_db/timeline_voice_voice_32.json","package":"/assets/unity_pack/pack_voice_032_047.json","package_key":"voice_32","package_asset_count":16},{"key":"voice_33","frames":8,"last_frame":23,"old_path":"/assets/unity_db/timeline_voice_voice_33.json","package":"/assets/unity_pack/pack_voice_032_047.json","package_key":"voice_33","package_asset_count":16},{"key":"voice_34","frames":9,"last_frame":34,"old_path":"/assets/unity_db/timeline_voice_voice_34.json","package":"/assets/unity_pack/pack_voice_032_047.json","package_key":"voice_34","package_asset_count":16},{"key":"voice_35","frames":8,"last_frame":22,"old_path":"/assets/unity_db/timeline_voice_voice_35.json","package":"/assets/unity_pack/pack_voice_032_047.json","package_key":"voice_35","package_asset_count":16},{"key":"voice_36","frames":10,"last_frame":25,"old_path":"/assets/unity_db/timeline_voice_voice_36.json","package":"/assets/unity_pack/pack_voice_032_047.json","package_key":"voice_36","package_asset_count":16},{"key":"voice_37","frames":14,"last_frame":34,"old_path":"/assets/unity_db/timeline_voice_voice_37.json","package":"/assets/unity_pack/pack_voice_032_047.json","package_key":"voice_37","package_asset_count":16},{"key":"voice_38","frames":11,"last_frame":24,"old_path":"/assets/unity_db/timeline_voice_voice_38.json","package":"/assets/unity_pack/pack_voice_032_047.json","package_key":"voice_38","package_asset_count":16},{"key":"voice_39","frames":13,"last_frame":35,"old_path":"/assets/unity_db/timeline_voice_voice_39.json","package":"/assets/unity_pack/pack_voice_032_047.json","package_key":"voice_39","package_asset_count":16},{"key":"voice_40","frames":13,"last_frame":43,"old_path":"/assets/unity_db/timeline_voice_voice_40.json","package":"/assets/unity_pack/pack_voice_032_047.json","package_key":"voice_40","package_asset_count":16},{"key":"voice_41","frames":11,"last_frame":23,"old_path":"/assets/unity_db/timeline_voice_voice_41.json","package":"/assets/unity_pack/pack_voice_032_047.json","package_key":"voice_41","package_asset_count":16},{"key":"voice_42","frames":11,"last_frame":38,"old_path":"/assets/unity_db/timeline_voice_voice_42.json","package":"/assets/unity_pack/pack_voice_032_047.json","package_key":"voice_42","package_asset_count":16},{"key":"voice_43","frames":15,"last_frame":36,"old_path":"/assets/unity_db/timeline_voice_voice_43.json","package":"/assets/unity_pack/pack_voice_032_047.json","package_key":"voice_43","package_asset_count":16},{"key":"voice_44","frames":7,"last_frame":17,"old_path":"/assets/unity_db/timeline_voice_voice_44.json","package":"/assets/unity_pack/pack_voice_032_047.json","package_key":"voice_44","package_asset_count":16},{"key":"voice_45","frames":5,"last_frame":17,"old_path":"/assets/unity_db/timeline_voice_voice_45.json","package":"/assets/unity_pack/pack_voice_032_047.json","package_key":"voice_45","package_asset_count":16},{"key":"voice_46","frames":5,"last_frame":22,"old_path":"/assets/unity_db/timeline_voice_voice_46.json","package":"/assets/unity_pack/pack_voice_032_047.json","package_key":"voice_46","package_asset_count":16},{"key":"voice_47","frames":7,"last_frame":18,"old_path":"/assets/unity_db/timeline_voice_voice_47.json","package":"/assets/unity_pack/pack_voice_032_047.json","package_key":"voice_47","package_asset_count":16},{"key":"voice_48","frames":5,"last_frame":17,"old_path":"/assets/unity_db/timeline_voice_voice_48.json","package":"/assets/unity_pack/pack_voice_048_063.json","package_key":"voice_48","package_asset_count":16},{"key":"voice_49","frames":5,"last_frame":16,"old_path":"/assets/unity_db/timeline_voice_voice_49.json","package":"/assets/unity_pack/pack_voice_048_063.json","package_key":"voice_49","package_asset_count":16},{"key":"voice_50","frames":6,"last_frame":20,"old_path":"/assets/unity_db/timeline_voice_voice_50.json","package":"/assets/unity_pack/pack_voice_048_063.json","package_key":"voice_50","package_asset_count":16},{"key":"voice_51","frames":9,"last_frame":29,"old_path":"/assets/unity_db/timeline_voice_voice_51.json","package":"/assets/unity_pack/pack_voice_048_063.json","package_key":"voice_51","package_asset_count":16},{"key":"voice_52","frames":5,"last_frame":21,"old_path":"/assets/unity_db/timeline_voice_voice_52.json","package":"/assets/unity_pack/pack_voice_048_063.json","package_key":"voice_52","package_asset_count":16},{"key":"voice_53","frames":5,"last_frame":17,"old_path":"/assets/unity_db/timeline_voice_voice_53.json","package":"/assets/unity_pack/pack_voice_048_063.json","package_key":"voice_53","package_asset_count":16},{"key":"voice_54","frames":5,"last_frame":18,"old_path":"/assets/unity_db/timeline_voice_voice_54.json","package":"/assets/unity_pack/pack_voice_048_063.json","package_key":"voice_54","package_asset_count":16},{"key":"voice_55","frames":8,"last_frame":24,"old_path":"/assets/unity_db/timeline_voice_voice_55.json","package":"/assets/unity_pack/pack_voice_048_063.json","package_key":"voice_55","package_asset_count":16},{"key":"voice_56","frames":6,"last_frame":23,"old_path":"/assets/unity_db/timeline_voice_voice_56.json","package":"/assets/unity_pack/pack_voice_048_063.json","package_key":"voice_56","package_asset_count":16},{"key":"voice_57","frames":7,"last_frame":16,"old_path":"/assets/unity_db/timeline_voice_voice_57.json","package":"/assets/unity_pack/pack_voice_048_063.json","package_key":"voice_57","package_asset_count":16},{"key":"voice_58","frames":6,"last_frame":16,"old_path":"/assets/unity_db/timeline_voice_voice_58.json","package":"/assets/unity_pack/pack_voice_048_063.json","package_key":"voice_58","package_asset_count":16},{"key":"voice_59","frames":7,"last_frame":21,"old_path":"/assets/unity_db/timeline_voice_voice_59.json","package":"/assets/unity_pack/pack_voice_048_063.json","package_key":"voice_59","package_asset_count":16},{"key":"voice_60","frames":8,"last_frame":21,"old_path":"/assets/unity_db/timeline_voice_voice_60.json","package":"/assets/unity_pack/pack_voice_048_063.json","package_key":"voice_60","package_asset_count":16},{"key":"voice_61","frames":8,"last_frame":27,"old_path":"/assets/unity_db/timeline_voice_voice_61.json","package":"/assets/unity_pack/pack_voice_048_063.json","package_key":"voice_61","package_asset_count":16},{"key":"voice_62","frames":9,"last_frame":26,"old_path":"/assets/unity_db/timeline_voice_voice_62.json","package":"/assets/unity_pack/pack_voice_048_063.json","package_key":"voice_62","package_asset_count":16},{"key":"voice_63","frames":8,"last_frame":20,"old_path":"/assets/unity_db/timeline_voice_voice_63.json","package":"/assets/unity_pack/pack_voice_048_063.json","package_key":"voice_63","package_asset_count":16},{"key":"voice_64","frames":9,"last_frame":23,"old_path":"/assets/unity_db/timeline_voice_voice_64.json","package":"/assets/unity_pack/pack_voice_064_079.json","package_key":"voice_64","package_asset_count":16},{"key":"voice_65","frames":7,"last_frame":23,"old_path":"/assets/unity_db/timeline_voice_voice_65.json","package":"/assets/unity_pack/pack_voice_064_079.json","package_key":"voice_65","package_asset_count":16},{"key":"voice_66","frames":7,"last_frame":17,"old_path":"/assets/unity_db/timeline_voice_voice_66.json","package":"/assets/unity_pack/pack_voice_064_079.json","package_key":"voice_66","package_asset_count":16},{"key":"voice_67","frames":8,"last_frame":24,"old_path":"/assets/unity_db/timeline_voice_voice_67.json","package":"/assets/unity_pack/pack_voice_064_079.json","package_key":"voice_67","package_asset_count":16},{"key":"voice_68","frames":5,"last_frame":21,"old_path":"/assets/unity_db/timeline_voice_voice_68.json","package":"/assets/unity_pack/pack_voice_064_079.json","package_key":"voice_68","package_asset_count":16},{"key":"voice_69","frames":7,"last_frame":24,"old_path":"/assets/unity_db/timeline_voice_voice_69.json","package":"/assets/unity_pack/pack_voice_064_079.json","package_key":"voice_69","package_asset_count":16},{"key":"voice_70","frames":8,"last_frame":24,"old_path":"/assets/unity_db/timeline_voice_voice_70.json","package":"/assets/unity_pack/pack_voice_064_079.json","package_key":"voice_70","package_asset_count":16},{"key":"voice_71","frames":7,"last_frame":31,"old_path":"/assets/unity_db/timeline_voice_voice_71.json","package":"/assets/unity_pack/pack_voice_064_079.json","package_key":"voice_71","package_asset_count":16},{"key":"voice_72","frames":6,"last_frame":21,"old_path":"/assets/unity_db/timeline_voice_voice_72.json","package":"/assets/unity_pack/pack_voice_064_079.json","package_key":"voice_72","package_asset_count":16},{"key":"voice_73","frames":4,"last_frame":25,"old_path":"/assets/unity_db/timeline_voice_voice_73.json","package":"/assets/unity_pack/pack_voice_064_079.json","package_key":"voice_73","package_asset_count":16},{"key":"voice_74","frames":7,"last_frame":29,"old_path":"/assets/unity_db/timeline_voice_voice_74.json","package":"/assets/unity_pack/pack_voice_064_079.json","package_key":"voice_74","package_asset_count":16},{"key":"voice_75","frames":5,"last_frame":19,"old_path":"/assets/unity_db/timeline_voice_voice_75.json","package":"/assets/unity_pack/pack_voice_064_079.json","package_key":"voice_75","package_asset_count":16},{"key":"voice_76","frames":9,"last_frame":26,"old_path":"/assets/unity_db/timeline_voice_voice_76.json","package":"/assets/unity_pack/pack_voice_064_079.json","package_key":"voice_76","package_asset_count":16},{"key":"voice_77","frames":6,"last_frame":29,"old_path":"/assets/unity_db/timeline_voice_voice_77.json","package":"/assets/unity_pack/pack_voice_064_079.json","package_key":"voice_77","package_asset_count":16},{"key":"voice_78","frames":6,"last_frame":17,"old_path":"/assets/unity_db/timeline_voice_voice_78.json","package":"/assets/unity_pack/pack_voice_064_079.json","package_key":"voice_78","package_asset_count":16},{"key":"voice_79","frames":7,"last_frame":19,"old_path":"/assets/unity_db/timeline_voice_voice_79.json","package":"/assets/unity_pack/pack_voice_064_079.json","package_key":"voice_79","package_asset_count":16},{"key":"voice_80","frames":5,"last_frame":17,"old_path":"/assets/unity_db/timeline_voice_voice_80.json","package":"/assets/unity_pack/pack_voice_080_095.json","package_key":"voice_80","package_asset_count":16},{"key":"voice_81","frames":7,"last_frame":20,"old_path":"/assets/unity_db/timeline_voice_voice_81.json","package":"/assets/unity_pack/pack_voice_080_095.json","package_key":"voice_81","package_asset_count":16},{"key":"voice_82","frames":8,"last_frame":21,"old_path":"/assets/unity_db/timeline_voice_voice_82.json","package":"/assets/unity_pack/pack_voice_080_095.json","package_key":"voice_82","package_asset_count":16},{"key":"voice_83","frames":10,"last_frame":24,"old_path":"/assets/unity_db/timeline_voice_voice_83.json","package":"/assets/unity_pack/pack_voice_080_095.json","package_key":"voice_83","package_asset_count":16},{"key":"voice_84","frames":9,"last_frame":26,"old_path":"/assets/unity_db/timeline_voice_voice_84.json","package":"/assets/unity_pack/pack_voice_080_095.json","package_key":"voice_84","package_asset_count":16},{"key":"voice_85","frames":5,"last_frame":19,"old_path":"/assets/unity_db/timeline_voice_voice_85.json","package":"/assets/unity_pack/pack_voice_080_095.json","package_key":"voice_85","package_asset_count":16},{"key":"voice_86","frames":9,"last_frame":21,"old_path":"/assets/unity_db/timeline_voice_voice_86.json","package":"/assets/unity_pack/pack_voice_080_095.json","package_key":"voice_86","package_asset_count":16},{"key":"voice_87","frames":10,"last_frame":23,"old_path":"/assets/unity_db/timeline_voice_voice_87.json","package":"/assets/unity_pack/pack_voice_080_095.json","package_key":"voice_87","package_asset_count":16},{"key":"voice_88","frames":9,"last_frame":26,"old_path":"/assets/unity_db/timeline_voice_voice_88.json","package":"/assets/unity_pack/pack_voice_080_095.json","package_key":"voice_88","package_asset_count":16},{"key":"voice_89","frames":9,"last_frame":26,"old_path":"/assets/unity_db/timeline_voice_voice_89.json","package":"/assets/unity_pack/pack_voice_080_095.json","package_key":"voice_89","package_asset_count":16},{"key":"voice_90","frames":8,"last_frame":30,"old_path":"/assets/unity_db/timeline_voice_voice_90.json","package":"/assets/unity_pack/pack_voice_080_095.json","package_key":"voice_90","package_asset_count":16},{"key":"voice_91","frames":7,"last_frame":16,"old_path":"/assets/unity_db/timeline_voice_voice_91.json","package":"/assets/unity_pack/pack_voice_080_095.json","package_key":"voice_91","package_asset_count":16},{"key":"voice_92","frames":5,"last_frame":18,"old_path":"/assets/unity_db/timeline_voice_voice_92.json","package":"/assets/unity_pack/pack_voice_080_095.json","package_key":"voice_92","package_asset_count":16},{"key":"voice_93","frames":9,"last_frame":23,"old_path":"/assets/unity_db/timeline_voice_voice_93.json","package":"/assets/unity_pack/pack_voice_080_095.json","package_key":"voice_93","package_asset_count":16},{"key":"voice_94","frames":8,"last_frame":25,"old_path":"/assets/unity_db/timeline_voice_voice_94.json","package":"/assets/unity_pack/pack_voice_080_095.json","package_key":"voice_94","package_asset_count":16},{"key":"voice_95","frames":8,"last_frame":27,"old_path":"/assets/unity_db/timeline_voice_voice_95.json","package":"/assets/unity_pack/pack_voice_080_095.json","package_key":"voice_95","package_asset_count":16},{"key":"voice_96","frames":11,"last_frame":31,"old_path":"/assets/unity_db/timeline_voice_voice_96.json","package":"/assets/unity_pack/pack_voice_096_111.json","package_key":"voice_96","package_asset_count":16},{"key":"voice_97","frames":7,"last_frame":29,"old_path":"/assets/unity_db/timeline_voice_voice_97.json","package":"/assets/unity_pack/pack_voice_096_111.json","package_key":"voice_97","package_asset_count":16},{"key":"voice_98","frames":7,"last_frame":24,"old_path":"/assets/unity_db/timeline_voice_voice_98.json","package":"/assets/unity_pack/pack_voice_096_111.json","package_key":"voice_98","package_asset_count":16},{"key":"voice_99","frames":5,"last_frame":18,"old_path":"/assets/unity_db/timeline_voice_voice_99.json","package":"/assets/unity_pack/pack_voice_096_111.json","package_key":"voice_99","package_asset_count":16},{"key":"voice_100","frames":5,"last_frame":19,"old_path":"/assets/unity_db/timeline_voice_voice_100.json","package":"/assets/unity_pack/pack_voice_096_111.json","package_key":"voice_100","package_asset_count":16},{"key":"voice_101","frames":7,"last_frame":17,"old_path":"/assets/unity_db/timeline_voice_voice_101.json","package":"/assets/unity_pack/pack_voice_096_111.json","package_key":"voice_101","package_asset_count":16},{"key":"voice_102","frames":7,"last_frame":24,"old_path":"/assets/unity_db/timeline_voice_voice_102.json","package":"/assets/unity_pack/pack_voice_096_111.json","package_key":"voice_102","package_asset_count":16},{"key":"voice_103","frames":6,"last_frame":26,"old_path":"/assets/unity_db/timeline_voice_voice_103.json","package":"/assets/unity_pack/pack_voice_096_111.json","package_key":"voice_103","package_asset_count":16},{"key":"voice_104","frames":6,"last_frame":24,"old_path":"/assets/unity_db/timeline_voice_voice_104.json","package":"/assets/unity_pack/pack_voice_096_111.json","package_key":"voice_104","package_asset_count":16},{"key":"voice_105","frames":7,"last_frame":17,"old_path":"/assets/unity_db/timeline_voice_voice_105.json","package":"/assets/unity_pack/pack_voice_096_111.json","package_key":"voice_105","package_asset_count":16},{"key":"voice_106","frames":8,"last_frame":25,"old_path":"/assets/unity_db/timeline_voice_voice_106.json","package":"/assets/unity_pack/pack_voice_096_111.json","package_key":"voice_106","package_asset_count":16},{"key":"voice_107","frames":8,"last_frame":28,"old_path":"/assets/unity_db/timeline_voice_voice_107.json","package":"/assets/unity_pack/pack_voice_096_111.json","package_key":"voice_107","package_asset_count":16},{"key":"voice_108","frames":9,"last_frame":38,"old_path":"/assets/unity_db/timeline_voice_voice_108.json","package":"/assets/unity_pack/pack_voice_096_111.json","package_key":"voice_108","package_asset_count":16},{"key":"voice_109","frames":9,"last_frame":30,"old_path":"/assets/unity_db/timeline_voice_voice_109.json","package":"/assets/unity_pack/pack_voice_096_111.json","package_key":"voice_109","package_asset_count":16},{"key":"voice_110","frames":8,"last_frame":24,"old_path":"/assets/unity_db/timeline_voice_voice_110.json","package":"/assets/unity_pack/pack_voice_096_111.json","package_key":"voice_110","package_asset_count":16},{"key":"voice_111","frames":5,"last_frame":18,"old_path":"/assets/unity_db/timeline_voice_voice_111.json","package":"/assets/unity_pack/pack_voice_096_111.json","package_key":"voice_111","package_asset_count":16},{"key":"voice_112","frames":5,"last_frame":15,"old_path":"/assets/unity_db/timeline_voice_voice_112.json","package":"/assets/unity_pack/pack_voice_112_127.json","package_key":"voice_112","package_asset_count":16},{"key":"voice_113","frames":9,"last_frame":21,"old_path":"/assets/unity_db/timeline_voice_voice_113.json","package":"/assets/unity_pack/pack_voice_112_127.json","package_key":"voice_113","package_asset_count":16},{"key":"voice_114","frames":6,"last_frame":15,"old_path":"/assets/unity_db/timeline_voice_voice_114.json","package":"/assets/unity_pack/pack_voice_112_127.json","package_key":"voice_114","package_asset_count":16},{"key":"voice_115","frames":7,"last_frame":20,"old_path":"/assets/unity_db/timeline_voice_voice_115.json","package":"/assets/unity_pack/pack_voice_112_127.json","package_key":"voice_115","package_asset_count":16},{"key":"voice_116","frames":9,"last_frame":33,"old_path":"/assets/unity_db/timeline_voice_voice_116.json","package":"/assets/unity_pack/pack_voice_112_127.json","package_key":"voice_116","package_asset_count":16},{"key":"voice_117","frames":11,"last_frame":26,"old_path":"/assets/unity_db/timeline_voice_voice_117.json","package":"/assets/unity_pack/pack_voice_112_127.json","package_key":"voice_117","package_asset_count":16},{"key":"voice_118","frames":6,"last_frame":15,"old_path":"/assets/unity_db/timeline_voice_voice_118.json","package":"/assets/unity_pack/pack_voice_112_127.json","package_key":"voice_118","package_asset_count":16},{"key":"voice_119","frames":8,"last_frame":28,"old_path":"/assets/unity_db/timeline_voice_voice_119.json","package":"/assets/unity_pack/pack_voice_112_127.json","package_key":"voice_119","package_asset_count":16},{"key":"voice_120","frames":9,"last_frame":23,"old_path":"/assets/unity_db/timeline_voice_voice_120.json","package":"/assets/unity_pack/pack_voice_112_127.json","package_key":"voice_120","package_asset_count":16},{"key":"voice_121","frames":8,"last_frame":27,"old_path":"/assets/unity_db/timeline_voice_voice_121.json","package":"/assets/unity_pack/pack_voice_112_127.json","package_key":"voice_121","package_asset_count":16},{"key":"voice_122","frames":13,"last_frame":28,"old_path":"/assets/unity_db/timeline_voice_voice_122.json","package":"/assets/unity_pack/pack_voice_112_127.json","package_key":"voice_122","package_asset_count":16},{"key":"voice_123","frames":8,"last_frame":34,"old_path":"/assets/unity_db/timeline_voice_voice_123.json","package":"/assets/unity_pack/pack_voice_112_127.json","package_key":"voice_123","package_asset_count":16},{"key":"voice_124","frames":9,"last_frame":33,"old_path":"/assets/unity_db/timeline_voice_voice_124.json","package":"/assets/unity_pack/pack_voice_112_127.json","package_key":"voice_124","package_asset_count":16},{"key":"voice_125","frames":10,"last_frame":20,"old_path":"/assets/unity_db/timeline_voice_voice_125.json","package":"/assets/unity_pack/pack_voice_112_127.json","package_key":"voice_125","package_asset_count":16},{"key":"voice_126","frames":8,"last_frame":23,"old_path":"/assets/unity_db/timeline_voice_voice_126.json","package":"/assets/unity_pack/pack_voice_112_127.json","package_key":"voice_126","package_asset_count":16},{"key":"voice_127","frames":10,"last_frame":21,"old_path":"/assets/unity_db/timeline_voice_voice_127.json","package":"/assets/unity_pack/pack_voice_112_127.json","package_key":"voice_127","package_asset_count":16},{"key":"voice_128","frames":8,"last_frame":18,"old_path":"/assets/unity_db/timeline_voice_voice_128.json","package":"/assets/unity_pack/pack_voice_128_142.json","package_key":"voice_128","package_asset_count":15},{"key":"voice_129","frames":7,"last_frame":15,"old_path":"/assets/unity_db/timeline_voice_voice_129.json","package":"/assets/unity_pack/pack_voice_128_142.json","package_key":"voice_129","package_asset_count":15},{"key":"voice_130","frames":11,"last_frame":28,"old_path":"/assets/unity_db/timeline_voice_voice_130.json","package":"/assets/unity_pack/pack_voice_128_142.json","package_key":"voice_130","package_asset_count":15},{"key":"voice_131","frames":9,"last_frame":22,"old_path":"/assets/unity_db/timeline_voice_voice_131.json","package":"/assets/unity_pack/pack_voice_128_142.json","package_key":"voice_131","package_asset_count":15},{"key":"voice_132","frames":9,"last_frame":20,"old_path":"/assets/unity_db/timeline_voice_voice_132.json","package":"/assets/unity_pack/pack_voice_128_142.json","package_key":"voice_132","package_asset_count":15},{"key":"voice_133","frames":9,"last_frame":20,"old_path":"/assets/unity_db/timeline_voice_voice_133.json","package":"/assets/unity_pack/pack_voice_128_142.json","package_key":"voice_133","package_asset_count":15},{"key":"voice_134","frames":10,"last_frame":22,"old_path":"/assets/unity_db/timeline_voice_voice_134.json","package":"/assets/unity_pack/pack_voice_128_142.json","package_key":"voice_134","package_asset_count":15},{"key":"voice_135","frames":10,"last_frame":23,"old_path":"/assets/unity_db/timeline_voice_voice_135.json","package":"/assets/unity_pack/pack_voice_128_142.json","package_key":"voice_135","package_asset_count":15},{"key":"voice_136","frames":6,"last_frame":14,"old_path":"/assets/unity_db/timeline_voice_voice_136.json","package":"/assets/unity_pack/pack_voice_128_142.json","package_key":"voice_136","package_asset_count":15},{"key":"voice_137","frames":7,"last_frame":22,"old_path":"/assets/unity_db/timeline_voice_voice_137.json","package":"/assets/unity_pack/pack_voice_128_142.json","package_key":"voice_137","package_asset_count":15},{"key":"voice_138","frames":6,"last_frame":15,"old_path":"/assets/unity_db/timeline_voice_voice_138.json","package":"/assets/unity_pack/pack_voice_128_142.json","package_key":"voice_138","package_asset_count":15},{"key":"voice_139","frames":8,"last_frame":19,"old_path":"/assets/unity_db/timeline_voice_voice_139.json","package":"/assets/unity_pack/pack_voice_128_142.json","package_key":"voice_139","package_asset_count":15},{"key":"voice_140","frames":7,"last_frame":21,"old_path":"/assets/unity_db/timeline_voice_voice_140.json","package":"/assets/unity_pack/pack_voice_128_142.json","package_key":"voice_140","package_asset_count":15},{"key":"voice_141","frames":13,"last_frame":27,"old_path":"/assets/unity_db/timeline_voice_voice_141.json","package":"/assets/unity_pack/pack_voice_128_142.json","package_key":"voice_141","package_asset_count":15},{"key":"voice_142","frames":8,"last_frame":16,"old_path":"/assets/unity_db/timeline_voice_voice_142.json","package":"/assets/unity_pack/pack_voice_128_142.json","package_key":"voice_142","package_asset_count":15}],"music":[{"key":"lumf","frames":171,"last_frame":1031,"old_path":"/assets/unity_db/timeline_music_lumf.json","package":"/assets/unity_pack/pack_music_lumf_solo0.json","package_key":"lumf","package_asset_count":2},{"key":"solo0","frames":320,"last_frame":968,"old_path":"/assets/unity_db/timeline_music_solo0.json","package":"/assets/unity_pack/pack_music_lumf_solo0.json","package_key":"solo0","package_asset_count":2},{"key":"solo1","frames":273,"last_frame":901,"old_path":"/assets/unity_db/timeline_music_solo1.json","package":"/assets/unity_pack/pack_music_solo1_solo2.json","package_key":"solo1","package_asset_count":2},{"key":"solo2","frames":282,"last_frame":1120,"old_path":"/assets/unity_db/timeline_music_solo2.json","package":"/assets/unity_pack/pack_music_solo1_solo2.json","package_key":"solo2","package_asset_count":2},{"key":"solo3","frames":302,"last_frame":1039,"old_path":"/assets/unity_db/timeline_music_solo3.json","package":"/assets/unity_pack/pack_music_solo3_solo4.json","package_key":"solo3","package_asset_count":2},{"key":"solo4","frames":199,"last_frame":1191,"old_path":"/assets/unity_db/timeline_music_solo4.json","package":"/assets/unity_pack/pack_music_solo3_solo4.json","package_key":"solo4","package_asset_count":2},{"key":"solo5","frames":238,"last_frame":912,"old_path":"/assets/unity_db/timeline_music_solo5.json","package":"/assets/unity_pack/pack_music_solo5_tkmk.json","package_key":"solo5","package_asset_count":2},{"key":"tkmk","frames":262,"last_frame":871,"old_path":"/assets/unity_db/timeline_music_tkmk.json","package":"/assets/unity_pack/pack_music_solo5_tkmk.json","package_key":"tkmk","package_asset_count":2}],"video":[{"key":"C&R01","frames":2,"last_frame":20,"old_path":"/assets/unity_db/timeline_video_C_R01.json","package":"/assets/unity_pack/pack_video_small.json","package_key":"C&R01","package_asset_count":6},{"key":"C&R02","frames":7,"last_frame":245,"old_path":"/assets/unity_db/timeline_video_C_R02.json","package":"/assets/unity_pack/pack_video_small.json","package_key":"C&R02","package_asset_count":6},{"key":"C&R11","frames":2,"last_frame":20,"old_path":"/assets/unity_db/timeline_video_C_R11.json","package":"/assets/unity_pack/pack_video_small.json","package_key":"C&R11","package_asset_count":6},{"key":"C&R12","frames":4,"last_frame":110,"old_path":"/assets/unity_db/timeline_video_C_R12.json","package":"/assets/unity_pack/pack_video_small.json","package_key":"C&R12","package_asset_count":6},{"key":"TVS101","frames":4,"last_frame":233,"old_path":"/assets/unity_db/timeline_video_TVS101.json","package":"/assets/unity_pack/pack_video_small.json","package_key":"TVS101","package_asset_count":6},{"key":"TVS103","frames":3,"last_frame":229,"old_path":"/assets/unity_db/timeline_video_TVS103.json","package":"/assets/unity_pack/pack_video_small.json","package_key":"TVS103","package_asset_count":6},{"key":"TVS102","frames":320,"last_frame":968,"old_path":"/assets/unity_db/timeline_video_TVS102.json","package":"/assets/unity_pack/pack_video_TVS102.json","package_key":"TVS102","package_asset_count":1}],"voiceDb":[{"id":0,"content":"璃奈板 笑眯眯"},{"id":1,"content":"璃奈板 害羞"},{"id":2,"content":"璃奈板 呒"},{"id":3,"content":"璃奈板 激动"},{"id":4,"content":"璃奈板 兴奋"},{"id":5,"content":"璃奈板 犀利"},{"id":6,"content":"璃奈板 熊熊燃烧"},{"id":7,"content":"璃奈板 ？"},{"id":8,"content":"璃奈板 啊哇哇"},{"id":9,"content":"璃奈板 头晕目眩"},{"id":10,"content":"璃奈板 呜"},{"id":11,"content":"璃奈板 沮丧"},{"id":12,"content":"璃奈板 泪眼汪汪"},{"id":13,"content":"璃奈板 感动"},{"id":14,"content":"璃奈板 啵哇旺"},{"id":15,"content":"璃奈板 闪闪发光"},{"id":16,"content":"璃奈板 高高兴兴"},{"id":17,"content":"璃奈板 点头"},{"id":18,"content":"璃奈板 V"},{"id":19,"content":"璃奈板 努力 冲"},{"id":20,"content":"璃奈板 加了个油"},{"id":21,"content":"璃奈板 干劲满满"},{"id":22,"content":"璃奈板 AAO"},{"id":23,"content":"璃奈板 竭尽全力嘞"},{"id":24,"content":"璃奈板 走吧"},{"id":25,"content":"璃奈板 加油"},{"id":26,"content":"璃奈板 加油啊"},{"id":27,"content":"璃奈板 鼓足气势"},{"id":28,"content":"璃奈板 大呼一口气"},{"id":29,"content":"璃奈板 好耶"},{"id":30,"content":"璃奈板 哇"},{"id":31,"content":"璃奈板 干的漂亮"},{"id":32,"content":"璃奈板 状态饱满"},{"id":33,"content":"璃奈板 超兴奋"},{"id":34,"content":"璃奈板 号角登登"},{"id":35,"content":"璃奈板 让我们上吧"},{"id":36,"content":"璃奈板 噜噜"},{"id":37,"content":"璃奈板 啦啦噜噜"},{"id":38,"content":"璃奈板 躁动不已"},{"id":39,"content":"璃奈板 兴奋不已"},{"id":40,"content":"璃奈板 激动兴奋"},{"id":41,"content":"璃奈板 激奋"},{"id":42,"content":"璃奈板 激动激动噜噜噜"},{"id":43,"content":"璃奈板 高高兴兴笑眯眯"},{"id":44,"content":"璃奈板 耶"},{"id":45,"content":"璃奈板 抿嘴一笑"},{"id":46,"content":"璃奈板 嘿嘿嘿"},{"id":47,"content":"璃奈板 窃笑"},{"id":48,"content":"璃奈板 嘲笑"},{"id":49,"content":"璃奈板 生气气"},{"id":50,"content":"璃奈板 气鼓鼓"},{"id":51,"content":"璃奈板 思索思索"},{"id":52,"content":"璃奈板 无奈"},{"id":53,"content":"璃奈板 无语"},{"id":54,"content":"璃奈板 无话可说"},{"id":55,"content":"璃奈板 哔哔哔"},{"id":56,"content":"璃奈板 哔空"},{"id":57,"content":"璃奈板 叮咚"},{"id":58,"content":"璃奈板 错错"},{"id":59,"content":"璃奈板 吓一跳"},{"id":60,"content":"璃奈板 完美"},{"id":61,"content":"璃奈板 得意"},{"id":62,"content":"璃奈板 咻咻"},{"id":63,"content":"璃奈板 闪亮亮"},{"id":64,"content":"璃奈板 闪亮"},{"id":65,"content":"璃奈板 亮"},{"id":66,"content":"璃奈板 大开灯"},{"id":67,"content":"璃奈板 嗨的很"},{"id":68,"content":"璃奈板 受惊"},{"id":69,"content":"璃奈板 颓废"},{"id":70,"content":"璃奈板 眼冒金星"},{"id":71,"content":"璃奈板 不可置信"},{"id":72,"content":"璃奈板 我倒"},{"id":73,"content":"璃奈板 我躺"},{"id":74,"content":"璃奈板 郁闷"},{"id":75,"content":"璃奈板 抽泣"},{"id":76,"content":"璃奈板 无精打采"},{"id":77,"content":"璃奈板 提不起劲"},{"id":78,"content":"璃奈板 喜出望外"},{"id":79,"content":"璃奈板 断然"},{"id":80,"content":"璃奈板 哼唧唧"},{"id":81,"content":"璃奈板 好气啊"},{"id":82,"content":"璃奈板 生气"},{"id":83,"content":"璃奈板 怒火中烧"},{"id":84,"content":"璃奈板 晃眼"},{"id":85,"content":"璃奈板 咽口水"},{"id":86,"content":"璃奈板 担心"},{"id":87,"content":"璃奈板 泪眼婆娑"},{"id":88,"content":"璃奈板 扭扭捏捏"},{"id":89,"content":"璃奈板 乖巧"},{"id":90,"content":"璃奈板 坐立不安"},{"id":91,"content":"璃奈板 起鸡皮疙瘩"},{"id":92,"content":"璃奈板 紧张兮兮"},{"id":93,"content":"璃奈板 哆哆嗦嗦"},{"id":94,"content":"璃奈板 瑟瑟发抖"},{"id":95,"content":"璃奈板 风尘仆仆"},{"id":96,"content":"璃奈板 筋疲力尽"},{"id":97,"content":"璃奈板 瘫倒无力"},{"id":98,"content":"璃奈板 晕倒"},{"id":99,"content":"璃奈板 吼"},{"id":100,"content":"璃奈板 落泪"},{"id":101,"content":"璃奈板 泪汪汪"},{"id":102,"content":"璃奈板 暖洋洋"},{"id":103,"content":"璃奈板 悠哉游哉"},{"id":104,"content":"璃奈板 心荡神驰"},{"id":105,"content":"璃奈板 发呆"},{"id":106,"content":"璃奈板 治愈"},{"id":107,"content":"璃奈板 暖心"},{"id":108,"content":"璃奈板 轻飘飘"},{"id":109,"content":"璃奈板 慢悠悠"},{"id":110,"content":"璃奈板 耐人寻味"},{"id":111,"content":"璃奈板 抱紧"},{"id":112,"content":"璃奈板 啾啾"},{"id":113,"content":"璃奈板 比心"},{"id":114,"content":"璃奈板 啾噜噜"},{"id":115,"content":"璃奈板 亲"},{"id":116,"content":"璃奈板 笑眯眯 笑眯眯"},{"id":117,"content":"璃奈板 笑容满面"},{"id":118,"content":"璃奈板 舔舌头"},{"id":119,"content":"璃奈板 咀嚼"},{"id":120,"content":"璃奈板 吹吹冷"},{"id":121,"content":"璃奈板 软乎乎"},{"id":122,"content":"璃奈板 太软啦"},{"id":123,"content":"璃奈板 吃饱饱"},{"id":124,"content":"璃奈板 困困"},{"id":125,"content":"璃奈板 傻眼"},{"id":126,"content":"璃奈板 闪亮登场"},{"id":127,"content":"璃奈板 坚定"},{"id":128,"content":"璃奈板 水灵灵"},{"id":129,"content":"璃奈板 哈喽"},{"id":130,"content":"璃奈板 早上中午晚上好"},{"id":131,"content":"璃奈板 欢迎回来"},{"id":132,"content":"璃奈板 不能摘下来"},{"id":133,"content":"璃奈板 嗨起来"},{"id":134,"content":"璃奈板 兔子跳"},{"id":135,"content":"璃奈板 喵喵"},{"id":136,"content":"璃奈板 喵"},{"id":137,"content":"璃奈板 收到"},{"id":138,"content":"璃奈板 开心"},{"id":139,"content":"璃奈板 热血沸腾"},{"id":140,"content":"璃奈板 谢谢"},{"id":141,"content":"璃奈板 接下来也请多关照了"},{"id":142,"content":"璃奈板 再见"}],"musicDb":[{"id":200001,"title":"TOKIMEKI Runners (心动逐梦人)","cover":"tkmk","artist":"虹ヶ咲学園スクールアイドル同好会","description":"手机游戏《Love Live!学园偶像祭 ALL STARS》主题曲，同时也是首张 专辑的主打歌。这首歌既是虹咲学园学园偶像同好会的起点，也是Live的定番歌曲。开场动画中由μ's、Aqours以及虹咲学园的三校27人一同表演的场面也令人印象深刻。"},{"id":209000,"title":"ツナガルコネクト (相连的connect)","cover":"solo0","artist":"天王寺璃奈","description":"TV动画《Love Live! 虹咲学园学园偶像同好会》第一季第6话插曲。不擅 表达感情的璃奈完全活用“小璃奈板”展开Solo Live时首度演出的歌曲。 歌词用“［Ctrl］+［Z］又没用”表现日常情境无法取消已说出的话，配上衬托擅长操作机械的璃奈的垫音，完整展现了璃奈独有特色。"},{"id":209001,"title":"ドキピポ☆エモーション (心跳☆加速)","cover":"solo1","artist":"天王寺璃奈","description":"虹咲学园学园偶像同好会首张专辑收录曲。SIFAS剧情2章插曲。璃奈的第一首Solo曲。描述的是不擅表达感情的璃奈在装上“小璃奈板”时的心境。整体而言是首电子音效突出的电波歌曲，“小璃奈板”呼声也是大家High起的定番桥段。"},{"id":209002,"title":"テレテレパシー (心灵心灵感应)","cover":"solo2","artist":"天王寺璃奈","description":"虹咲学园学园偶像同好会第二张专辑收录曲。SIFAS璃奈羁绊剧情12话插曲。在羁绊剧情中，璃奈首度卸下“小璃奈板”歌唱的歌曲。羁绊剧情第12话释出时引起了相当大的讨论。Live时挥舞心电感应杖的舞蹈也令人印象深刻。"},{"id":209003,"title":"アナログハート (电波之心)","cover":"solo3","artist":"天王寺璃奈","description":"虹咲学园学园偶像同好会第三张专辑收录曲。SIFAS璃奈羁绊剧情21话插曲。SIFAS羁绊剧情中，粉丝俱乐部活动时为了“想要静静地聆听璃奈的歌声”的粉丝们，选择线上转播的歌曲。曲中寄托了璃奈想要跟大家更加友好，更加密切的心愿。"},{"id":209004,"title":"First Love Again (再一次初恋)","cover":"solo4","artist":"天王寺璃奈","description":"虹咲学园学园偶像同好会第四张专辑收录曲。SIFAS璃奈羁绊剧情27话插曲。在羁绊剧情中，负责为电玩研究部拍的校内影像祭电影制作主题曲的璃奈挑战作曲的歌曲。描写记忆只能维持一天的主角心境，温柔窝心的抒情歌曲。"},{"id":209005,"title":"私はマグネット (我是磁石)","cover":"solo5","artist":"天王寺璃奈","description":"虹咲学园学园偶像同好会第五张专辑收录曲。由受邀参加学园偶像祭2的“学园偶像的日常”之“情歌嘉年华”的虹咲学园成员制作。因为从你那里得到了爱而获得救赎的璃奈。这首歌融合了澎湃的福音歌曲旋律，描绘出璃奈那辽阔的世界。"},{"id":200002,"title":"Love U my friends (爱你我的朋友们)","cover":"lumf","artist":"虹ヶ咲学園スクールアイドル同好会","description":"虹咲学园学园偶像同好会第二张专辑的主打歌，也是虹咲首度全员穿上相同舞台装的歌曲。开头成员们各自被打上自己代表色的姿态令人难忘。情感丰沛的吉他主奏，以及满满对你的感谢的歌词都令人热泪满盈。"}],"videoDb":[{"id":1,"title":"Call&Response前半","cover":"C&R01"},{"id":2,"title":"Call&Response后半","cover":"C&R02"},{"id":3,"title":"Call&Response前半(纯享)","cover":"C&R11"},{"id":4,"title":"Call&Response后半(纯享)","cover":"C&R12"},{"id":5,"title":"TV一期第六话Part1","cover":"TVS101"},{"id":6,"title":"TV一期第六话Part2","cover":"TVS102"},{"id":7,"title":"TV一期第六话Part3","cover":"TVS103"}],"package_count":15,"packages":[{"kind":"voice","name":"pack_voice_000_015","path":"webui/assets/unity_pack/pack_voice_000_015.json.gz","request_path":"/assets/unity_pack/pack_voice_000_015.json","asset_count":16,"total_frames":123,"last_frame_max":32,"gzip_bytes":850,"raw_bytes":8796},{"kind":"voice","name":"pack_voice_016_031","path":"webui/assets/unity_pack/pack_voice_016_031.json.gz","request_path":"/assets/unity_pack/pack_voice_016_031.json","asset_count":16,"total_frames":142,"last_frame_max":202,"gzip_bytes":860,"raw_bytes":10106},{"kind":"voice","name":"pack_voice_032_047","path":"webui/assets/unity_pack/pack_voice_032_047.json.gz","request_path":"/assets/unity_pack/pack_voice_032_047.json","asset_count":16,"total_frames":155,"last_frame_max":43,"gzip_bytes":952,"raw_bytes":10999},{"kind":"voice","name":"pack_voice_048_063","path":"webui/assets/unity_pack/pack_voice_048_063.json.gz","request_path":"/assets/unity_pack/pack_voice_048_063.json","asset_count":16,"total_frames":107,"last_frame_max":29,"gzip_bytes":797,"raw_bytes":7740},{"kind":"voice","name":"pack_voice_064_079","path":"webui/assets/unity_pack/pack_voice_064_079.json.gz","request_path":"/assets/unity_pack/pack_voice_064_079.json","asset_count":16,"total_frames":108,"last_frame_max":31,"gzip_bytes":801,"raw_bytes":7809},{"kind":"voice","name":"pack_voice_080_095","path":"webui/assets/unity_pack/pack_voice_080_095.json.gz","request_path":"/assets/unity_pack/pack_voice_080_095.json","asset_count":16,"total_frames":126,"last_frame_max":30,"gzip_bytes":887,"raw_bytes":9030},{"kind":"voice","name":"pack_voice_096_111","path":"webui/assets/unity_pack/pack_voice_096_111.json.gz","request_path":"/assets/unity_pack/pack_voice_096_111.json","asset_count":16,"total_frames":115,"last_frame_max":38,"gzip_bytes":792,"raw_bytes":8308},{"kind":"voice","name":"pack_voice_112_127","path":"webui/assets/unity_pack/pack_voice_112_127.json.gz","request_path":"/assets/unity_pack/pack_voice_112_127.json","asset_count":16,"total_frames":136,"last_frame_max":34,"gzip_bytes":905,"raw_bytes":9737},{"kind":"voice","name":"pack_voice_128_142","path":"webui/assets/unity_pack/pack_voice_128_142.json.gz","request_path":"/assets/unity_pack/pack_voice_128_142.json","asset_count":15,"total_frames":128,"last_frame_max":28,"gzip_bytes":817,"raw_bytes":9167},{"kind":"music","name":"pack_music_lumf_solo0","path":"webui/assets/unity_pack/pack_music_lumf_solo0.json.gz","request_path":"/assets/unity_pack/pack_music_lumf_solo0.json","asset_count":2,"total_frames":491,"last_frame_max":1031,"gzip_bytes":2540,"raw_bytes":34015},{"kind":"music","name":"pack_music_solo1_solo2","path":"webui/assets/unity_pack/pack_music_solo1_solo2.json.gz","request_path":"/assets/unity_pack/pack_music_solo1_solo2.json","asset_count":2,"total_frames":555,"last_frame_max":1120,"gzip_bytes":2883,"raw_bytes":38402},{"kind":"music","name":"pack_music_solo3_solo4","path":"webui/assets/unity_pack/pack_music_solo3_solo4.json.gz","request_path":"/assets/unity_pack/pack_music_solo3_solo4.json","asset_count":2,"total_frames":501,"last_frame_max":1191,"gzip_bytes":2499,"raw_bytes":34654},{"kind":"music","name":"pack_music_solo5_tkmk","path":"webui/assets/unity_pack/pack_music_solo5_tkmk.json.gz","request_path":"/assets/unity_pack/pack_music_solo5_tkmk.json","asset_count":2,"total_frames":500,"last_frame_max":912,"gzip_bytes":2345,"raw_bytes":34625},{"kind":"video","name":"pack_video_small","path":"webui/assets/unity_pack/pack_video_small.json.gz","request_path":"/assets/unity_pack/pack_video_small.json","asset_count":6,"total_frames":22,"last_frame_max":245,"gzip_bytes":375,"raw_bytes":1737},{"kind":"video","name":"pack_video_TVS102","path":"webui/assets/unity_pack/pack_video_TVS102.json.gz","request_path":"/assets/unity_pack/pack_video_TVS102.json","asset_count":1,"total_frames":320,"last_frame_max":968,"gzip_bytes":1836,"raw_bytes":22199}]};

(function(){
'use strict';

const DEFAULT_FACES = [{"name":"默认 01 惊讶眨眼大嘴","hex":"0000000000700408804044020020080100200000001002000000006180027900080400402004F20030C0000000000","type":"default","locked":true,"builtin":true,"default_id":"web_default_00"},{"name":"默认 02 眼镜方嘴","hex":"00000000000000000000300301A0160780780C00E000014000020000000000000FFC00402003FC000000000000000","type":"default","locked":true,"builtin":true,"default_id":"web_default_01"},{"name":"默认 03 困惑挑眉","hex":"0000000000000000000000000000000800041E01E000000000000A00140000000408001F800000000000000000000","type":"default","locked":true,"builtin":true,"default_id":"web_default_02"},{"name":"默认 04 难过斜眼","hex":"000000000000000000003000C0C00C0300400C00C00000C000000A001401FE0004080010800090000600000000000","type":"default","locked":true,"builtin":true,"default_id":"web_default_03"},{"name":"默认 05 中性偷笑","hex":"00000000000000000000300300C00C0300300C00C000000000000A00140201000408001F800000000000000000000","type":"default","locked":true,"builtin":true,"default_id":"web_default_04"},{"name":"默认 06 开心眯眼","hex":"00000000000000000000000000C00C03C0F006018000000000000540A800840003F00010800204000000000000000","type":"default","locked":true,"builtin":true,"default_id":"web_default_05"},{"name":"默认 07 宽眉小嘴","hex":"0000000000000000000000000000000FC0FC000028000040000000000000780002100020400204003FC0000000000","type":"default","locked":true,"builtin":true,"default_id":"web_default_06"},{"name":"默认 08 三角眼委屈","hex":"00000000000000000000100200A014044088000000000000000005002829FE5004080010800090000600000000000","type":"default","locked":true,"builtin":true,"default_id":"web_default_07"},{"name":"默认 09 竖眼皱眉","hex":"000000000000000000001806006018018060060180000000000005002801FE0004080010800090000600000000000","type":"default","locked":true,"builtin":true,"default_id":"web_default_08"},{"name":"默认 10 X眼皱眉","hex":"00000000000000000000C000C0C00C0080400C00C0C000C0000005002829FE5004080010800090000600000000000","type":"default","locked":true,"builtin":true,"default_id":"web_default_09"},{"name":"默认 11 强强","hex":"0000000001C423A242451212208844042108108420000001084200000000FC0004080040200402004020040801F80","type":"default","locked":true,"builtin":true,"default_id":"web_default_10"}];
const ROW_LENS = [18,20,20,20,22,22,22,22,22,22,22,22,22,20,20,20,18,16];
const ROWS = 18;
const COLS = 22;
const PHY_BITS = ROW_LENS.reduce((a,b)=>a+b,0);
const PHY_HEX_LEN = Math.ceil(PHY_BITS / 4);
const LEGACY_ROW_OFFSET = 1;
const LEGACY_COL_OFFSET = 2;
const UNITY_FPS = 30;
const SAVE_KEY = 'rina_clean_saved_faces_v1';

const $ = id => document.getElementById(id);
const qa = sel => Array.from(document.querySelectorAll(sel));

function hardwareMode(){ return !!(window.rinaHardwareMode && window.rinaHardwareMode()); }

function previewMode(){ return !hardwareMode(); }

function toggleButtonValue(id){
  const el = $(id);
  if (!el) return false;

  if (el.tagName === 'INPUT' && el.type === 'checkbox') return !!el.checked;
  return el.getAttribute('aria-pressed') === 'true' || el.classList.contains('active') || el.dataset.checked === '1';
}

function setToggleButtonValue(id, on){
  const el = $(id);
  if (!el) return;
  const value = !!on;

  if (el.tagName === 'INPUT' && el.type === 'checkbox') {
    el.checked = value;
    return;
  }
  el.dataset.checked = value ? '1' : '0';
  el.setAttribute('aria-pressed', value ? 'true' : 'false');
  el.classList.toggle('active', value);

  if (id === 'saveFaceLocked') el.textContent = value ? '已锁定' : '锁定';
  else if (id === 'unityMediaLoop') el.textContent = value ? 'Loop 开' : 'Loop';
  else if (id === 'eyeSyncBox') el.textContent = value ? '左右眼同步：开' : '左右眼同步';
}

function bindToggleButton(id, initial, afterChange){
  const el = $(id);
  if (!el) return;
  setToggleButtonValue(id, toggleButtonValue(id) || !!initial);
  const eventName = (el.tagName === 'INPUT' && el.type === 'checkbox') ? 'change' : 'click';
  el.addEventListener(eventName, action(id + 'Toggle', function(){

    if (!(el.tagName === 'INPUT' && el.type === 'checkbox')) setToggleButtonValue(id, !toggleButtonValue(id));
    else setToggleButtonValue(id, !!el.checked);
    if (typeof afterChange === 'function') afterChange(toggleButtonValue(id));
  }));
}

function selectedSaveType(fallback){
  if (fallback === 'custom' || fallback === 'part') return fallback;
  const el = $('saveFaceType');

  return el && (el.value === 'custom' || el.value === 'part') ? el.value : 'custom';
}

let gridBits = Array(ROWS * COLS).fill(0);
let savedFaces = [];
let selectedFaceIndex = 0;
let statusTimer = null;

let mediaTimer = null;
let mediaElement = null;
let mediaBlobUrl = '';

let mediaToken = 0;
let mediaSilentFrame = 0;
let mediaLastFrame = 0;
let scrollPreviewTimer = null;
let scrollPreviewOffset = 0;

function log(msg){
  const box = $('log');
  const line = '[' + new Date().toLocaleTimeString() + '] ' + msg;

  if (box) box.textContent = line + '\n' + box.textContent.slice(0, 9000);
  try { console.log(line); } catch (_) {}
}

function debug(msg, data){
  const box = $('debugLog');
  const detail = data == null ? '' : ' ' + (typeof data === 'string' ? data : JSON.stringify(data));
  const line = '[' + new Date().toLocaleTimeString() + '] ' + msg + detail;

  if (box) box.textContent = line + '\n' + box.textContent.slice(0, 16000);
  try { console.debug(line); } catch (_) {}
}
const actionBusy = Object.create(null);

function action(label, fn){
  return function(ev){
    debug('button', label);

    if (actionBusy[label]) { debug('button ignored while busy', label); return undefined; }
    let result;
    try {
      result = fn.call(this, ev);

      if (result && typeof result.then === 'function') {
        actionBusy[label] = true;
        if (this && this.classList) this.classList.add('busy');

        return result.catch(error => {
          debug('action error: ' + label, error && (error.stack || error.message || String(error)));
          log(label + ' failed: ' + (error && error.message ? error.message : error));
        }).finally(() => {
          actionBusy[label] = false;

          if (this && this.classList) this.classList.remove('busy');
        });
      }

      return result;
    } catch (error) {
      actionBusy[label] = false;

      if (this && this.classList) this.classList.remove('busy');
      debug('action error: ' + label, error && (error.stack || error.message || String(error)));
      log(label + ' failed: ' + (error && error.message ? error.message : error));

      return undefined;
    }
  };
}

function on(id, event, label, fn){
  const el = $(id);
  if (!el) {
    debug('missing element', id);

    return null;
  }
  el.addEventListener(event, action(label || id, fn));

  return el;
}

function onAll(selector, event, label, fn){
  const nodes = qa(selector);
  if (!nodes.length) debug('missing selector', selector);
  nodes.forEach((el, index) => el.addEventListener(event, action((label || selector) + '#' + index, function(ev){ return fn.call(el, ev, el, index); })));

  return nodes;
}
window.addEventListener('error', ev => debug('window error', ev.message || String(ev.error || ev)));
window.addEventListener('unhandledrejection', ev => debug('promise rejection', ev.reason && (ev.reason.stack || ev.reason.message || String(ev.reason))));

function cleanHex(s){ return String(s || '').replace(/[^0-9a-fA-F]/g, '').toUpperCase(); }

function pad2(n){ return String(Math.max(0, Math.floor(n || 0))).padStart(2, '0'); }

function sleep(ms){ return new Promise(resolve => setTimeout(resolve, ms)); }

function rowPad(row){ return Math.floor((COLS - ROW_LENS[row]) / 2); }

function isRealCell(row, col){ const p = rowPad(row); return row >= 0 && row < ROWS && col >= p && col < p + ROW_LENS[row]; }

function realCells(){ const out=[]; for(let r=0;r<ROWS;r++) for(let c=0;c<COLS;c++) if(isRealCell(r,c)) out.push([r,c]); return out; }

function bitIndex(row, col){ return row * COLS + col; }

function toByte(n){ return Number(n || 0).toString(16).padStart(2, '0').toUpperCase(); }

function safeJson(text, fallback){ try { return JSON.parse(text); } catch (_) { return fallback; } }

function commandContentType(reply){ const s = String(reply || '').trim(); return s.charAt(0) === '{' || s.charAt(0) === '['; }

function localRequestReply(cmd){
  cmd = String(cmd || '');
  if (cmd === 'requestSavedFaces370') return JSON.stringify(localFaces().map(faceForFirmware));

  if (cmd === 'requestFace370') return 'M370:' + bitsToM370(gridBits);
  if (cmd === 'requestFace') return bitsToLegacyHex(gridBits);
  if (cmd === 'requestColor') return '#' + cleanHex(($('colorHex') && $('colorHex').value) || DEFAULT_COLOR_HEX).slice(0, 6).padEnd(6, '0');

  if (cmd === 'requestBright') return String(parseInt(($('bright') && $('bright').value) || '16', 10) || 16);
  if (cmd === 'requestVersion') return 'local-preview';
  if (cmd === 'requestBattery') return JSON.stringify({percent:null, battery_voltage:null, charge_voltage:null, charging:false, remaining_minutes:null, charge_minutes:null, preview:true});

  if (cmd === 'requestManualMode' || cmd === 'requestControlMode') return JSON.stringify({manual_control_mode:false, control_mode:'preview', preview:true});
  if (cmd === 'requestEspStatus') return JSON.stringify({mode:'preview', ip:'local', version:'local-preview', runtime:{type:'preview'}});
  return 'preview ok';
}

function localApiText(path, opts){
  const method = (opts && opts.method) || 'GET';
  const url = new URL(String(path || '/'), 'http://local-preview');
  debug('preview api', method + ' ' + url.pathname);

  if (url.pathname === '/api/ping') return JSON.stringify({ok:true, message:'local preview', mode:'preview'});
  if (url.pathname === '/api/status') return JSON.stringify({mode:'preview', ip:'local', ap_ip:'', udp_port:0, rssi:0, manual_control_mode:false, control_mode:'preview', runtime:{type:'preview'}});
  if (url.pathname === '/api/faces') return JSON.stringify(localFaces().map(faceForFirmware));

  if (url.pathname === '/api/wifi/status') return JSON.stringify({mode:'preview', can_configure:false, sta_connected:false, sta_ssid:'', sta_ip:'', ap_active:false, ap_ip:'', rssi:0, sta_ssid_cfg:'', ap_ssid_cfg:'RinaChanBoard-S3'});
  if (url.pathname === '/api/wifi/scan') return JSON.stringify({ok:true, networks:[]});
  if (url.pathname === '/api/wifi/save') return JSON.stringify({ok:false, preview:true, message:'preview only'});

  if (url.pathname === '/api/request') return localRequestReply(url.searchParams.get('cmd') || '');
  if (url.pathname === '/api/send') {
    let msg = '';

    try {
      const body = opts && opts.body;
      const form = body instanceof URLSearchParams ? body : new URLSearchParams(String(body || ''));
      msg = form.get('msg') || form.get('plain') || '';

    } catch (_) {}
    return localRequestReply(msg);
  }

  if (url.pathname === '/api/binary') return cleanHex(url.searchParams.get('hex') || '') || 'preview ok';
  return 'preview ok';
}

async function apiText(path, opts){
  const fetchOpts = Object.assign({}, opts || {});
  const retries = Math.max(0, parseInt(fetchOpts.retries || '0', 10) || 0);
  delete fetchOpts.retries;
  const method = fetchOpts.method || 'GET';
  const target = (typeof window.rinaDeviceUrl === 'function') ? window.rinaDeviceUrl(path) : path;

  if (previewMode()) return localApiText(path, fetchOpts);
  debug('api request', method + ' ' + path + (target !== path ? ' -> ' + target : ''));
  for (let attempt = 0; attempt <= retries; attempt++) {

    try {
      const r = await fetch(path, fetchOpts);
      const t = await r.text();
      debug('api response', method + ' ' + path + ' -> ' + r.status + ' ' + t.slice(0, 160));

      if (!r.ok) throw new Error(t || r.statusText);
      return t;
    } catch (error) {
      debug('api error', method + ' ' + path + ' ' + (error && error.message ? error.message : error));

      if (attempt >= retries) throw error;
      await sleep(150 * (attempt + 1));
      debug('api retry', method + ' ' + path + ' #' + (attempt + 2));
    }
  }
}

async function apiJson(path, opts){ const text = await apiText(path, opts); try { return JSON.parse(text); } catch (e) { throw new Error('JSON parse failed: ' + text.slice(0, 180)); } }

async function postForm(path, params, retries){

  return apiText(path, {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:new URLSearchParams(params), cache:'no-store', retries: retries || 0});
}

async function sendText(msg, wait){
  const runtimeCommand = /^(scrollText|timeline370|runtimeStop)/.test(String(msg || ''));
  const t = await postForm('/api/send', {msg, wait: wait ? '1' : '0'}, runtimeCommand ? 2 : 0);
  const shown = String(msg || '').length > 180 ? String(msg).slice(0, 180) + '...' : String(msg || '');
  log((wait ? 'RX ' : 'TX ') + shown + (wait ? ' => ' + t : ''));

  return t;
}

async function sendHex(hex, wait, format){
  const t = await apiText('/api/binary?hex=' + encodeURIComponent(cleanHex(hex)) + '&wait=' + (wait ? '1' : '0') + '&format=' + encodeURIComponent(format || 'hex'));
  log((wait ? 'RX hex ' : 'TX hex ') + cleanHex(hex) + (wait ? ' => ' + t : ''));

  return t;
}

async function req(cmd){
  const t = await apiText('/api/request?cmd=' + encodeURIComponent(cmd));
  log(cmd + ' => ' + t);

  return t;
}

function bitsToM370(bits){
  let binary = '';
  for (const rc of realCells()) binary += bits[bitIndex(rc[0], rc[1])] ? '1' : '0';

  while (binary.length % 4) binary += '0';
  let out = '';
  for (let i=0; i<binary.length; i+=4) out += parseInt(binary.slice(i, i+4), 2).toString(16).toUpperCase();

  return out.slice(0, PHY_HEX_LEN);
}

function m370ToBits(hex){
  let raw = String(hex || '').trim();
  if (raw.toUpperCase().startsWith('M370:')) raw = raw.slice(5);
  let binary = '';

  for (const h of cleanHex(raw).padEnd(PHY_HEX_LEN, '0').slice(0, PHY_HEX_LEN)) binary += parseInt(h, 16).toString(2).padStart(4, '0');
  const bits = Array(ROWS * COLS).fill(0);
  let k = 0;

  for (const rc of realCells()) bits[bitIndex(rc[0], rc[1])] = binary[k++] === '1' ? 1 : 0;
  return bits;
}

function legacyHexToBits(hex){
  let binary = '';
  for (const h of cleanHex(hex).padEnd(72, '0').slice(0, 72)) binary += parseInt(h, 16).toString(2).padStart(4, '0');
  const bits = Array(ROWS * COLS).fill(0);

  for (let i=0; i<16*18; i++) {
    const r = Math.floor(i / 18) + LEGACY_ROW_OFFSET;
    const c = (i % 18) + LEGACY_COL_OFFSET;

    if (isRealCell(r, c)) bits[bitIndex(r, c)] = binary[i] === '1' ? 1 : 0;
  }
  return bits;
}

function bitsToLegacyHex(bits){
  let binary = '';
  for (let r=0; r<16; r++) for (let c=0; c<18; c++) {
    const rr = r + LEGACY_ROW_OFFSET, cc = c + LEGACY_COL_OFFSET;
    binary += isRealCell(rr, cc) && bits[bitIndex(rr, cc)] ? '1' : '0';
  }
  let out = '';

  for (let i=0; i<binary.length; i+=4) out += parseInt(binary.slice(i, i+4), 2).toString(16).toUpperCase();
  return out.padEnd(72, '0').slice(0, 72);
}

function bitmapToBits(bitmap){
  const bits = Array(ROWS * COLS).fill(0);
  (bitmap || []).forEach((row, r) => String(row || '').split('').forEach((ch, c) => {

    if (r < ROWS && c < COLS && isRealCell(r, c)) bits[bitIndex(r, c)] = ch === '#' || ch === '+' ? 1 : 0;
  }));
  return bits;
}

function bitsToBitmap(bits){
  const rows = [];
  for (let r=0; r<ROWS; r++) {
    let row = '';

    for (let c=0; c<COLS; c++) row += isRealCell(r,c) && bits[bitIndex(r,c)] ? '#' : '.';
    rows.push(row);
  }

  return rows;
}

function faceToBits(item){
  if (!item) return Array(ROWS * COLS).fill(0);
  if (item.hex) return m370ToBits(item.hex);

  return bitmapToBits(item.data || []);
}

function updateHexField(){ const el = $('faceHex'); if (el) el.value = 'M370:' + bitsToM370(gridBits); }

function setEditorBits(bits){ gridBits = bits.slice(0, ROWS * COLS); renderEditor(); updateHexField(); }

function bitmapTextToBits(text){
  const lines = [];
  String(text || '').split(/\r?\n/).forEach(function(raw){
    let line = String(raw || '').trim();
    const quoted = line.match(/[\"']([.#\+]{8,40})[\"']/);
    if (quoted) line = quoted[1];
    if (/^[.#\+]{8,40}$/.test(line)) lines.push(line);
  });
  if (!lines.length) return null;
  const bits = Array(ROWS * COLS).fill(0);
  for (let r=0; r<Math.min(ROWS, lines.length); r++) {
    const row = lines[r];
    for (let c=0; c<Math.min(COLS, row.length); c++) {
      if (isRealCell(r, c) && (row[c] === '#' || row[c] === '+')) bits[bitIndex(r,c)] = 1;
    }
  }
  return bits;
}
function setColorsByString(value){
  const bitmapBits = bitmapTextToBits(value);
  if (bitmapBits) { setEditorBits(bitmapBits); return; }
  setEditorBits(String(value || '').toUpperCase().startsWith('M370:') || cleanHex(value).length >= PHY_HEX_LEN ? m370ToBits(value) : legacyHexToBits(value));
}


function renderBits(container, bits, editable){
  if (!container) return;
  container.innerHTML = '';
  for (let r=0; r<ROWS; r++) for (let c=0; c<COLS; c++) {
    const real = isRealCell(r, c);
    const node = editable ? document.createElement('button') : document.createElement('span');
    node.className = (editable ? 'led ' : 'miniLed ') + (real ? '' : 'hidden ') + (c === Math.floor(COLS/2)-1 ? 'midCol ' : '') + (r === Math.floor(ROWS/2)-1 ? 'midRow ' : '') + (real && bits[bitIndex(r,c)] ? 'on' : '');
    if (real && editable) {
      node.type = 'button';
      node.title = 'row ' + r + ', col ' + c;
      node.addEventListener('pointerdown', ev => { ev.preventDefault(); gridBits[bitIndex(r,c)] = gridBits[bitIndex(r,c)] ? 0 : 1; renderEditor(); updateHexField(); });
      node.addEventListener('contextmenu', ev => { ev.preventDefault(); gridBits[bitIndex(r,c)] = 0; renderEditor(); updateHexField(); });
    }
    container.appendChild(node);
  }
}
function renderEditor(){ renderBits($('grid'), gridBits, true); }


function partSize(group){ return group === 'cheek' ? [5, 2] : [8, 8]; }
function getPart(group, idx){
  const faces = window.RINA_FACES || {};
  if (!idx) return group === 'cheek' ? faces.cheek00 : faces.none;
  return (faces[group] || [])[idx - 1] || faces.none;
}
function setPart(bits, bitmap, sr, sc, w, h, flip){
  for (let r=0; r<h; r++) for (let c=0; c<w; c++) {
    const srcC = flip ? w - 1 - c : c;
    const val = bitmap && bitmap[r] && bitmap[r][srcC];
    const rr = sr + r + LEGACY_ROW_OFFSET;
    const cc = sc + c + LEGACY_COL_OFFSET;
    if (isRealCell(rr, cc)) bits[bitIndex(rr, cc)] = val ? 1 : 0;
  }
}
function buildFaceBits(le, re, mo, ch){
  const bits = Array(ROWS * COLS).fill(0);
  setPart(bits, getPart('leye', le), 0, 0, 8, 8, false);
  setPart(bits, getPart('reye', re), 0, 10, 8, 8, false);
  setPart(bits, getPart('mouth', mo), 8, 5, 8, 8, false);
  setPart(bits, getPart('cheek', ch), 8, 0, 5, 2, false);
  setPart(bits, getPart('cheek', ch), 8, 13, 5, 2, true);
  return bits;
}
function renderPartFacePreview(bits){
  renderBits($('partFacePreview'), bits || Array(ROWS * COLS).fill(0), false);
}

function faceFromSelectors(){
  const le = +$('leye').value || 0;
  const re = +$('reye').value || 0;
  const mo = +$('mouth').value || 0;
  const ch = +$('cheek').value || 0;
  const bits = buildFaceBits(le, re, mo, ch);
  setEditorBits(bits);
  renderPartFacePreview(bits);
  syncPartThumbSelection();
}
function makeOptions(select, count){
  if (!select) return;
  select.innerHTML = '';
  for (let i=0; i<=count; i++) {
    const o = document.createElement('option');
    o.value = String(i);
    o.textContent = i === 0 ? '00' : pad2(i);
    select.appendChild(o);
  }
}
function buildPartThumb(group, idx, selectId){
  const box = document.createElement('button');
  const size = partSize(group);
  const bmp = getPart(group, idx);
  box.type = 'button';
  box.className = 'partThumb';
  box.dataset.group = group;
  box.dataset.index = String(idx);
  const pixels = document.createElement('div');
  pixels.className = 'partPixels';
  pixels.style.gridTemplateColumns = 'repeat(' + size[0] + ',9px)';
  for (let r=0; r<size[1]; r++) for (let c=0; c<size[0]; c++) {
    const px = document.createElement('span');
    px.className = 'partPix ' + (bmp && bmp[r] && bmp[r][c] ? 'on' : '');
    pixels.appendChild(px);
  }
  const label = document.createElement('div');
  label.className = 'mono small';
  label.textContent = idx === 0 ? '00' : pad2(idx);
  box.appendChild(pixels);
  box.appendChild(label);
  box.addEventListener('click', () => {
    $(selectId).value = String(idx);
    if (selectId === 'leye' && toggleButtonValue('eyeSyncBox')) $('reye').value = String(idx);
    faceFromSelectors();
  });
  return box;
}
function renderPartGalleries(){
  const faces = window.RINA_FACES || {};
  [['leye','leyeGallery'],['reye','reyeGallery'],['mouth','mouthGallery'],['cheek','cheekGallery']].forEach(pair => {
    const group = pair[0], gallery = $(pair[1]);
    if (!gallery) return;
    gallery.innerHTML = '';
    const count = (faces[group] || []).length;
    for (let i=0; i<=count; i++) gallery.appendChild(buildPartThumb(group, i, group));
  });
  syncPartThumbSelection();
}
function syncPartThumbSelection(){
  const vals = {leye:+$('leye').value||0, reye:+$('reye').value||0, mouth:+$('mouth').value||0, cheek:+$('cheek').value||0};
  qa('.partThumb').forEach(el => el.classList.toggle('active', vals[el.dataset.group] === +el.dataset.index));
}
function randomizeParts(upload){
  const faces = window.RINA_FACES || {};
  const pick = group => Math.floor(Math.random() * ((faces[group] || []).length + 1));
  const le = pick('leye');
  $('leye').value = String(le);
  $('reye').value = String((toggleButtonValue('eyeSyncBox')) ? le : pick('reye'));
  $('mouth').value = String(pick('mouth'));
  $('cheek').value = String(pick('cheek'));
  faceFromSelectors();
  if (upload) uploadFace();
}


function normalizeFaceItem(item, index){
  const isDefault = item && (item.type === 'default' || item.builtin || item.default_id);
  const defaultRef = isDefault ? DEFAULT_FACES[index] : null;
  const bits = faceToBits(item);
  return {
    name: isDefault && defaultRef && defaultRef.name
      ? String(defaultRef.name)
      : (item && item.name ? String(item.name) : (isDefault ? '默认表情 ' + pad2(index + 1) : '自定义表情 ' + pad2(index + 1))),
    type: isDefault ? 'default' : ((item && item.type) || 'custom'),
    locked: !!(isDefault || (item && item.locked)),
    builtin: !!(item && item.builtin),
    default_id: item && item.default_id,
    data: bitsToBitmap(bits),
    hex: bitsToM370(bits)
  };
}
function displayFaceName(face, index){
  if (face && face.name) return face.name;
  if (face.type === 'default' || face.builtin || face.default_id) return '默认表情 ' + pad2(index + 1);
  return '自定义表情 ' + pad2(index + 1);
}
function localFaces(){
  const raw = safeJson(localStorage.getItem(SAVE_KEY) || '[]', []);
  return Array.isArray(raw) && raw.length ? raw.map(normalizeFaceItem) : DEFAULT_FACES.map(normalizeFaceItem);
}
function storeLocalFaces(list){ localStorage.setItem(SAVE_KEY, JSON.stringify(list.map(faceForFirmware))); }
function faceForFirmware(face){
  const out = {name: face.name, type: face.type || 'custom', locked: !!face.locked, data: face.data || bitsToBitmap(m370ToBits(face.hex))};
  if (face.default_id) out.default_id = face.default_id;
  if (face.builtin) out.builtin = true;
  return out;
}
async function loadFaces(){
  if (previewMode()) {
    savedFaces = localFaces();
    log('本地预览保存表情：' + savedFaces.length);
    selectedFaceIndex = Math.min(selectedFaceIndex, Math.max(0, savedFaces.length - 1));
    renderSavedFaces();
    return;
  }
  try {
    const list = await apiJson('/api/faces');
    savedFaces = (Array.isArray(list) ? list : []).map(normalizeFaceItem);
    storeLocalFaces(savedFaces);
    log('已从固件读取保存表情：' + savedFaces.length);
  } catch (error) {
    savedFaces = localFaces();
    log('使用本地保存表情：' + error.message);
  }
  selectedFaceIndex = Math.min(selectedFaceIndex, Math.max(0, savedFaces.length - 1));
  renderSavedFaces();
}
let dragSrcIdx = null;
function moveFace(from, to) {
  if (from === to || from < 0 || to < 0 || from >= savedFaces.length || to >= savedFaces.length) return;
  const item = savedFaces.splice(from, 1)[0];
  savedFaces.splice(to, 0, item);
  if (selectedFaceIndex === from) selectedFaceIndex = to;
  else if (from < selectedFaceIndex && to >= selectedFaceIndex) selectedFaceIndex--;
  else if (from > selectedFaceIndex && to <= selectedFaceIndex) selectedFaceIndex++;
  storeLocalFaces(savedFaces);
  renderSavedFaces();
  sendText('moveFace370|' + from + '|' + to, true).catch(function(e){ log('排序失败: ' + e.message); });
}
function renderSavedFaces(){
  const sel = $('savedFaces');
  const count = $('savedFacesCount');
  const list = $('savedFaceList');
  if (count) count.textContent = savedFaces.length + ' 个';
  if (sel) {
    sel.innerHTML = '';
    savedFaces.forEach(function(face, i){
      const o = document.createElement('option');
      o.value = String(i);
      const pfx = (face.type === 'default' || face.builtin) ? '*' : '';
      o.textContent = pfx + pad2(i + 1) + ' ' + displayFaceName(face, i) + ' [' + (face.type || 'custom') + ']';
      sel.appendChild(o);
    });
    sel.value = String(selectedFaceIndex);
  }
  if (list) {
    list.innerHTML = '';
    savedFaces.forEach(function(face, i){
      const isDef = face.type === 'default' || face.builtin;
      const row = document.createElement('div');
      row.className = 'faceRow' + (i === selectedFaceIndex ? ' active' : '');
      row.draggable = true;
      row.dataset.index = String(i);

      const num = document.createElement('div');
      num.className = 'num';
      num.textContent = (isDef ? '*' : '') + pad2(i + 1);

      const fname = document.createElement('div');
      fname.className = 'fname';
      fname.textContent = displayFaceName(face, i);
      fname.title = displayFaceName(face, i) + ' [' + (face.type || 'custom') + ']';

      const lockBtn = document.createElement('button');
      lockBtn.type = 'button';
      lockBtn.className = 'btn sm' + (face.locked ? ' warn' : '');
      lockBtn.textContent = face.locked ? '锁定' : '解锁';
      if (isDef) lockBtn.disabled = true;
      lockBtn.addEventListener('click', function(e){
        e.stopPropagation();
        selectedFaceIndex = i;
        toggleSelectedLock();
      });

      const typeBtn = document.createElement('button');
      typeBtn.type = 'button';
      typeBtn.className = 'btn sm';
      typeBtn.textContent = isDef ? '默认' : face.type === 'part' ? '部件' : '自定';
      if (isDef) typeBtn.disabled = true;
      typeBtn.addEventListener('click', function(e){
        e.stopPropagation();
        if (isDef) return;
        selectedFaceIndex = i;
        var newType = face.type === 'custom' ? 'part' : 'custom';
        face.type = newType;
        storeLocalFaces(savedFaces);
        renderSavedFaces();
        sendText('typeFace370|' + i + '|' + newType, true).catch(function(){ log('属性切换失败'); });
      });

      const delBtn = document.createElement('button');
      delBtn.type = 'button';
      delBtn.className = 'btn sm danger';
      delBtn.textContent = '删除';
      if (face.locked || isDef) delBtn.disabled = true;
      delBtn.addEventListener('click', function(e){
        e.stopPropagation();
        selectedFaceIndex = i;
        deleteSelectedFace();
      });

      const handle = document.createElement('div');
      handle.className = 'dragHandle';
      handle.textContent = '⋮';
      handle.title = '拖拽排序';

      row.addEventListener('click', function(){
        selectedFaceIndex = i;
        renderSavedFaces();
        previewSelectedFace();
        sendText('selectFace370|' + i, false).catch(function(e){ log('选择失败: ' + e.message); });
      });

      row.addEventListener('dragstart', function(e){
        dragSrcIdx = i;
        e.dataTransfer.effectAllowed = 'move';
        setTimeout(function(){ row.classList.add('dragging'); }, 0);
      });
      row.addEventListener('dragover', function(e){
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
        qa('.faceRow.drag-over').forEach(function(r){ r.classList.remove('drag-over'); });
        if (dragSrcIdx !== null && dragSrcIdx !== i) row.classList.add('drag-over');
      });
      row.addEventListener('dragleave', function(){ row.classList.remove('drag-over'); });
      row.addEventListener('drop', function(e){
        e.preventDefault();
        qa('.faceRow.drag-over').forEach(function(r){ r.classList.remove('drag-over'); });
        if (dragSrcIdx !== null && dragSrcIdx !== i) moveFace(dragSrcIdx, i);
        dragSrcIdx = null;
      });
      row.addEventListener('dragend', function(){
        qa('.faceRow.dragging').forEach(function(r){ r.classList.remove('dragging'); });
        qa('.faceRow.drag-over').forEach(function(r){ r.classList.remove('drag-over'); });
        dragSrcIdx = null;
      });

      var touchStartY = 0;
      handle.addEventListener('touchstart', function(e){
        dragSrcIdx = i;
        touchStartY = e.touches[0].clientY;
        row.classList.add('dragging');
        e.preventDefault();
      }, {passive: false});
      handle.addEventListener('touchmove', function(e){ e.preventDefault(); }, {passive: false});
      handle.addEventListener('touchend', function(e){
        row.classList.remove('dragging');
        qa('.faceRow.drag-over').forEach(function(r){ r.classList.remove('drag-over'); });
        if (dragSrcIdx === null) return;
        var touch = e.changedTouches[0];
        var el = document.elementFromPoint(touch.clientX, touch.clientY);
        var targetRow = el && el.closest('.faceRow');
        if (targetRow && targetRow.dataset.index != null) {
          var targetIdx = +targetRow.dataset.index;
          if (!isNaN(targetIdx) && targetIdx !== dragSrcIdx) moveFace(dragSrcIdx, targetIdx);
        }
        dragSrcIdx = null;
      });

      row.appendChild(num);
      row.appendChild(fname);
      row.appendChild(lockBtn);
      row.appendChild(typeBtn);
      row.appendChild(delBtn);
      row.appendChild(handle);
      list.appendChild(row);
    });
  }
  previewSelectedFace();
}
function previewSelectedFace(){
  const face = savedFaces[selectedFaceIndex];
  renderBits($('savedFacePreview'), faceToBits(face), false);
  const out = $('savedFaceOut');
  if (out && face) out.textContent = JSON.stringify({index:selectedFaceIndex, name:displayFaceName(face, selectedFaceIndex), type:face.type, locked:face.locked, hex:'M370:' + face.hex}, null, 2);
}
function loadSelectedFace(){
  const face = savedFaces[selectedFaceIndex];
  if (!face) return;
  setEditorBits(faceToBits(face));
  renderSavedFaces();
  sendText('selectFace370|' + selectedFaceIndex, false).catch(function(e){ log('载入表情失败: ' + e.message); });
}
async function addCurrentFace(typeOverride){
  const typ = selectedSaveType(typeOverride);
  const baseName = typ === 'part' ? '表情部件 ' : '自定义表情 ';
  const name = prompt('表情名称', baseName + pad2(savedFaces.length + 1));
  if (name == null) return;
  const item = {name: String(name).trim() || baseName.trim(), type: typ, locked: toggleButtonValue('saveFaceLocked'), data: bitsToBitmap(gridBits)};
  savedFaces.push(normalizeFaceItem(item, savedFaces.length));
  selectedFaceIndex = savedFaces.length - 1;
  storeLocalFaces(savedFaces);
  renderSavedFaces();
  try {
    await sendText('addFace370Json|' + JSON.stringify(item), true);
    await loadFaces();
  } catch (error) {
    log('保存到固件失败，仅保存到本地：' + error.message);
  }
}
async function saveCustomFaceToSharedStore(){
  const sel = $('saveFaceType');
  if (sel) sel.value = 'custom';
  return addCurrentFace('custom');
}
async function savePartFaceToSharedStore(){
  faceFromSelectors();
  const sel = $('saveFaceType');
  if (sel) sel.value = 'part';
  return addCurrentFace('part');
}
async function renameSelectedFace(){
  const face = savedFaces[selectedFaceIndex];
  if (!face || face.type === 'default' || face.builtin) return;
  const name = prompt('新的表情名称', face.name);
  if (name == null) return;
  face.name = String(name).trim() || face.name;
  storeLocalFaces(savedFaces);
  renderSavedFaces();
  try { await sendText('renameFace370Index|' + selectedFaceIndex + '|' + face.name, true); } catch (e) { log('固件重命名失败：' + e.message); }
}
async function toggleSelectedLock(){
  const face = savedFaces[selectedFaceIndex];
  if (!face || face.type === 'default' || face.builtin) return;
  face.locked = !face.locked;
  storeLocalFaces(savedFaces);
  renderSavedFaces();
  try { await sendText('lockFace370|' + selectedFaceIndex + '|' + (face.locked ? '1' : '0'), true); } catch (e) { log('固件锁定状态更新失败：' + e.message); }
}
async function deleteSelectedFace(){
  const face = savedFaces[selectedFaceIndex];
  if (!face || face.locked || face.type === 'default' || face.builtin) return;
  if (!confirm('删除 ' + displayFaceName(face, selectedFaceIndex) + ' ?')) return;
  const idx = selectedFaceIndex;
  savedFaces.splice(idx, 1);
  selectedFaceIndex = Math.max(0, Math.min(savedFaces.length - 1, idx));
  storeLocalFaces(savedFaces);
  renderSavedFaces();
  try { await sendText('deleteFace370Index|' + idx, true); await loadFaces(); } catch (e) { log('固件删除失败：' + e.message); }
}


function updateManualModeUi(enabled, raw){
  const badge = $('manualModeBadge');
  const btn = $('manualModeToggle');
  const out = $('manualModeOut');
  if (badge) { badge.textContent = enabled ? 'MANUAL / 手动控制中' : 'WEB / 网络控制中'; badge.className = 'pill ' + (enabled ? 'warn' : 'ok'); }
  if (btn) btn.textContent = enabled ? '停止手动控制模式' : '启动手动控制模式';
  if (out) out.textContent = typeof raw === 'string' ? raw : JSON.stringify(raw, null, 2);
}
async function requestManualMode(){
  const text = await req('requestManualMode');
  const obj = safeJson(text, null);
  updateManualModeUi(!!(obj && obj.manual_control_mode), text);
}
async function setManualMode(enabled){
  const text = await sendText('manualMode|' + (enabled ? '1' : '0'), true);
  updateManualModeUi(enabled, text);
}
async function toggleManualMode(){
  const badge = $('manualModeBadge');
  await setManualMode(!(badge && String(badge.textContent).includes('MANUAL')));
}


async function uploadFace(){ await sendText('M370:' + bitsToM370(gridBits), false); }
async function downloadFace(){
  try { setColorsByString(await req('requestFace370')); }
  catch (_) { setColorsByString(await req('requestFace')); }
}
async function uploadColor(){
  const hex = setUiThemeColor(currentColorHex());
  await sendText('#' + hex, false);
}
async function downloadColor(){
  const hex = cleanHex(await req('requestColor')).slice(0, 6).padEnd(6, '0');
  setUiThemeColor(hex);
}
function clampBright(value){
  const n = parseInt(value, 10);
  return Math.max(1, Math.min(128, Number.isFinite(n) ? n : 16));
}

function syncBrightControls(value){
  const b = clampBright(value);
  if ($('bright')) $('bright').value = String(b);
  if ($('brightSlider')) $('brightSlider').value = String(b);
  return b;
}

async function uploadBright(){
  const b = syncBrightControls($('bright').value);
  await sendText('B' + String(b).padStart(3, '0'), false);
}
async function downloadBright(){ syncBrightControls(parseInt(await req('requestBright'), 10) || 16); }
async function requestVersion(){ $('versionOut').textContent = await req('requestVersion'); }
async function requestEspStatus(){ $('espOut').textContent = await req('requestEspStatus'); }
async function updateStatus(){
  applyRunModeUi();
  try {
    const s = await apiJson('/api/status');
    $('status').textContent = 'mode=' + s.mode + ' ip=' + s.ip + ' ap=' + (s.ap_ip || '') + ' udp=' + s.udp_port + ' rssi=' + s.rssi;
    updateManualModeUi(!!s.manual_control_mode, s);
    if (s.color) setUiThemeColor(s.color);
  } catch (error) {
    $('status').textContent = 'status error: ' + error.message;
  }
}
function updateBatteryUi(obj){
  const pct = obj.percent == null ? null : Math.max(0, Math.min(100, Number(obj.percent)));
  $('batteryBadge').textContent = pct == null ? '未知' : pct.toFixed(0) + '%';
  $('batteryBadge').className = 'pill ' + (obj.charging ? 'ok' : '');
  $('batteryBarFill').style.width = (pct == null ? 0 : pct) + '%';
  $('batteryPercent').textContent = pct == null ? '-' : pct.toFixed(1) + '%';
  $('batteryVoltage').textContent = obj.battery_voltage == null ? '-' : Number(obj.battery_voltage).toFixed(3) + ' V';
  $('batteryChargeVoltage').textContent = obj.charge_voltage == null ? '-' : Number(obj.charge_voltage).toFixed(3) + ' V';
  $('batteryCharging').textContent = obj.charging ? 'charging' : 'not charging';
  $('batteryRemaining').textContent = obj.remaining_minutes == null ? '-' : obj.remaining_minutes + ' min';
  $('batteryChargeTime').textContent = obj.charge_minutes == null ? '-' : obj.charge_minutes + ' min';
  $('batteryRaw').textContent = JSON.stringify(obj, null, 2);
}
async function requestBatteryJson(){
  const text = await req('requestBattery');
  updateBatteryUi(safeJson(text, {}));
}
async function autoSyncAll(){
  const out = $('espOut');
  const result = {};
  try { result.face370 = await req('requestFace370'); setColorsByString(result.face370); } catch(e) { result.face = e.message; }
  try { result.color = await req('requestColor'); } catch(e) { result.color = e.message; }
  try { result.bright = await req('requestBright'); } catch(e) { result.bright = e.message; }
  try { result.version = await req('requestVersion'); } catch(e) { result.version = e.message; }
  try { result.battery = safeJson(await req('requestBattery'), {}); updateBatteryUi(result.battery); } catch(e) { result.battery = e.message; }
  if (out) out.textContent = JSON.stringify(result, null, 2);
}


function glyphFor(ch){
  const db = window.RINA_UNITY_DB || {};
  const code = ch.charCodeAt(0);
  return (db.ascii || []).find(g => g.id === code || g.symbol === ch);
}
function textToBits(text, offset){
  const bits = Array(ROWS * COLS).fill(0);
  let x = COLS - (offset || 0);
  const y0 = 5;
  for (const ch of String(text || '')) {
    const g = glyphFor(ch) || glyphFor('?') || glyphFor(' ');
    const rows = g ? g.content : [];
    for (let r=0; r<7; r++) for (let c=0; c<5; c++) {
      const rr = y0 + r, cc = x + c;
      if (rows[r] && rows[r][c] && isRealCell(rr, cc)) bits[bitIndex(rr, cc)] = 1;
    }
    x += 6;
  }
  return bits;
}
function previewScrollText(){
  const text = String($('scrollText').value || '');
  renderBits($('scrollPreview'), textToBits(text, Math.max(0, COLS - 6)), false);
}
function stopLocalScrollPreview(){
  if (scrollPreviewTimer) {
    clearInterval(scrollPreviewTimer);
    scrollPreviewTimer = null;
  }
}
function startLocalScrollPreview(speed, text){
  stopLocalScrollPreview();
  scrollPreviewOffset = 0;
  const maxOffset = COLS + text.length * 6 + 8;
  const tick = function(){
    renderBits($('scrollPreview'), textToBits(text, scrollPreviewOffset), false);
    scrollPreviewOffset = (scrollPreviewOffset + 1) % Math.max(1, maxOffset);
  };
  tick();
  scrollPreviewTimer = setInterval(tick, speed);
}
async function startScrollText(){
  stopUnityMedia(false);
  unloadUnityTimelineExcept('', '');
  const speed = Math.max(40, Math.min(1000, parseInt($('scrollSpeed').value || '120', 10) || 120));
  const text = String($('scrollText').value || '').replace(/[\r\n\t|]/g, ' ').slice(0, 96);
  previewScrollText();
  if (previewMode()) {
    startLocalScrollPreview(speed, text);
    log('滚动文字本地预览：' + text);
    return;
  }
  await sendText('scrollText370|' + speed + '|' + text, true);
}
async function stopScrollText(doFirmwareStop){
  stopLocalScrollPreview();
  if (hardwareMode() && doFirmwareStop !== false) await sendText('scrollTextStop370', true);
}


function db(){ return window.RINA_UNITY_DB || {}; }
function unityManifest(){ return window.RINA_UNITY_TIMELINE_MANIFEST || {voice:[], music:[], video:[]}; }
function unityMapName(kind){ return kind === 'voice' ? 'voiceTimelines' : kind === 'music' ? 'musicTimelines' : 'videoTimelines'; }
function unityItems(kind){ return (unityManifest()[kind] || []); }
function mediaKeys(kind){
  const items = unityItems(kind);
  if (items.length) return items.map(item => item.key);
  const map = db()[unityMapName(kind)] || {};
  return Object.keys(map || {});
}
function mediaManifestItem(kind, key){
  return (unityItems(kind) || []).find(item => String(item.key) === String(key)) || null;
}
function unityAssetUrl(path){
  path = String(path || '');
  if (!path) return '';
  if (path.charAt(0) === '/' && location.protocol === 'file:') return path.slice(1);
  return (path.charAt(0) === '/' && typeof window.rinaDeviceUrl === 'function') ? window.rinaDeviceUrl(path) : path;
}
async function unityFetchJson(path){
  const url = unityAssetUrl(path);
  const r = await fetch(url, {cache:'no-store'});
  if (!r.ok) throw new Error('HTTP ' + r.status + ' while loading ' + url);
  return await r.json();
}
function unloadUnityTimelineExcept(kind, key){
  const d = db();
  ['voice', 'music', 'video'].forEach(k => {
    const name = unityMapName(k);
    const map = d[name] || (d[name] = {});
    Object.keys(map).forEach(existing => {
      if (!(k === kind && String(existing) === String(key))) delete map[existing];
    });
  });
  updateUnityDbInfo();
}
async function ensureUnityTimeline(kind, key){
  const d = db();
  const mapName = unityMapName(kind);
  const map = d[mapName] || (d[mapName] = {});
  if (map[key]) return map[key];

  const item = mediaManifestItem(kind, key);
  if (!item || (!item.package && !item.path)) throw new Error('找不到 Unity 时间轴：' + kind + ':' + key);

  const fetchPath = item.package || item.path;
  const packageKey = item.package_key || key;
  log('Unity 按需载入包：' + kind + ':' + key + ' <- ' + fetchPath + ' (' + (item.frames || '?') + ' frames)');

  const payload = await unityFetchJson(fetchPath);
  let timeline = [];
  if (Array.isArray(payload)) {
    timeline = payload;
  } else if (payload && Array.isArray(payload.timeline)) {
    timeline = payload.timeline;
  } else if (payload && payload.timelines) {
    timeline = payload.timelines[packageKey] || payload.timelines[key] || [];
  }

  if (!Array.isArray(timeline)) throw new Error('Unity package timeline 格式错误：' + kind + ':' + key);

  unloadUnityTimelineExcept(kind, key);
  (d[mapName] || (d[mapName] = {}))[key] = timeline;
  updateUnityDbInfo();
  return timeline;
}
function timelineOf(kind, key){
  const d = db();
  const map = d[unityMapName(kind)] || {};
  return map[key] || [];
}
function mediaAsset(kind, key, index){
  const d = db();
  if (kind === 'voice') {
    const number = parseInt(String(key).replace(/^\D+/, ''), 10);
    return (d.voiceDb || []).find(item => Number(item.id) === number)
      || (window.RINA_VOICE_DATA || [])[index]
      || null;
  }
  if (kind === 'music') {
    return (d.musicDb || []).find(item => item.cover === key)
      || (window.RINA_MUSIC_DATA || []).find(item => item.cover === key || item.id === key)
      || null;
  }
  return (d.videoDb || []).find(item => item.cover === key || String(item.id) === String(key)) || null;
}
function mediaLabel(kind, key, index){
  const item = mediaAsset(kind, key, index);
  if (!item) return key;
  if (kind === 'voice') return key + ' - ' + (item.content || item.text || item.id || '');
  if (kind === 'music') return key + ' - ' + (item.title || item.name || item.id || '') + (item.artist || item.singer ? ' / ' + (item.artist || item.singer) : '');
  return key + ' - ' + (item.title || item.name || item.id || '');
}
function drawUnityModule(bits, key, sr, sc, h, w, flip){
  const mods = (db().faceModules || {});
  const bmp = mods[String(key)] || mods[key] || mods['0'];
  if (!bmp) return;
  for (let y=0; y<h; y++) for (let x=0; x<w; x++) {
    const sx = flip ? w - 1 - x : x;
    const rr = sr + y + LEGACY_ROW_OFFSET, cc = sc + x + LEGACY_COL_OFFSET;
    if (bmp[y] && bmp[y][sx] && isRealCell(rr, cc)) bits[bitIndex(rr, cc)] = 1;
  }
}
function unityFaceToBits(face){
  const bits = Array(ROWS * COLS).fill(0);
  face = face || {};
  drawUnityModule(bits, face.leye, 0, 0, 8, 8, false);
  drawUnityModule(bits, face.reye, 0, 10, 8, 8, false);
  drawUnityModule(bits, face.mouth, 8, 5, 8, 8, false);
  drawUnityModule(bits, face.cheek, 8, 14, 4, 4, false);
  drawUnityModule(bits, face.cheek, 8, 0, 4, 4, true);
  return bits;
}
function findTimelineIndex(tl, frame){ let best = -1; for (let i=0; i<tl.length; i++) { if ((tl[i].frame || 0) <= frame) best = i; else break; } return best; }
function currentMedia(){
  const kindEl = $('unityMediaKind');
  const selectEl = $('unityMediaSelect');
  const kind = kindEl ? (kindEl.value || 'voice') : 'voice';
  const key = selectEl ? (selectEl.value || '') : '';
  return {kind, key, timeline: timelineOf(kind, key)};
}
async function currentMediaLoaded(){
  const cur = currentMedia();
  cur.timeline = await ensureUnityTimeline(cur.kind, cur.key);
  return cur;
}
function updateMediaSelect(){
  const kindEl = $('unityMediaKind');
  const sel = $('unityMediaSelect');
  if (!kindEl || !sel) {
    debug('media select skipped', 'missing unityMediaKind or unityMediaSelect');
    return;
  }
  stopUnityMedia(false);
  const kind = kindEl.value || 'voice';
  sel.innerHTML = '';
  mediaKeys(kind).forEach((key, index) => {
    const o = document.createElement('option');
    o.value = key;
    o.textContent = mediaLabel(kind, key, index);
    sel.appendChild(o);
  });
  updateUnityDbInfo();
  const infoEl = $('unityMediaInfo');
  if (infoEl) infoEl.textContent = '未载入。选择媒体后点击“载入第 0 帧”或“播放”才会按需读取对应时间轴 JSON。';
}
function applyUnityFrame(frame, send, curOpt){
  const cur = curOpt || currentMedia();
  const idx = findTimelineIndex(cur.timeline || [], frame || 0);
  if (idx < 0) { log('Unity 没有可预览帧，可能尚未载入'); return null; }
  const bits = unityFaceToBits(cur.timeline[idx].face);
  renderBits($('unityMediaPreview'), bits, false);
  const hx = bitsToM370(bits);
  if (send && hardwareMode() && typeof window.sendText === 'function') sendText('M370:' + hx, false).catch(e => log('preview send failed: ' + e.message));
  const last = cur.timeline.length ? cur.timeline[cur.timeline.length - 1].frame || 0 : 0;
  if ($('unityMediaTime')) $('unityMediaTime').textContent = Math.floor((frame || 0) / UNITY_FPS) + 's / ' + Math.floor(last / UNITY_FPS) + 's';
  return hx;
}
async function chooseUnityMedia(send){
  stopUnityMedia(false);
  const cur = await currentMediaLoaded();
  const firstFrame = (cur.timeline && cur.timeline.length) ? (cur.timeline[0].frame || 0) : 0;
  const hx = applyUnityFrame(firstFrame, send !== false, cur);
  log('Unity 预览：' + cur.kind + ':' + cur.key + ' frame=' + firstFrame + (hx ? ' hex=' + hx.slice(0, 16) + '...' : ''));
  const selected = $('unityMediaSelect') ? $('unityMediaSelect').selectedIndex : 0;
  const infoEl = $('unityMediaInfo');
  const manifestItem = mediaManifestItem(cur.kind, cur.key) || {};
  if (infoEl) infoEl.textContent = JSON.stringify({
    kind: cur.kind,
    key: cur.key,
    label: mediaLabel(cur.kind, cur.key, selected),
    asset: mediaAsset(cur.kind, cur.key, selected),
    timeline_path: manifestItem.path || null,
    frames: cur.timeline.length,
    lazy_loaded: true
  }, null, 2);
}
function updateUnityDbInfo(){
  const d = db();
  const m = unityManifest();
  const loaded = {
    voice: Object.keys(d.voiceTimelines || {}),
    music: Object.keys(d.musicTimelines || {}),
    video: Object.keys(d.videoTimelines || {})
  };
  const el = $('dbInfo');
  if (el) el.textContent = JSON.stringify({
    mode: 'lazy-load timelines',
    ascii: (d.ascii || []).length,
    faceModules: Object.keys(d.faceModules || {}).length,
    voiceTimelines_available: (m.voice || []).length,
    musicTimelines_available: (m.music || []).length,
    videoTimelines_available: (m.video || []).length,
    loadedTimelines: loaded
  }, null, 2);
}
function sourceAssetPath(kind, key, item){
  item = item || {};
  if (item.music_src) return item.music_src;
  if (item.video_src) return item.video_src;
  if (item.audio_src) return item.audio_src;
  if (item.src) return item.src;
  if (item.url) return item.url;
  if (kind === 'music' && key) return '/assets/music/music_' + encodeURIComponent(key) + '.ogg';
  if (kind === 'video' && key) return '/assets/video/video_' + encodeURIComponent(key) + '.mp4';
  if (kind === 'voice') {
    const n = String(key || '').match(/(\d+)/);
    if (n) return '/assets/voice/voice_' + n[1] + '.ogg';
  }
  return '';
}
function mediaSource(){
  if (previewMode()) return '';
  const cur = currentMedia();
  const selected = $('unityMediaSelect') ? $('unityMediaSelect').selectedIndex : 0;
  const src = sourceAssetPath(cur.kind, cur.key, mediaAsset(cur.kind, cur.key, selected));
  return (src && src.charAt(0) === '/' && typeof window.rinaDeviceUrl === 'function') ? window.rinaDeviceUrl(src) : src;
}
function releaseHtmlMediaElement(el){
  if (!el) return;
  try { el.pause(); } catch (_) {}
  try { el.removeAttribute('src'); el.load(); } catch (_) {}
  el.style.display = 'none';
}
function showMediaElement(kind, url){
  const audio = $('unityMediaAudio'), video = $('unityMediaVideo');
  releaseHtmlMediaElement(audio);
  releaseHtmlMediaElement(video);
  if (!url) return null;
  const el = kind === 'video' ? video : audio;
  if (!el) return null;
  el.src = url;
  el.style.display = 'block';
  try { el.currentTime = 0; el.play().catch(()=>{}); } catch (_) {}
  return el;
}
function buildFirmwareTimeline(cur){
  const entries = [];
  let lastHex = '';
  for (const row of cur.timeline) {
    const hx = bitsToM370(unityFaceToBits(row.face));
    if (hx !== lastHex) { entries.push({frame: row.frame || 0, hex: hx}); lastHex = hx; }
  }
  if (entries.length && entries[0].frame > 0) entries.unshift({frame: 0, hex: entries[0].hex});
  const last = cur.timeline.length ? cur.timeline[cur.timeline.length - 1].frame || 0 : 0;
  const name = (cur.kind + ':' + cur.key).replace(/[|;,\r\n]/g, ' ').slice(0, 48);
  return {entries, last, name, loaded: entries.length};
}
async function sendFirmwareTimeline(cur, loop){
  const plan = buildFirmwareTimeline(cur);
  const entries = plan.entries;
  const last = plan.last;
  const name = plan.name;
  await sendText('timeline370Clear', true);
  await sendText('timeline370Begin|' + UNITY_FPS + '|' + last + '|' + (loop ? '1' : '0') + '|' + entries.length + '|' + name, true);
  let chunk = '';
  let loaded = 0;
  for (const e of entries) {
    const part = String(e.frame) + ',' + e.hex + ';';
    if ((chunk + part).length > 640) {
      const reply = await sendText('timeline370Chunk|' + chunk, true);
      const info = safeJson(reply, {});
      if (info && info.loaded != null) loaded = Number(info.loaded) || loaded;
      chunk = '';
    }
    chunk += part;
  }
  if (chunk) {
    const reply = await sendText('timeline370Chunk|' + chunk, true);
    const info = safeJson(reply, {});
    if (info && info.loaded != null) loaded = Number(info.loaded) || loaded;
  }
  if (loaded && loaded < entries.length) throw new Error('时间轴上传不完整：' + loaded + '/' + entries.length);
  return {entries, last, name, loaded: loaded || entries.length};
}
function stopUnityMedia(doFirmwareStop){
  if (mediaTimer) { clearInterval(mediaTimer); mediaTimer = null; }
  releaseHtmlMediaElement($('unityMediaAudio'));
  releaseHtmlMediaElement($('unityMediaVideo'));
  if (mediaBlobUrl && mediaBlobUrl.startsWith('blob:')) { try { URL.revokeObjectURL(mediaBlobUrl); } catch (_) {} }
  mediaElement = null; mediaBlobUrl = ''; mediaSilentFrame = 0; mediaLastFrame = 0; mediaToken++;
  const cur = currentMedia();
  if (doFirmwareStop !== false) unloadUnityTimelineExcept('', '');
  else unloadUnityTimelineExcept(cur.kind, cur.key);
  if (hardwareMode() && doFirmwareStop !== false) sendText('runtimeStop|media', false).catch(e => log('停止媒体失败：' + e.message));
}
async function playUnityMedia(){
  const cur = await currentMediaLoaded();
  if (!cur.timeline.length) { alert('没有时间轴数据'); return; }
  stopUnityMedia(false);
  const loop = toggleButtonValue('unityMediaLoop');
  const sent = previewMode() ? buildFirmwareTimeline(cur) : await sendFirmwareTimeline(cur, loop);
  mediaBlobUrl = mediaSource();
  mediaElement = showMediaElement(cur.kind, mediaBlobUrl);
  mediaLastFrame = sent.last;
  const token = ++mediaToken;
  if (hardwareMode()) await sendText('timeline370Play', true);
  mediaTimer = setInterval(() => {
    if (token !== mediaToken) return;
    let frame = mediaElement && mediaBlobUrl && !mediaElement.paused ? Math.floor((mediaElement.currentTime || 0) * UNITY_FPS) : mediaSilentFrame++;
    if (frame > mediaLastFrame + 20 || (mediaElement && mediaBlobUrl && mediaElement.ended)) {
      if (loop) { mediaSilentFrame = 0; if (mediaElement && mediaBlobUrl) { try { mediaElement.currentTime = 0; mediaElement.play(); } catch (_) {} } frame = 0; }
      else { stopUnityMedia(true); return; }
    }
    applyUnityFrame(frame, false, cur);
  }, Math.max(20, Math.floor(1000 / UNITY_FPS)));
  log((previewMode() ? 'Unity 本地预览：' : 'Unity 时间轴已发送：') + sent.loaded + '/' + sent.entries.length + ' keyframes, ' + sent.name);
}


async function sendFaceLiteBinary(){ await sendHex([+$('leye').value, +$('reye').value, +$('mouth').value, +$('cheek').value].map(toByte).join(''), false); }
async function sendTextLite(){ const h = cleanHex($('textLiteHex').value).padEnd(32, '0').slice(0, 32); $('textLiteHex').value = h; await sendHex(h, false); }
async function sendFaceFullBinary(){ await sendHex(bitsToLegacyHex(gridBits), false); }
async function binaryRequest(value){
  const parts = String(value).split(':');
  $('binaryOut').textContent = await sendHex(parts[0], true, parts[1] || 'hex');
}

let wifiCanConfigure = false;
function applyWifiLock(){
  const readonly = !wifiCanConfigure;
  ['wifiSsid','wifiPassword','wifiApSsid','wifiApPassword','wifiApChannel','wifiSaveBtn','wifiApSaveBtn','wifiScanBtn'].forEach(id => { const el = $(id); if (el) el.disabled = readonly; });
  if ($('wifiReadonlyBanner')) $('wifiReadonlyBanner').style.display = readonly ? '' : 'none';
  if ($('wifiApReadonlyBanner')) $('wifiApReadonlyBanner').style.display = readonly ? '' : 'none';
}
async function wifiRefreshStatus(){
  const out = $('wifiStatusOut');
  out.textContent = '读取中...';
  try {
    const s = await apiJson('/api/wifi/status');
    wifiCanConfigure = !!s.can_configure;
    out.textContent = (s.sta_connected ? 'STA: 已连接 SSID=' + s.sta_ssid + ' IP=' + s.sta_ip : 'STA: 未连接') + '\nAP: ' + (s.ap_ssid_cfg || s.ap_ssid || 'RinaChanBoard-S3') + ' IP=' + (s.ap_ip || '192.168.4.1');
    $('wifiModeNote').textContent = wifiCanConfigure ? '设备 AP 已开启，可扫描并修改 Wi-Fi。' : '当前 Wi-Fi 配置只读。';
    if (s.sta_ssid_cfg && !$('wifiSsid').value) $('wifiSsid').value = s.sta_ssid_cfg;
    if (s.ap_ssid_cfg && !$('wifiApSsid').value) $('wifiApSsid').value = s.ap_ssid_cfg;
    applyWifiLock();
  } catch (error) {
    out.textContent = '读取失败：' + error.message;
  }
}
async function wifiScan(){
  const box = $('wifiScanResults'), btn = $('wifiScanBtn');
  btn.disabled = true; btn.textContent = '扫描中...'; box.style.display = 'block'; box.textContent = '扫描中...';
  try {
    const data = await apiJson('/api/wifi/scan?t=' + Date.now());
    const nets = data.networks || [];
    const err = nets.find(n => n && n.error);
    if (err) throw new Error(err.error);
    box.innerHTML = nets.length ? '' : '<span class="small">未发现网络</span>';
    nets.forEach(n => {
      const row = document.createElement('button');
      row.type = 'button'; row.className = 'btn'; row.style.margin = '2px'; row.textContent = n.ssid + '  ' + n.rssi + ' dBm' + (n.channel ? '  ch' + n.channel : '');
      row.addEventListener('click', () => { $('wifiSsid').value = n.ssid; box.style.display = 'none'; $('wifiPassword').focus(); });
      box.appendChild(row);
    });
  } catch (error) { box.textContent = '扫描失败：' + error.message; }
  btn.disabled = false; btn.textContent = '扫描';
}
async function wifiSave(){
  if (!wifiCanConfigure) { alert('只能在连接到设备 AP 热点时修改 Wi-Fi。'); return; }
  const body = {
    ssid: $('wifiSsid').value.trim(),
    password: $('wifiPassword').value || '',
    ap_ssid: $('wifiApSsid').value.trim() || 'RinaChanBoard-S3',
    ap_password: $('wifiApPassword').value || '',
    ap_channel: $('wifiApChannel').value || '6'
  };
  try {
    const data = await apiJson('/api/wifi/save', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:new URLSearchParams(body)});
    $('wifiSaveOut').textContent = JSON.stringify(data, null, 2);
  } catch (error) { $('wifiSaveOut').textContent = '保存失败：' + error.message; }
}
function wifiTogglePw(){
  const pw = $('wifiPassword'), btn = $('wifiPwToggle');
  pw.type = pw.type === 'password' ? 'text' : 'password';
  btn.textContent = pw.type === 'password' ? '显示' : '隐藏';
}


function currentRunMode(){
  return hardwareMode() ? 'device' : 'preview';
}
function applyRunModeUi(){
  const mode = currentRunMode();
  const hostEl = $('host');
  if (hostEl) hostEl.textContent = location.host || 'local file';
  const badge = $('runModeBadge');
  if (badge) {
    badge.textContent = mode === 'device' ? 'DEVICE / 设备控制' : 'PREVIEW / 本地预览';
    badge.className = 'pill ' + (mode === 'device' ? 'ok' : 'warn');
  }
  const out = $('runModeOut');
  if (out) out.textContent = JSON.stringify({mode, host: location.host || 'local file', api: hardwareMode() ? location.origin : null}, null, 2);
  const play = $('playUnityMedia');
  if (play) play.textContent = hardwareMode() ? '发送并播放' : '预览播放';
}


function fillSelectors(){
  const faces = window.RINA_FACES || {};
  makeOptions($('leye'), (faces.leye || []).length);
  makeOptions($('reye'), (faces.reye || []).length);
  makeOptions($('mouth'), (faces.mouth || []).length);
  makeOptions($('cheek'), (faces.cheek || []).length);
  const colors = $('presetColor');
  if (colors) {
    colors.innerHTML = '';
    (window.RINA_COLOR_INFO || []).forEach((c, i) => {
      const o = document.createElement('option');
      o.value = c.color; o.textContent = pad2(i) + ' ' + c.name + ' #' + c.color;
      colors.appendChild(o);
    });
  }
  const ch = $('wifiApChannel');
  if (ch) for (let i=1; i<=13; i++) { const o = document.createElement('option'); o.value = String(i); o.textContent = String(i); if (i === 6) o.selected = true; ch.appendChild(o); }
  updateMediaSelect();
}
function bind(){
  bindToggleButton('saveFaceLocked', false);
  bindToggleButton('unityMediaLoop', false);
  bindToggleButton('eyeSyncBox', false, function(on){ if (on && $('leye') && $('reye')) $('reye').value = $('leye').value; faceFromSelectors(); });
  applyRunModeUi();
  setUiThemeColor(currentColorHex());
  on('clearDebugLog', 'click', 'clearDebugLog', () => { const box = $('debugLog'); if (box) box.textContent = ''; });
  onAll('[data-tab]', 'click', 'tab', (ev, btn) => {
    qa('[data-tab]').forEach(b => b.classList.remove('active'));
    qa('.tab').forEach(t => t.classList.remove('show'));
    btn.classList.add('active'); $(btn.dataset.tab).classList.add('show');
    if (hardwareMode()) sendText('runtimeStop|tabSwitch', false).catch(function(){});
    if (btn.dataset.tab === 'tab-wifi') wifiRefreshStatus();
    if (btn.dataset.tab === 'tab-saved') loadFaces();
  });
  on('refreshStatus', 'click', 'refreshStatus', updateStatus);
  on('readVersion', 'click', 'readVersion', requestVersion);
  on('readEspStatus', 'click', 'readEspStatus', requestEspStatus);
  on('manualModeToggle', 'click', 'manualModeToggle', toggleManualMode);
  on('manualModeRefresh', 'click', 'manualModeRefresh', requestManualMode);
  on('colorPick', 'input', 'colorPick', () => { setUiThemeColor($('colorPick').value.slice(1)); });
  on('usePresetColor', 'click', 'usePresetColor', () => { setUiThemeColor($('presetColor').value); return uploadColor(); });
  on('uploadColor', 'click', 'uploadColor', uploadColor);
  on('downloadColor', 'click', 'downloadColor', downloadColor);
  on('uploadBright', 'click', 'uploadBright', uploadBright);
  on('downloadBright', 'click', 'downloadBright', downloadBright);
  on('bright', 'input', 'brightInput', () => syncBrightControls($('bright').value));
  on('brightSlider', 'input', 'brightSlider', () => syncBrightControls($('brightSlider').value));
  onAll('[data-bright]', 'click', 'brightPreset', (ev, btn) => { syncBrightControls(btn.dataset.bright); return uploadBright(); });
  on('readBattery', 'click', 'readBattery', requestBatteryJson);
  on('autoSync', 'click', 'autoSync', autoSyncAll);
  on('clearFace', 'click', 'clearFace', () => setEditorBits(Array(ROWS * COLS).fill(0)));
  on('invertFace', 'click', 'invertFace', () => setEditorBits(gridBits.map((b, i) => isRealCell(Math.floor(i / COLS), i % COLS) ? (b ? 0 : 1) : 0)));
  on('uploadFace', 'click', 'uploadFace', uploadFace);
  on('downloadFace', 'click', 'downloadFace', downloadFace);
  on('loadHexToEditor', 'click', 'loadHexToEditor', () => setColorsByString($('faceHex').value));
  on('sendLegacyBinary', 'click', 'sendLegacyBinary', sendFaceFullBinary);
  on('saveCustomFace', 'click', 'saveCustomFace', saveCustomFaceToSharedStore);
  ['leye','reye','mouth','cheek'].forEach(id => on(id, 'change', id + 'Change', () => { if (id === 'leye' && toggleButtonValue('eyeSyncBox') && $('reye')) $('reye').value = $('leye').value; faceFromSelectors(); }));
  on('buildFace', 'click', 'buildFace', faceFromSelectors);
  on('uploadPartFace', 'click', 'uploadPartFace', () => { faceFromSelectors(); return uploadFace(); });
  on('randomPartBtn', 'click', 'randomPart', () => randomizeParts(false));
  on('randomUploadPartBtn', 'click', 'randomUploadPart', () => randomizeParts(true));
  on('sendFaceLiteBinary', 'click', 'sendFaceLiteBinary', sendFaceLiteBinary);
  on('savePartFace', 'click', 'savePartFace', savePartFaceToSharedStore);
  on('reloadFaces', 'click', 'reloadFaces', loadFaces);
  on('saveCurrentFace', 'click', 'saveCurrentFace', addCurrentFace);
  on('savedFaces', 'change', 'savedFacesChange', () => { selectedFaceIndex = +$('savedFaces').value || 0; renderSavedFaces(); sendText('selectFace370|' + selectedFaceIndex, false).catch(function(){}); });
  on('loadCustomFace', 'click', 'loadCustomFace', loadSelectedFace);
  on('renameCustomFace', 'click', 'renameCustomFace', renameSelectedFace);
  on('toggleLockFace', 'click', 'toggleLockFace', toggleSelectedLock);
  on('deleteCustomFace', 'click', 'deleteCustomFace', deleteSelectedFace);
  on('previewScrollText', 'click', 'previewScrollText', previewScrollText);
  on('startScrollText', 'click', 'startScrollText', startScrollText);
  on('stopScrollText', 'click', 'stopScrollText', () => stopScrollText(true));
  on('unityMediaKind', 'change', 'unityMediaKind', updateMediaSelect);
  on('unityMediaSelect', 'change', 'unityMediaSelect', () => chooseUnityMedia(false));
  on('chooseUnityMedia', 'click', 'chooseUnityMedia', () => chooseUnityMedia(true));
  on('playUnityMedia', 'click', 'playUnityMedia', playUnityMedia);
  on('stopUnityMedia', 'click', 'stopUnityMedia', () => stopUnityMedia(true));
  onAll('[data-binary-request]', 'click', 'binaryRequest', (ev, btn) => binaryRequest(btn.dataset.binaryRequest));
  on('sendTextLite', 'click', 'sendTextLite', sendTextLite);
  on('sendRawHex', 'click', 'sendRawHex', () => sendHex($('rawHex').value, false));
  on('sendRawHexWait', 'click', 'sendRawHexWait', () => sendHex($('rawHex').value, true));
  on('wifiRefreshStatus', 'click', 'wifiRefreshStatus', wifiRefreshStatus);
  on('wifiScanBtn', 'click', 'wifiScan', wifiScan);
  on('wifiSaveBtn', 'click', 'wifiSave', wifiSave);
  on('wifiApSaveBtn', 'click', 'wifiApSave', wifiSave);
  on('wifiPwToggle', 'click', 'wifiTogglePw', wifiTogglePw);
}
function init(){
  fillSelectors();
  bind();
  renderEditor();
  renderPartGalleries();
  faceFromSelectors();
  syncBrightControls(($('bright') && $('bright').value) || 16);
  previewScrollText();
  updateUnityDbInfo();
  loadFaces();
  updateStatus();
  statusTimer = setInterval(updateStatus, 5000);
  requestManualMode().catch(()=>{});
  log('Web UI ready');
}

Object.assign(window, {
  sendText, sendHex, req, log, debug, setColorsByString, clearFace: () => setEditorBits(Array(ROWS * COLS).fill(0)),
  invertFace: () => setEditorBits(gridBits.map((b, i) => isRealCell(Math.floor(i / COLS), i % COLS) ? (b ? 0 : 1) : 0)),
  uploadFace, downloadFace, uploadColor, downloadColor, uploadBright, downloadBright, requestVersion,
  requestEspStatus, requestBatteryJson, autoSyncAll, faceFromSelectors, renderPartFacePreview, syncBrightControls, sendFaceLiteBinary,
  sendTextLite, sendFaceFullBinary, saveCustomFaceToSharedStore, savePartFaceToSharedStore, startScrollText, stopScrollText, previewScrollText,
  chooseUnityMedia, playUnityMedia, stopUnityMedia, wifiRefreshStatus, wifiScan, wifiSave, wifiTogglePw,
  requestManualMode, setManualMode, toggleManualMode
});

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, {once:true});
else init();
})();
