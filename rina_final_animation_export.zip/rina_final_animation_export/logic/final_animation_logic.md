# 最终版动画逻辑与图片导出

导出来源：`rina_loading_demo_image_shield_above_halo`

本导出包只包含动画逻辑和图片，不包含后方网页正文内容。

## 文件清单

```text
rina_final_animation_export/
├─ images/
│  ├─ rina_icon1_default.png
│  └─ rina_icon2_hover.png
├─ base64/
│  ├─ rina_icon1_default.base64.txt
│  ├─ rina_icon2_hover.base64.txt
│  └─ rina_image_data_urls.js
└─ logic/
   ├─ final_animation_logic.md
   ├─ final_animation_logic.json
   └─ animation_core_snippets.css
```

## 图片 Assets

| 名称 | 文件 | 大小 | base64 长度 |
|---|---|---:|---:|
| 默认图片 | `images/rina_icon1_default.png` | 41172 bytes | 54896 chars |
| hover 图片 | `images/rina_icon2_hover.png` | 40837 bytes | 54452 chars |

## Data URL 常量

```js
const RINA_ICON_DEFAULT_DATA_URL = "data:image/png;base64,...";
const RINA_ICON_HOVER_DATA_URL = "data:image/png;base64,...";
```

完整值已写入：

```text
base64/rina_image_data_urls.js
```

## DOM 结构

```html
<div class="loading-overlay" id="loadingOverlay">
  <div class="blur-screen" id="blurScreen" aria-hidden="true"></div>

  <div class="loading-box">
    <div class="loader-stage">
      <div class="flash-halo" aria-hidden="true"></div>

      <div class="avatar-circle">
        <img class="avatar-before" id="avatarBefore">
        <img class="avatar-after" id="avatarAfter">
      </div>
    </div>
    <div class="loading-text">Loading</div>
  </div>
</div>
```

## 图层规则

```text
blur-screen              z-index: 1
loading-box              z-index: 20
loader-stage             isolation: isolate
flash-halo               z-index: 10
avatar-circle            z-index: 200
avatar-circle::before    z-index: 210  不透明白色防穿透底板
avatar-before            z-index: 220
avatar-after             z-index: 230
```

核心要求：

```text
1. flash-halo 永远低于所有图片相关层。
2. avatar-circle::before 是不透明白底，位于图片下方、进度环上方。
3. 图片切换时即使 before/after 出现透明空窗，也只会露出白色底板。
4. hover 图片 avatar-after 永远是最高图片层。
5. blur-screen 永远在图片下方。
```

## 关键 CSS

### 白色防穿透底板

```css
.avatar-circle::before {
  content: "";
  position: absolute;
  left: var(--avatar-frame-width);
  top: var(--avatar-frame-width);
  width: var(--icon-size);
  height: var(--icon-size);
  z-index: 210;
  border-radius: 50%;
  background: #fff;
  pointer-events: none;
}
```

### 图片层

```css
.avatar-before {
  z-index: 220;
  opacity: 1;
}

.avatar-after {
  z-index: 230;
  opacity: 0;
}
```

### 进度环层

```css
.flash-halo {
  z-index: 10;
}
```

## 动画时间轴

```text
打开页面 / 重新播放
→ overlay 显示
→ blur-screen 显示
→ 默认图片显示
→ hover 图片隐藏
→ 白色防穿透底板存在于图片下方
→ 单层 flash-halo 在图片层下方呼吸

加载完成信号：
→ 等待呼吸环到达 100% 亮度峰值
→ 同一帧触发 is-ring-contracting + is-image-pop

进度环：
→ haloContractOut 执行 300ms
→ transform: scale(1.075) → transform: scale(0.65)
→ opacity: 1 → opacity: 0
→ 300ms 到点后 is-halo-hidden
→ visibility:hidden + opacity:0 + transform:scale(0)

图片切换：
→ avatar-before opacity: 0
→ avatar-after opacity: 1
→ 如果出现透明空窗，由 avatar-circle::before 白底填补
→ 不会露出 flash-halo

最终释放：
→ hover 图片保持 0.5s
→ avatar-circle 先缩小到 1.12x
→ 图片重新开始放大后 blur-screen 才开始消失
→ 图片继续放大到 2.35x 并在 1.3s 内淡出
→ blur-screen 以图片圆心为原点，用 1s 多级羽化扩散消失
→ overlay 隐藏，重播按钮恢复
```

## 性能约束

```text
- 进度环收缩只使用 transform: scale(...) 和 opacity。
- 图片缩放只使用 transform。
- 动画过程中不改 width / height / margin。
- loader-stage 使用 isolation:isolate 锁定内部堆叠关系。
- will-change 只在 overlay 激活时使用。
```

## 完整 base64

完整 base64 没有直接写进本 Markdown 主体，避免文件过大。请使用：

```text
base64/rina_icon1_default.base64.txt
base64/rina_icon2_hover.base64.txt
base64/rina_image_data_urls.js
```
